const {spawnSync}=require('child_process');
const tests=['physics_smoke.js','economy_smoke.js','effects_smoke.js','car_catalog_smoke.js','car_geometry_smoke.js','porsche_shop_smoke.js','shop_garage_smoke.js','garage_visual_smoke.js','garage_performance_smoke.js','cases_smoke.js','root_tools_smoke.js','admin_panel_smoke.js','interaction_guard_smoke.js','account_auth_smoke.js','admin_console_smoke.js','drift_smoke.js','track_geometry_smoke.js','trajectory_sector_test.js','standalone_race_test.js'];
for(const t of tests){console.log('\n== '+t+' ==');const r=spawnSync(process.execPath,[require('path').join(__dirname,t)],{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);}
console.log('\nexisting standalone tests: OK');
