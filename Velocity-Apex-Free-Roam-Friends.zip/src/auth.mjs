const SESSION_COOKIE='va_session';
const SESSION_TTL_MS=30*24*60*60*1000;
const PASSWORD_ITERATIONS=100000;
const SAVE_LIMIT_BYTES=64*1024;
const ADMIN_USERNAME='w1st1r';
const ADMIN_PASSWORD_SHA256='dxEnsDF2QSbEDOepP2HFM_okaUwBB-fBg8fC90XrmIA';
const ADMIN_UNLOCK_TTL_MS=30*60*1000;
const ADMIN_MAX_BAN_MS=365*24*60*60*1000;
const ADMIN_MAX_CREDITS=999999999;
const enc=new TextEncoder();
let adminSchemaPromise=null;
let socialSchemaPromise=null;

const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json;charset=UTF-8','cache-control':'no-store','x-content-type-options':'nosniff',...headers}});
const now=()=>Date.now();
const b64url=bytes=>{let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');};
const randomBytes=n=>{const a=new Uint8Array(n);crypto.getRandomValues(a);return a;};
const sha256=async value=>b64url(new Uint8Array(await crypto.subtle.digest('SHA-256',typeof value==='string'?enc.encode(value):value)));
const normalizeUsername=v=>String(v||'').trim().toLowerCase();
const validUsername=v=>/^[a-z0-9_]{3,24}$/.test(v);
const normalizeDisplayName=v=>String(v||'').trim().replace(/\s+/g,' ');
const validDisplayName=v=>v.length>=2&&v.length<=24&&/^[\p{L}\p{N}_\- .]+$/u.test(v)&&!/[<>"'`\\/]/.test(v);
const validPassword=v=>typeof v==='string'&&v.length>=8&&v.length<=128;
const isAdminUsername=v=>normalizeUsername(v)===ADMIN_USERNAME;
const adminUser=user=>({...user,isAdmin:isAdminUsername(user?.username)});

function cookieValue(request,name){
  const raw=request.headers.get('cookie')||'';
  for(const part of raw.split(';')){const i=part.indexOf('=');if(i<0)continue;if(part.slice(0,i).trim()===name)return decodeURIComponent(part.slice(i+1).trim());}
  return '';
}
function sessionCookie(request,value,maxAge=Math.floor(SESSION_TTL_MS/1000)){
  const secure=new URL(request.url).protocol==='https:'?'; Secure':'';
  return `${SESSION_COOKIE}=${encodeURIComponent(value)}; Path=/; HttpOnly${secure}; SameSite=Lax; Max-Age=${maxAge}`;
}
function sameOrigin(request){const origin=request.headers.get('origin');return !origin||origin===new URL(request.url).origin;}
async function readBody(request){const len=Number(request.headers.get('content-length')||0);if(len>SAVE_LIMIT_BYTES+8192)throw new Error('REQUEST_TOO_LARGE');return request.json();}
async function passwordHash(password,salt,iterations=PASSWORD_ITERATIONS){
  const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations},key,256);
  return b64url(new Uint8Array(bits));
}
function decodeB64url(input){
  const s=String(input||'').replace(/-/g,'+').replace(/_/g,'/');
  const padded=s+'='.repeat((4-s.length%4)%4),raw=atob(padded),out=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;
}
function safeSave(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw))return null;
  let text;try{text=JSON.stringify(raw);}catch{return null;}
  if(enc.encode(text).byteLength>SAVE_LIMIT_BYTES)return null;
  return text;
}
function defaultSave(){return {saveVersion:6,credits:200,ownedLiveries:['apexLime'],ownedEffects:['standard'],caseInventory:{},selectedLivery:'apexLime',selectedEffect:'standard'};}
function safeResourceId(v){const s=String(v||'');return /^[a-zA-Z0-9_-]{1,64}$/.test(s)?s:'';}
function normalizeReason(v){return String(v||'').trim().replace(/\s+/g,' ').slice(0,240);}

async function ensureAdminSchema(env){
  if(adminSchemaPromise)return adminSchemaPromise;
  adminSchemaPromise=(async()=>{
    await env.DB.batch([
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS account_bans (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        reason TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        created_by TEXT NOT NULL,
        revoked_at INTEGER,
        revoked_by TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_account_bans_user_active ON account_bans(user_id,revoked_at,expires_at)'),
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS admin_unlocks (
        session_token_hash TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_admin_unlocks_expires ON admin_unlocks(expires_at)'),
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS admin_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_user_id TEXT NOT NULL,
        target_user_id TEXT,
        action TEXT NOT NULL,
        details TEXT,
        created_at INTEGER NOT NULL
      )`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_admin_audit_created ON admin_audit(created_at)')
    ]);
  })().catch(e=>{adminSchemaPromise=null;throw e;});
  return adminSchemaPromise;
}
async function audit(env,adminId,targetId,action,details={}){
  let text='{}';try{text=JSON.stringify(details).slice(0,2000);}catch{}
  await env.DB.prepare('INSERT INTO admin_audit (admin_user_id,target_user_id,action,details,created_at) VALUES (?,?,?,?,?)').bind(adminId,targetId||null,action,text,now()).run();
}
async function createSession(env,request,userId){
  const raw=b64url(randomBytes(32)),hash=await sha256(raw),t=now(),expires=t+SESSION_TTL_MS;
  await env.DB.prepare('INSERT INTO sessions (token_hash,user_id,created_at,expires_at,last_seen_at) VALUES (?,?,?,?,?)').bind(hash,userId,t,expires,t).run();
  return {raw,expires};
}
async function currentSession(env,request){
  const raw=cookieValue(request,SESSION_COOKIE);if(!raw)return null;
  const hash=await sha256(raw),t=now();
  const row=await env.DB.prepare(`SELECT s.token_hash,s.user_id,s.expires_at,s.last_seen_at,u.username,u.display_name,u.created_at
    FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? LIMIT 1`).bind(hash).first();
  if(!row)return null;
  if(Number(row.expires_at)<=t){await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(hash).run();return null;}
  if(t-Number(row.last_seen_at||0)>6*60*60*1000)await env.DB.prepare('UPDATE sessions SET last_seen_at=? WHERE token_hash=?').bind(t,hash).run();
  return {hash,user:adminUser({id:row.user_id,username:row.username,displayName:row.display_name,createdAt:Number(row.created_at)||0})};
}
async function activeBan(env,userId,t=now()){
  const row=await env.DB.prepare(`SELECT id,reason,created_at,expires_at FROM account_bans
    WHERE user_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY expires_at DESC,created_at DESC LIMIT 1`).bind(userId,t).first();
  if(!row)return null;
  return {id:row.id,reason:row.reason,createdAt:Number(row.created_at)||0,expiresAt:Number(row.expires_at)||0,remainingMs:Math.max(0,Number(row.expires_at)-t)};
}
async function banResponse(env,user,status=423){const ban=await activeBan(env,user.id);return ban?json({error:'ACCOUNT_BANNED',user:adminUser(user),ban},status):null;}
async function saveRow(env,userId){
  const row=await env.DB.prepare('SELECT save_json,revision,updated_at FROM player_saves WHERE user_id=? LIMIT 1').bind(userId).first();
  if(!row)return {save:null,revision:0,updatedAt:0};
  let save=null;try{save=JSON.parse(row.save_json);}catch{}
  return {save,revision:Number(row.revision)||0,updatedAt:Number(row.updated_at)||0};
}
async function writeSave(env,userId,raw,expectedRevision=null){
  const text=safeSave(raw);if(!text)return {ok:false,error:'INVALID_SAVE'};
  const t=now(),current=await saveRow(env,userId),expected=Number.isInteger(expectedRevision)?expectedRevision:null;
  if(expected!==null&&expected!==current.revision)return {ok:false,error:'SAVE_CONFLICT',save:current.save,revision:current.revision,updatedAt:current.updatedAt};
  if(current.revision>0){
    const result=await env.DB.prepare('UPDATE player_saves SET save_json=?,revision=revision+1,updated_at=? WHERE user_id=? AND revision=?').bind(text,t,userId,current.revision).run();
    if(Number(result?.meta?.changes||0)!==1){const latest=await saveRow(env,userId);return {ok:false,error:'SAVE_CONFLICT',save:latest.save,revision:latest.revision,updatedAt:latest.updatedAt};}
  }else{
    try{await env.DB.prepare('INSERT INTO player_saves (user_id,save_json,revision,created_at,updated_at) VALUES (?,?,1,?,?)').bind(userId,text,t,t).run();}
    catch(e){const latest=await saveRow(env,userId);if(latest.revision>0)return {ok:false,error:'SAVE_CONFLICT',save:latest.save,revision:latest.revision,updatedAt:latest.updatedAt};throw e;}
  }
  const row=await saveRow(env,userId);return {ok:true,revision:row.revision||1,updatedAt:row.updatedAt||t};
}
async function requireAdmin(env,request,{unlocked=true}={}){
  const session=await currentSession(env,request);if(!session)return {error:json({error:'AUTH_REQUIRED'},401)};
  if(!session.user.isAdmin)return {error:json({error:'ADMIN_REQUIRED'},403)};
  const ban=await activeBan(env,session.user.id);if(ban)return {error:json({error:'ACCOUNT_BANNED',ban},423)};
  if(unlocked){
    const row=await env.DB.prepare('SELECT expires_at FROM admin_unlocks WHERE session_token_hash=? AND user_id=? LIMIT 1').bind(session.hash,session.user.id).first();
    if(!row||Number(row.expires_at)<=now())return {error:json({error:'ADMIN_LOCKED'},403)};
    return {session,unlockExpiresAt:Number(row.expires_at)||0};
  }
  return {session};
}
async function targetUser(env,id){
  return env.DB.prepare('SELECT id,username,display_name,created_at,last_login_at FROM users WHERE id=? LIMIT 1').bind(id).first();
}
async function accountDetail(env,id){
  const user=await targetUser(env,id);if(!user)return null;
  const row=await saveRow(env,id),save=row.save&&typeof row.save==='object'?row.save:defaultSave(),ban=await activeBan(env,id);
  const cases=save.caseInventory&&typeof save.caseInventory==='object'&&!Array.isArray(save.caseInventory)?save.caseInventory:{};
  return {user:adminUser({id:user.id,username:user.username,displayName:user.display_name,createdAt:Number(user.created_at)||0,lastLoginAt:Number(user.last_login_at)||0}),save:{credits:Math.max(0,Math.floor(Number(save.credits)||0)),ownedLiveries:Array.isArray(save.ownedLiveries)?save.ownedLiveries:[],ownedEffects:Array.isArray(save.ownedEffects)?save.ownedEffects:[],caseInventory:cases,selectedLivery:String(save.selectedLivery||'apexLime'),selectedEffect:String(save.selectedEffect||'standard')},revision:row.revision,updatedAt:row.updatedAt,ban};
}
async function mutateTargetSave(env,id,mutator){
  const exists=await targetUser(env,id);if(!exists)return {error:'USER_NOT_FOUND'};
  for(let attempt=0;attempt<4;attempt++){
    const row=await saveRow(env,id),save=row.save&&typeof row.save==='object'&&!Array.isArray(row.save)?structuredClone(row.save):defaultSave();
    const result=mutator(save);if(result?.error)return result;
    const written=await writeSave(env,id,save,row.revision);
    if(written.ok)return {ok:true,result:result||{},revision:written.revision,updatedAt:written.updatedAt,detail:await accountDetail(env,id)};
    if(written.error!=='SAVE_CONFLICT')return {error:written.error};
  }
  return {error:'SAVE_CONFLICT'};
}

async function ensureSocialSchema(env){
  if(socialSchemaPromise)return socialSchemaPromise;
  socialSchemaPromise=(async()=>{
    await env.DB.batch([
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS friendships (
        user_low TEXT NOT NULL,
        user_high TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (user_low,user_high),
        FOREIGN KEY (user_low) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (user_high) REFERENCES users(id) ON DELETE CASCADE
      )`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_friendships_low ON friendships(user_low)'),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_friendships_high ON friendships(user_high)'),
      env.DB.prepare(`CREATE TABLE IF NOT EXISTS user_presence (
        user_id TEXT PRIMARY KEY,
        last_seen_at INTEGER NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )`),
      env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_user_presence_seen ON user_presence(last_seen_at)')
    ]);
  })().catch(e=>{socialSchemaPromise=null;throw e;});
  return socialSchemaPromise;
}
async function touchPresence(env,userId){
  const t=now();await env.DB.prepare(`INSERT INTO user_presence (user_id,last_seen_at) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET last_seen_at=excluded.last_seen_at`).bind(userId,t).run();return t;
}
async function requireUser(env,request){
  const session=await currentSession(env,request);if(!session)return {error:json({error:'AUTH_REQUIRED'},401)};
  const ban=await activeBan(env,session.user.id);if(ban)return {error:json({error:'ACCOUNT_BANNED',ban},423)};
  return {session};
}
async function handleFriendsRequest(request,env,url){
  await ensureSocialSchema(env);if(request.method!=='GET'&&!sameOrigin(request))return json({error:'ORIGIN_REJECTED'},403);
  const access=await requireUser(env,request);if(access.error)return access.error;const me=access.session.user;await touchPresence(env,me.id);
  if(url.pathname==='/api/friends/presence'&&request.method==='POST')return json({ok:true,seenAt:now()});
  if(url.pathname==='/api/friends'&&request.method==='GET'){
    const cutoff=now()-90000;
    const result=await env.DB.prepare(`SELECT u.id,u.username,u.display_name,u.created_at,p.last_seen_at
      FROM friendships f JOIN users u ON u.id=CASE WHEN f.user_low=? THEN f.user_high ELSE f.user_low END
      LEFT JOIN user_presence p ON p.user_id=u.id
      WHERE f.user_low=? OR f.user_high=? ORDER BY lower(u.username) ASC`).bind(me.id,me.id,me.id).all();
    const friends=(result.results||[]).map(r=>({id:r.id,username:r.username,displayName:r.display_name,createdAt:Number(r.created_at)||0,lastSeenAt:Number(r.last_seen_at)||0,online:Number(r.last_seen_at||0)>=cutoff}));
    return json({ok:true,friends});
  }
  if((url.pathname==='/api/friends/add'||url.pathname==='/api/friends/remove')&&request.method==='POST'){
    const b=await readBody(request),username=normalizeUsername(String(b?.username||'').replace(/^@/,''));if(!validUsername(username))return json({error:'INVALID_USERNAME'},400);
    const target=await env.DB.prepare('SELECT id,username,display_name FROM users WHERE username=? COLLATE NOCASE LIMIT 1').bind(username).first();if(!target)return json({error:'USER_NOT_FOUND'},404);if(target.id===me.id)return json({error:'CANNOT_ADD_SELF'},400);
    const low=me.id<target.id?me.id:target.id,high=me.id<target.id?target.id:me.id;
    if(url.pathname.endsWith('/add')){const exists=await env.DB.prepare('SELECT 1 AS ok FROM friendships WHERE user_low=? AND user_high=? LIMIT 1').bind(low,high).first();if(exists)return json({error:'ALREADY_FRIENDS'},409);await env.DB.prepare('INSERT INTO friendships (user_low,user_high,created_at) VALUES (?,?,?)').bind(low,high,now()).run();return json({ok:true,friend:{id:target.id,username:target.username,displayName:target.display_name}});}
    await env.DB.prepare('DELETE FROM friendships WHERE user_low=? AND user_high=?').bind(low,high).run();return json({ok:true});
  }
  return json({error:'NOT_FOUND'},404);
}

async function handleAdminRequest(request,env,url){
  await ensureAdminSchema(env);
  if(!sameOrigin(request)&&request.method!=='GET')return json({error:'ORIGIN_REJECTED'},403);

  if(url.pathname==='/api/admin/status'&&request.method==='GET'){
    const access=await requireAdmin(env,request,{unlocked:false});if(access.error)return access.error;
    const row=await env.DB.prepare('SELECT expires_at FROM admin_unlocks WHERE session_token_hash=? AND user_id=? LIMIT 1').bind(access.session.hash,access.session.user.id).first();
    const expiresAt=Number(row?.expires_at)||0;return json({ok:true,isAdmin:true,unlocked:expiresAt>now(),expiresAt});
  }
  if(url.pathname==='/api/admin/unlock'&&request.method==='POST'){
    const access=await requireAdmin(env,request,{unlocked:false});if(access.error)return access.error;
    const b=await readBody(request),digest=await sha256(String(b?.password||''));if(digest!==ADMIN_PASSWORD_SHA256)return json({error:'ADMIN_PASSWORD_INVALID'},403);
    const t=now(),expiresAt=t+ADMIN_UNLOCK_TTL_MS;
    await env.DB.prepare(`INSERT INTO admin_unlocks (session_token_hash,user_id,created_at,expires_at) VALUES (?,?,?,?)
      ON CONFLICT(session_token_hash) DO UPDATE SET user_id=excluded.user_id,created_at=excluded.created_at,expires_at=excluded.expires_at`).bind(access.session.hash,access.session.user.id,t,expiresAt).run();
    await audit(env,access.session.user.id,null,'admin_unlock',{expiresAt});return json({ok:true,expiresAt});
  }
  if(url.pathname==='/api/admin/lock'&&request.method==='POST'){
    const access=await requireAdmin(env,request,{unlocked:false});if(access.error)return access.error;
    await env.DB.prepare('DELETE FROM admin_unlocks WHERE session_token_hash=?').bind(access.session.hash).run();return json({ok:true});
  }

  const access=await requireAdmin(env,request);if(access.error)return access.error;
  if(url.pathname==='/api/admin/accounts'&&request.method==='GET'){
    const q=normalizeUsername(url.searchParams.get('q')||'').replace(/^@/,'').slice(0,24),blocked=url.searchParams.get('blocked')==='1',like='%'+q+'%',t=now();
    let sql=`SELECT u.id,u.username,u.display_name,u.created_at,u.last_login_at,ps.revision,ps.updated_at AS save_updated_at,
      (SELECT b.reason FROM account_bans b WHERE b.user_id=u.id AND b.revoked_at IS NULL AND b.expires_at>? ORDER BY b.expires_at DESC,b.created_at DESC LIMIT 1) AS ban_reason,
      (SELECT b.expires_at FROM account_bans b WHERE b.user_id=u.id AND b.revoked_at IS NULL AND b.expires_at>? ORDER BY b.expires_at DESC,b.created_at DESC LIMIT 1) AS ban_expires_at
      FROM users u LEFT JOIN player_saves ps ON ps.user_id=u.id
      WHERE (lower(u.username) LIKE ? OR lower(u.display_name) LIKE ?)`;
    const binds=[t,t,like,like];
    if(blocked){sql+=` AND EXISTS (SELECT 1 FROM account_bans bx WHERE bx.user_id=u.id AND bx.revoked_at IS NULL AND bx.expires_at>?)`;binds.push(t);}
    sql+=' ORDER BY COALESCE(u.last_login_at,u.created_at) DESC LIMIT 50';
    const result=await env.DB.prepare(sql).bind(...binds).all();
    const accounts=(result.results||[]).map(r=>({id:r.id,username:r.username,displayName:r.display_name,createdAt:Number(r.created_at)||0,lastLoginAt:Number(r.last_login_at)||0,revision:Number(r.revision)||0,saveUpdatedAt:Number(r.save_updated_at)||0,ban:r.ban_expires_at?{reason:r.ban_reason||'',expiresAt:Number(r.ban_expires_at)||0,remainingMs:Math.max(0,Number(r.ban_expires_at)-t)}:null,isAdmin:isAdminUsername(r.username)}));
    return json({ok:true,accounts});
  }
  const detailMatch=url.pathname.match(/^\/api\/admin\/account\/([0-9a-f-]{16,64})$/i);
  if(detailMatch&&request.method==='GET'){
    const detail=await accountDetail(env,detailMatch[1]);if(!detail)return json({error:'USER_NOT_FOUND'},404);return json({ok:true,...detail});
  }
  const actionMatch=url.pathname.match(/^\/api\/admin\/account\/([0-9a-f-]{16,64})\/(credits|resource|ban|unban)$/i);
  if(actionMatch&&request.method==='POST'){
    const userId=actionMatch[1],action=actionMatch[2],target=await targetUser(env,userId);if(!target)return json({error:'USER_NOT_FOUND'},404);
    if(action==='credits'){
      const b=await readBody(request),delta=Number(b?.delta);if(!Number.isSafeInteger(delta)||delta===0||Math.abs(delta)>ADMIN_MAX_CREDITS)return json({error:'INVALID_AMOUNT'},400);
      const changed=await mutateTargetSave(env,userId,save=>{const before=Math.max(0,Math.floor(Number(save.credits)||0)),after=Math.max(0,Math.min(ADMIN_MAX_CREDITS,before+delta));save.credits=after;return {before,after,delta:after-before};});
      if(changed.error)return json({error:changed.error},changed.error==='SAVE_CONFLICT'?409:400);await audit(env,access.session.user.id,userId,'credits',{requestedDelta:delta,...changed.result,liveSync:true});return json(changed);
    }
    if(action==='resource'){
      const b=await readBody(request),kind=String(b?.kind||''),resourceId=safeResourceId(b?.id),op=String(b?.action||''),quantity=Math.max(1,Math.min(999,Math.floor(Number(b?.quantity)||1)));
      if(!['car','effect','case'].includes(kind)||!resourceId||!['grant','revoke'].includes(op))return json({error:'INVALID_RESOURCE_ACTION'},400);
      const changed=await mutateTargetSave(env,userId,save=>{
        if(kind==='case'){
          if(!save.caseInventory||typeof save.caseInventory!=='object'||Array.isArray(save.caseInventory))save.caseInventory={};
          const before=Math.max(0,Math.min(999,Math.floor(Number(save.caseInventory[resourceId])||0))),after=op==='grant'?Math.min(999,before+quantity):Math.max(0,before-quantity);save.caseInventory[resourceId]=after;return {kind,id:resourceId,action:op,before,after,quantity:Math.abs(after-before)};
        }
        const key=kind==='car'?'ownedLiveries':'ownedEffects',selectedKey=kind==='car'?'selectedLivery':'selectedEffect',fallback=kind==='car'?'apexLime':'standard';
        if(resourceId===fallback&&op==='revoke')return {error:'SYSTEM_RESOURCE'};
        if(!Array.isArray(save[key]))save[key]=[fallback];if(!save[key].includes(fallback))save[key].unshift(fallback);
        const before=save[key].includes(resourceId);if(op==='grant'&&!before)save[key].push(resourceId);if(op==='revoke'&&before)save[key]=save[key].filter(x=>x!==resourceId);
        if(op==='revoke'&&save[selectedKey]===resourceId)save[selectedKey]=fallback;
        return {kind,id:resourceId,action:op,before,after:save[key].includes(resourceId)};
      });
      if(changed.error)return json({error:changed.error},changed.error==='SAVE_CONFLICT'?409:400);await audit(env,access.session.user.id,userId,'resource',{...changed.result,liveSync:true});return json(changed);
    }
    if(action==='ban'){
      if(isAdminUsername(target.username))return json({error:'ADMIN_ACCOUNT_PROTECTED'},403);
      const b=await readBody(request),durationMs=Math.floor(Number(b?.durationMs)),reason=normalizeReason(b?.reason);if(!Number.isFinite(durationMs)||durationMs<1000||durationMs>ADMIN_MAX_BAN_MS)return json({error:'INVALID_BAN_DURATION'},400);if(reason.length<3)return json({error:'INVALID_BAN_REASON'},400);
      const t=now(),expiresAt=t+durationMs,id=crypto.randomUUID();
      await env.DB.prepare('UPDATE account_bans SET revoked_at=?,revoked_by=? WHERE user_id=? AND revoked_at IS NULL AND expires_at>?').bind(t,access.session.user.id,userId,t).run();
      await env.DB.prepare('INSERT INTO account_bans (id,user_id,reason,created_at,expires_at,created_by) VALUES (?,?,?,?,?,?)').bind(id,userId,reason,t,expiresAt,access.session.user.id).run();
      await audit(env,access.session.user.id,userId,'ban',{reason,expiresAt,durationMs});
      return json({ok:true,ban:{id,reason,createdAt:t,expiresAt,remainingMs:durationMs},detail:await accountDetail(env,userId)});
    }
    if(action==='unban'){
      const t=now();await env.DB.prepare('UPDATE account_bans SET revoked_at=?,revoked_by=? WHERE user_id=? AND revoked_at IS NULL AND expires_at>?').bind(t,access.session.user.id,userId,t).run();await audit(env,access.session.user.id,userId,'unban',{});return json({ok:true,detail:await accountDetail(env,userId)});
    }
  }
  return json({error:'NOT_FOUND'},404);
}

export async function handleAuthRequest(request,env,url=new URL(request.url)){
  if(!url.pathname.startsWith('/api/auth/')&&!url.pathname.startsWith('/api/account/')&&!url.pathname.startsWith('/api/admin/')&&!url.pathname.startsWith('/api/friends'))return null;
  if(!env.DB)return json({error:'DATABASE_UNAVAILABLE'},503);
  try{
    await ensureAdminSchema(env);
    if(url.pathname.startsWith('/api/friends'))return handleFriendsRequest(request,env,url);
    if(url.pathname.startsWith('/api/admin/'))return handleAdminRequest(request,env,url);
    if(url.pathname==='/api/auth/me'&&request.method==='GET'){
      const session=await currentSession(env,request);if(!session)return json({authenticated:false});
      const banned=await banResponse(env,session.user);if(banned)return banned;
      const cloud=await saveRow(env,session.user.id);
      return json({authenticated:true,user:session.user,saveRevision:cloud.revision,saveUpdatedAt:cloud.updatedAt});
    }
    if(url.pathname==='/api/auth/register'&&request.method==='POST'){
      if(!sameOrigin(request))return json({error:'ORIGIN_REJECTED'},403);
      const b=await readBody(request),username=normalizeUsername(b?.username),displayName=normalizeDisplayName(b?.displayName),password=b?.password;
      if(!validUsername(username))return json({error:'INVALID_USERNAME'},400);
      if(!validDisplayName(displayName))return json({error:'INVALID_DISPLAY_NAME'},400);
      if(!validPassword(password))return json({error:'INVALID_PASSWORD'},400);
      const exists=await env.DB.prepare('SELECT id FROM users WHERE username=? COLLATE NOCASE LIMIT 1').bind(username).first();
      if(exists)return json({error:'USERNAME_TAKEN'},409);
      const id=crypto.randomUUID(),salt=randomBytes(16),hash=await passwordHash(password,salt),t=now();
      try{
        await env.DB.prepare('INSERT INTO users (id,username,display_name,password_hash,password_salt,password_iterations,created_at,updated_at,last_login_at) VALUES (?,?,?,?,?,?,?,?,?)')
          .bind(id,username,displayName,hash,b64url(salt),PASSWORD_ITERATIONS,t,t,t).run();
      }catch(e){if(String(e?.message||e).toLowerCase().includes('unique'))return json({error:'USERNAME_TAKEN'},409);throw e;}
      if(b?.save&&safeSave(b.save))await writeSave(env,id,b.save);
      const session=await createSession(env,request,id);
      return json({ok:true,user:adminUser({id,username,displayName,createdAt:t})},201,{'set-cookie':sessionCookie(request,session.raw)});
    }
    if(url.pathname==='/api/auth/login'&&request.method==='POST'){
      if(!sameOrigin(request))return json({error:'ORIGIN_REJECTED'},403);
      const b=await readBody(request),username=normalizeUsername(b?.username),password=b?.password;
      if(!validUsername(username)||!validPassword(password))return json({error:'INVALID_CREDENTIALS'},401);
      const row=await env.DB.prepare('SELECT id,username,display_name,password_hash,password_salt,password_iterations,created_at FROM users WHERE username=? COLLATE NOCASE LIMIT 1').bind(username).first();
      if(!row)return json({error:'INVALID_CREDENTIALS'},401);
      const hash=await passwordHash(password,decodeB64url(row.password_salt),Number(row.password_iterations)||PASSWORD_ITERATIONS);
      if(hash!==row.password_hash)return json({error:'INVALID_CREDENTIALS'},401);
      const user=adminUser({id:row.id,username:row.username,displayName:row.display_name,createdAt:Number(row.created_at)||0});
      const banned=await banResponse(env,user);if(banned)return banned;
      const t=now();await env.DB.prepare('UPDATE users SET last_login_at=?,updated_at=? WHERE id=?').bind(t,t,row.id).run();
      const session=await createSession(env,request,row.id);
      return json({ok:true,user},200,{'set-cookie':sessionCookie(request,session.raw)});
    }
    if(url.pathname==='/api/auth/logout'&&request.method==='POST'){
      if(!sameOrigin(request))return json({error:'ORIGIN_REJECTED'},403);
      const session=await currentSession(env,request);if(session){await env.DB.prepare('DELETE FROM admin_unlocks WHERE session_token_hash=?').bind(session.hash).run();await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(session.hash).run();}
      return json({ok:true},200,{'set-cookie':sessionCookie(request,'',0)});
    }
    if(url.pathname==='/api/account/save'&&request.method==='GET'){
      const session=await currentSession(env,request);if(!session)return json({error:'AUTH_REQUIRED'},401);const banned=await banResponse(env,session.user);if(banned)return banned;
      return json({ok:true,...await saveRow(env,session.user.id)});
    }
    if(url.pathname==='/api/account/save'&&(request.method==='PUT'||request.method==='POST')){
      if(!sameOrigin(request))return json({error:'ORIGIN_REJECTED'},403);
      const session=await currentSession(env,request);if(!session)return json({error:'AUTH_REQUIRED'},401);const banned=await banResponse(env,session.user);if(banned)return banned;
      const b=await readBody(request),expectedRevision=Number.isInteger(b?.revision)?b.revision:null,result=await writeSave(env,session.user.id,b?.save,expectedRevision);
      if(!result.ok)return json({error:result.error,save:result.save??null,revision:result.revision||0,updatedAt:result.updatedAt||0},result.error==='SAVE_CONFLICT'?409:400);return json(result);
    }
    return json({error:'NOT_FOUND'},404);
  }catch(e){
    if(e?.message==='REQUEST_TOO_LARGE')return json({error:'REQUEST_TOO_LARGE'},413);
    console.error('auth error',e);return json({error:'SERVER_ERROR'},500);
  }
}
