import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const load=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
const citySrc=load('public/js/free-city.js'),html=load('public/index.html'),worker=load('src/worker.mjs');
const track=load('public/js/track.js'),menu=load('public/js/main-menu-ui.js'),css=load('public/css/v72-polish.css'),roam=load('public/js/freeroam.js');
const ctx={window:{}};vm.createContext(ctx);
vm.runInContext(citySrc.replace('window.ApexCity={','window.__v72={trees,roads,areas,garageVenue};window.ApexCity={'),ctx);
const city=ctx.window.ApexCity,{trees,roads,areas,garageVenue}=ctx.window.__v72;
const version=JSON.parse(load('public/version.json'));
assert.equal(version.version,'V73');assert.equal(city.coastalRingVersion,72);
assert.match(html,/velocity-apex-version" content="V73"/);
assert.match(html,/coastal=v72/);assert.match(html,/v72-polish.css\?v=20261014-v72/);
assert.match(html,/track.js[^"\n]*ui=v72/);
assert.ok(trees.length>=250,'island foliage must be preserved');
assert.ok(roads.length>=16);
assert.equal(city.minigameVenues.length,3);
const hot=city.minigameVenues.find(x=>x.id==='hot_potato'),check=city.minigameVenues.find(x=>x.id==='checkpoint');
assert.equal(hot.apron.x,505,'move Hot Potato pad toward its city-block center');
assert.equal(hot.apron.w,390);assert.equal(hot.building.x,560);
assert.match(roam,/hotPotatoHub:\{x:700,y:1400/);
assert.match(worker,/hot_potato:\{x:700,y:1400/);
for(const venue of city.minigameVenues){
  for(const section of ['apron','access','exit']){
    const a=venue[section];assert.ok(city.roadAt(a.x+a.w/2,a.y+a.h/2,-20),`${venue.id} ${section} not driveable`);
    const cx=a.x+a.w/2,cy=a.y+a.h/2;
    assert.ok(!trees.some(t=>Math.hypot(cx-t.x,cy-t.y)<t.r),`${venue.id} centre covered by vegetation`);
  }
}
function intersectsTree(rect,t){
 const x=Math.max(rect.x-12,Math.min(rect.x+rect.w+12,t.x));
 const y=Math.max(rect.y-12,Math.min(rect.y+rect.h+12,t.y));
 return Math.hypot(t.x-x,t.y-y)<t.r*(t.species==='palm'?2.5:1.9);
}
for(const venue of [hot,check])for(const key of ['apron','building','access','exit']){
 assert.ok(trees.every(t=>!intersectsTree(venue[key],t)),`tree canopy covers ${venue.id} ${key}`);
}
assert.match(citySrc,/if\(a!==activityAreas\.garageAccess\)/,'do not paint access area across public street');
assert.match(citySrc,/const bx=gx-gb\.w\/2/,'garage must remain centered');
assert.match(citySrc,/const glass=c\.createLinearGradient/,'garage glass-door art missing');
assert.match(citySrc,/Complete two-piece taxiway arrows/);
assert.ok(!/path\(c,\[\[x,2788\],\[x\+38,2788\]/.test(citySrc),'broken airport arrows remain');
assert.ok(!/ctx\.moveTo\(x,y-size\*1\.7\)/.test(track),'triangular pine artifacts still drawn');
assert.match(menu,/api\/progression\/me/);assert.doesNotMatch(menu,/api\/upgrade\/profile/);
assert.match(worker,/api\/progression\/me/);assert.match(menu,/Number\.isFinite\(raw\)/);
assert.match(menu,/const id=r\.LIVERIES\[wanted\]\?wanted:'apexLime'/);
assert.match(css,/#menu \.rc-car-holder img/);
assert.match(css,/\.case-quantity-control strong\{display:flex/);
assert.match(css,/\.promo-card \.promo-header,\.friends-card \.friends-header/);
assert.ok(css.includes('#crewDialog{width:min(600px'));
assert.ok(city.roadAt(2675,535,-20),'garage curb opening must stay drivable');
assert.ok(city.roadAt(2675,660,-20),'garage center must stay driveable');
assert.ok(city.roadAt(3338,865,-20),'checkpoint center must stay driveable');
assert.ok(city.roadAt(700,1400,-20),'moved Hot Potato interaction must be driveable');
console.log(`v72_ui_map_review_test: OK — ${trees.length} foliage items, 3 safe events, live level API, full airport arrows, continuous garage asphalt, clean iOS UI`);
