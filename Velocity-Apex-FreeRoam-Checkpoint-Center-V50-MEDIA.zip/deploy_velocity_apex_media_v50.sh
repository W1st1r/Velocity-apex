#!/usr/bin/env bash
set -euo pipefail

ZIP="${1:-Velocity-Apex-FreeRoam-Checkpoint-Center-V50-MEDIA.zip}"
if [[ ! -f "$ZIP" ]]; then
  echo "ZIP not found: $ZIP" >&2
  exit 1
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
unzip -q "$ZIP" -d "$WORK"
ROOT="$(dirname "$(find "$WORK" -maxdepth 4 -type f -name wrangler.jsonc -print -quit)")"
if [[ -z "$ROOT" || ! -f "$ROOT/wrangler.jsonc" ]]; then
  echo "wrangler.jsonc not found in archive" >&2
  exit 1
fi

cd "$ROOT"
if [[ -f package-lock.json ]]; then npm ci; else npm install; fi
npm test
node tests/media_v50_test.mjs
npx wrangler d1 migrations apply velocity-apex-db --remote
npm run deploy

echo "Velocity Apex MEDIA V50 deployed successfully."
