"""APEX free-roam V44 collision builder.

The drivable boundary is derived from the shipped map texture itself instead of a
fixed-width road approximation. Hand-traced centerlines are only used as a broad
region-of-interest so similarly colored roofs/objects cannot become drivable.
This makes the collision edge follow the visible asphalt/curb border pixel by pixel.

Requires: numpy, scipy, Pillow, opencv-python. Runtime does not need these packages.
"""
from pathlib import Path
import json,base64,struct
import numpy as np
import cv2
from scipy.ndimage import distance_transform_edt,label

ROOT=Path(__file__).resolve().parents[1]
layout_path=ROOT/'public/js/map-layout-v43.js'
text=layout_path.read_text(encoding='utf-8')
layout=json.loads(text.split('=',1)[1].rsplit(';',1)[0])
layout['version']=44
W,H=layout['width'],layout['height'];S=layout['referenceScale'];step=2
nx,ny=W//step,H//step

# Geometry scripts remain named v43 for backwards-compatible imports, but the
# payload version and cache key are V44.
payload=json.dumps(layout,separators=(',',':'),ensure_ascii=False)
layout_path.write_text('/* V44 geometry: texture-aligned free-roam layout. */\nwindow.ApexMapLayout='+payload+';\n',encoding='utf-8')
(ROOT/'src/free-map-v43.mjs').write_text('/* V44 generated map layout shared by server and client. */\nexport const FREE_MAP='+payload+';\n',encoding='utf-8')

img=cv2.imread(str(ROOT/'public/assets/maps/free-roam-v41.png'),cv2.IMREAD_COLOR)
if img is None: raise RuntimeError('Map texture missing')
img=cv2.resize(img,(nx,ny),interpolation=cv2.INTER_AREA)
hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
_h,sat,val=cv2.split(hsv)

# Asphalt is neutral/dark. Long bright curb strips are intentionally excluded;
# short lane/crosswalk gaps are restored by morphology below.
asphalt=(((sat<62)&(val>=42)&(val<=180))|((sat<88)&(val>=24)&(val<92))).astype(np.uint8)*255

# Restrict segmentation to a broad envelope around known roads. This is wider
# than the old collision so the texture, not the hand trace, decides the final edge.
roi=np.zeros((ny,nx),np.uint8)
for r in layout['roads']:
    pts=np.array([[round(x*S/step),round(y*S/step)] for x,y in r['points']],np.int32)
    width=max(1,round((r['width']+28)*S/step))
    cv2.polylines(roi,[pts],False,255,width,lineType=cv2.LINE_AA)
    rad=max(1,width//2)
    for p in pts: cv2.circle(roi,tuple(p),rad,255,-1,lineType=cv2.LINE_AA)

mask=cv2.bitwise_and(asphalt,roi)
# Restore lane markings and remove tiny pixel dents that could snag a moving car.
mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9)),iterations=2)
mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)),iterations=1)

# Gameplay surfaces are deliberate asphalt/plaza areas and must stay fully usable.
def pxy(points): return np.array([[round(x*S/step),round(y*S/step)] for x,y in points],np.int32)
for poly in layout['surfaces']: cv2.fillPoly(mask,[pxy(poly['points'])],255)

# Guarantee continuous road center corridors even under heavy artwork shadows.
for r in layout['roads']:
    pts=pxy(r['points']);width=max(1,round((r['width']-16)*S/step));rad=max(1,width//2)
    cv2.polylines(mask,[pts],False,255,width,lineType=cv2.LINE_AA)
    for p in pts: cv2.circle(mask,tuple(p),rad,255,-1,lineType=cv2.LINE_AA)

# Keep intentional obstacles non-drivable.
for poly in layout['obstacles']: cv2.fillPoly(mask,[pxy(poly)],0)

# Keep only the connected world containing the player spawn. This prevents a
# dark roof or decoration inside the ROI from becoming an isolated driveable island.
cc,n=label(mask>0)
sy,sx=round(layout['spawn']['y']/step),round(layout['spawn']['x']/step)
main=(cc==cc[sy,sx])
if not main.any(): raise RuntimeError('Spawn is not connected to drivable map')

# Signed distance, in world units, to the exact texture-derived edge.
inside=distance_transform_edt(main)*step-step/2
outside=distance_transform_edt(~main)*step-step/2
field=np.clip(np.where(main,inside,-outside),-127,127).astype(np.int16)+128
field=field.astype(np.uint8)

# Delta + RLE keeps the JS payload compact and fast to decode.
delta=field.copy();delta[1:]=(field[1:].astype(np.int16)-field[:-1].astype(np.int16))%256
flat=delta.ravel();ends=np.r_[0,np.nonzero(flat[1:]!=flat[:-1])[0]+1,len(flat)]
buf=bytearray()
for a,b in zip(ends[:-1],ends[1:]):
    length=int(b-a)
    while length:
        k=min(length,65535);buf+=struct.pack('<HB',k,int(flat[a]));length-=k
encoded=base64.b64encode(buf).decode()
(ROOT/'public/js/map-collision-v43.js').write_text(
    "/* V44 signed clearance derived from the visible asphalt/curb texture. */\n"
    "(function(){const raw=atob('"+encoded+"'),data=new Uint8Array(3750000);let p=0;"
    "for(let i=0;i<raw.length;i+=3){const n=raw.charCodeAt(i)|(raw.charCodeAt(i+1)<<8);data.fill(raw.charCodeAt(i+2),p,p+n);p+=n;}"
    "if(p!==data.length)throw new Error('Invalid V44 collision field');for(let i=2500;i<data.length;i++)data[i]=(data[i]+data[i-2500])&255;"
    "window.ApexMapCollision={data,width:2500,height:1500,step:2,version:44};})();\n",encoding='utf-8')

# QA outputs outside the release tree.
qa=img.copy();overlay=np.zeros_like(qa);overlay[:]=[255,185,20]
qa=np.where(main[...,None],(qa*.72+overlay*.28).astype(np.uint8),qa)
contours,_=cv2.findContours(main.astype(np.uint8)*255,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
cv2.drawContours(qa,contours,-1,(0,0,255),2)
cv2.imwrite(str(ROOT.parent/'v44-collision-overlay.jpg'),qa,[cv2.IMWRITE_JPEG_QUALITY,92])
np.save(ROOT.parent/'v44-field.npy',field)
components,sizes=label(inside>16),None
print('V44 collision cells',int(main.sum()),'RLE bytes',len(encoded),'texture',img.shape)
