import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../public/js/free-city.js',import.meta.url),'utf8');
const scope={window:{}};vm.createContext(scope);vm.runInContext(source,scope);const city=scope.window.ApexCity;
const server=fs.readFileSync(new URL('../src/worker.mjs',import.meta.url),'utf8');
const match=server.match(/const FREE_MINIGAME_HUBS=Object.freeze\((\{[\s\S]*?\})\);/);
const serverHubs=vm.runInNewContext('('+match[1]+')');
for(const venue of city.minigameVenues){
 const h=city.hubs[venue.id],a=venue.apron;
 assert.equal(h.x,a.x+a.w/2);assert.equal(h.y,a.y+a.h/2);
 assert.equal(h.x,serverHubs[venue.id].x);assert.equal(h.y,serverHubs[venue.id].y);assert.equal(h.r,serverHubs[venue.id].r);
 for(let angle=0;angle<Math.PI*2;angle+=.04)assert(city.roadAt(h.x+Math.cos(angle)*h.r,h.y+Math.sin(angle)*h.r,-20),'entire trigger must be on accessible asphalt');
 for(const lane of [venue.access,venue.exit]){
   const start={x:lane.x+lane.w/2,y:lane.y+lane.h/2};const end={x:h.x,y:h.y};
   const c={...start,vx:0,vy:0};
   for(let i=1;i<=100;i++){const px=c.x,py=c.y;c.x=start.x+(end.x-start.x)*i/100;c.y=start.y+(end.y-start.y)*i/100;c.vx=(c.x-px)*60;c.vy=(c.y-py)*60;city.resolveCarMotion(c,px,py);assert(city.roadAt(c.x,c.y,-20));}
   assert(Math.hypot(c.x-h.x,c.y-h.y)<1,'entry to marker must not hit invisible barrier');
 }
}
// Regression for screenshot: lawns and park paths are not a second hidden road map.
for(const [x,y] of [[1300,1740],[1360,1300],[2500,1200],[3320,1800],[540,536]])assert(!city.roadAt(x,y),`lawn/building/water is not driveable ${x},${y}`);
assert(!source.includes('mapSprite'),'no asynchronous picture may replace the authoritative geometry');
console.log('free_map_v42_test: OK — server/client hubs, full trigger rings, swept venue entry, lawns and park protected');
