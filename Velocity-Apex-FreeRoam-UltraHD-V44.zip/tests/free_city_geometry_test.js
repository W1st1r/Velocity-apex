// V43 geometry and swept collision regression suite.
import('./free_map_v43_test.mjs').catch(e=>{console.error(e);process.exitCode=1;});
