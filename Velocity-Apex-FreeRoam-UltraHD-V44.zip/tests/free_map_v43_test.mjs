import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import {FREE_MAP as server} from '../src/free-map-v43.mjs';
const scope={window:{},atob};vm.createContext(scope);
for(const name of ['map-layout-v43.js','map-collision-v43.js','free-city.js'])vm.runInContext(fs.readFileSync(new URL('../public/js/'+name,import.meta.url),'utf8'),scope);
const city=scope.window.ApexCity,L=city.layout,S=L.referenceScale,C=city.carClearance||20;
assert.deepEqual(JSON.parse(JSON.stringify(L)),server,'client/server layout must be identical');
for(const key of ['spawn','crew','speed','drag','drift','koth','levels','meet']){const p=L[key];assert(city.roadAt(p.x,p.y,-C),key+' must be reachable');}
for(const p of [...Object.values(L.hubs),L.crew,L.speed,L.drag,L.drift,L.koth,L.levels,...L.kothZones])for(let a=0;a<Math.PI*2;a+=.025){assert(city.roadAt(p.x+Math.cos(a)*p.r,p.y+Math.sin(a)*p.r,-C),`ring outside asphalt ${p.label||p.x} at ${a}`);}
// Specific non-drivable surfaces observed in the artwork, including the user's lawn.
for(const [x,y] of [[590,705],[598,520],[1100,742],[230,704],[815,292],[1400,527],[270,232],[1720,743]])assert(!city.roadAt(x*S,y*S),`grass, buildings or water ${x},${y}`);
for(const p of L.obstacles){const x=p.reduce((a,b)=>a+b[0],0)/p.length,y=p.reduce((a,b)=>a+b[1],0)/p.length;assert(!city.roadAt(x*S,y*S),'parked artwork vehicles must block driving');}
function drive(points){
 for(let k=1;k<points.length;k++){
  const a=points[k-1].map(n=>n*S),b=points[k].map(n=>n*S),n=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/3);
  let c={x:a[0],y:a[1],vx:0,vy:0};assert(city.roadAt(c.x,c.y,-C),'route start '+points[k-1]);
  for(let i=1;i<=n;i++){const x=c.x,y=c.y;c.x=a[0]+(b[0]-a[0])*i/n;c.y=a[1]+(b[1]-a[1])*i/n;c.vx=(c.x-x)*60;c.vy=(c.y-y)*60;city.resolveCarMotion(c,x,y);assert(city.roadAt(c.x,c.y,-C));}
  assert(Math.hypot(c.x-b[0],c.y-b[1])<2,`blocked route ${points[k-1]} -> ${points[k]}`);
 }
}
for(const route of [
 [[806,196],[806,150],[806,138],[860,138]],[[913,196],[913,151],[913,138],[860,138]],
 [[1349,411],[1349,373],[1349,361],[1394,361]],[[1436,411],[1436,373],[1436,361],[1394,361]],
 [[475,553],[421,553],[390,553],[362,565]],[[475,579],[415,579],[380,577],[362,565]],
 [[475,720],[441,720],[441,781],[400,820],[321,910]],[[475,720],[490,720],[490,779],[450,820]],
 [[991,632],[880,600],[887,526]],[[730,1018],[1200,1018],[1950,1018]]
])drive(route);
// Swept impacts in every direction along the road network: no tunneling or speed gain.
let count=0;for(const r of L.roads)for(const q of r.points){const x=q[0]*S,y=q[1]*S;if(!city.roadAt(x,y,-C))continue;for(let a=0;a<Math.PI*2;a+=.31){const c={x:x+Math.cos(a)*950*.35,y:y+Math.sin(a)*950*.35,vx:Math.cos(a)*950,vy:Math.sin(a)*950};city.resolveCarMotion(c,x,y);assert(city.roadAt(c.x,c.y,-C));assert(c.speed<950.01);count++;}}
for(let lane=0;lane<2;lane++)for(let x=L.dragStartX;x<=L.dragFinishX+50;x+=5)assert(city.roadAt(x,L.dragLaneY+lane*L.dragLaneGap,-C),'drag lane must stay on runway');
for(const [x,y] of [[3920,1840],[740,839],[2738,2429],[2067,2429],[1242,2558],[334,1629]])assert(city.clearance(x,y)>C-1,'screenshot collision point must remain usable');
console.log(`V44 PASS: exact client/server layout, protected lawns, artwork obstacles, all event rings, 12 entrance routes, ${count} swept impacts, both drag lanes`);
