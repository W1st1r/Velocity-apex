// V43 replaces the old procedural venue coordinate contract.
import './free_map_v43_test.mjs';
