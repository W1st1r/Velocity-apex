# Velocity Apex

Top-down / rotating-top-down racing PWA for iPhone/Safari, Android and desktop. The existing HTML/CSS/JavaScript/Canvas 2D architecture is preserved: no framework, npm build, CDN, Three.js, Matter.js or other runtime dependency is required.

## Launch

Open `index.html` in a modern browser. On iPhone use landscape orientation. For Home Screen installation, deploy the project over HTTPS and use Safari → Share → Add to Home Screen. The existing manifest, safe-area layout and static hosting configuration are unchanged.

## Controls

Control mode is stored in `localStorage` and is available both from the main menu and PAUSE.

- **ARROWS** — left/right steering plus independent GAS / BRAKE; multitouch remains supported.
- **TILT** — DeviceOrientation analog steering with iOS permission flow, dead zone and sensitivity selection.
- **WHEEL** — analog virtual wheel, independent GAS / BRAKE.
- Desktop: ← / A, → / D — steer; ↑ / W — gas; ↓ / S — brake; P / Escape — pause.

The physics now expects circuit-racing technique: brake before a slow corner, turn in, then open the throttle on exit. There is no automatic player brake and no hidden track-centering steering assist.

## Formula-style physics

`js/car.js` now uses a high-grip Formula-style yaw/tyre model instead of preserving a large lateral velocity during ordinary cornering.

- Steering requests yaw; available tyre grip limits achievable yaw, so an excessive high-speed steering request becomes **understeer / speed scrub**, not persistent drift.
- Mechanical grip is supplemented by a speed-squared aero/downforce term, giving strong high-speed stability without making low-speed steering rotate the car in place.
- Asphalt lateral velocity relaxes quickly toward the body direction. Heavy braking + steering, impacts, barriers and off-road surfaces temporarily allow more slip.
- Steering release damps yaw quickly and LEFT → RIGHT transitions reverse naturally without a long residual slide.
- GAS, BRAKE, coasting and off-road drag remain distinct.
- The existing OBB/SAT collision footprint is retained. Car-to-car and barrier impacts can temporarily disturb grip instead of being visually erased immediately.

The fixed/substep physics path remains `1/120 s` with the existing bounded number of per-frame substeps.

## Precomputed minimum-time racing line and speed profile

`js/racing-line.js` performs the expensive trajectory search once when a `Track` is created. `js/track.js` stores the result and cached speed profiles.

1. The closed centerline is arc-length resampled.
2. Curvature is smoothed only for feature detection; meaningful apexes and linked sectors are identified over a long forward horizon.
3. Hard/Extreme use a coarse second-order dynamic program over lateral offsets. The cost is based on real path length, three-point curvature, lateral movement, edge/surface risk and smoothness.
4. Each corner group can then evaluate conservative, normal, early/late apex, maximum-radius, attack, curb-cut, S-straightening and sacrifice-corner candidates.
5. Every candidate rebuilds trajectory curvature and a lateral-speed envelope, then runs closed-loop backward braking and forward acceleration propagation. Estimated sector/lap time plus small surface/risk penalties determines the winner.
6. A light final relaxation removes lateral-grid quantization without washing out useful apex movement.

The result is cached per track. No global racing-line optimization runs in the 120 Hz physics loop.

## Racing surfaces

`js/car.js` and `js/track.js` share the same surface rules for player and AI:

- **asphalt** — full grip;
- **curb / narrow shoulder** — small grip, steering and drag penalty but intentionally driveable for brief racing use;
- **true off-road** — strong traction/grip loss and large drag;
- **barrier** — separate physical collision boundary.

Surface contact uses an orientation-aware wheel envelope. Barrier clearance uses the full 44-unit OBB projection, so two-wheel curb use does not imply that the body may intersect a wall.

## Racing AI

`js/ai.js` follows the difficulty-specific precomputed trajectory and cached speed profile with a dynamic Pure-Pursuit-style look-ahead.

- Look-ahead grows with speed, shortens near a sharp apex and is stabilized through fast S transitions.
- Braking combines the local speed target with forward deceleration demand; Hard/Extreme use progressively more of the real brake capability and trail off the brake as the exit opens.
- Throttle uses hysteresis and exit-speed priority to avoid repeated throttle/brake chatter and to accelerate early when the following profile rises.
- Difficulty changes line quality, confidence, risk/curb use, traffic skill and consistency. It does **not** add max speed, power, braking force, grip, rubber-band or teleport behavior.
- Traffic chooses alternate lanes when blocked, reserves side-by-side corridors and dynamically narrows the allowed envelope in dense packs so several cars do not converge on the same curb/apex.
- Once traffic clears, lane response returns smoothly to the time-optimal line.

## Camera

Race camera transform is now isotropic top-down / rotating top-down:

```js
ctx.scale(cam.zoom, cam.zoom)
```

`cam.pitch` and speed-dependent anisotropic Y scaling have been removed from race camera code. Therefore a car keeps the same geometric length/width ratio at world headings 0°, 45°, 90° and every other angle. Speed-dependent look-ahead and zoom remain; rotation tracking is faster so camera lag does not create a false impression of sliding. Collision shake is preserved.

## Tracks and race setup

The existing five tracks, 1–13 bots, Easy / Medium / Hard / Extreme and 3 / 5 / 7 / 10 / 15 lap choices are retained. Shop/economy, save key, HUD, mini-map, lap counting, finish flow, credits, PWA manifest and iPhone landscape/safe-area UI are unchanged unless directly required by physics/AI/camera integration.

| Track | Length | Character |
| --- | ---: | --- |
| APEX CIRCUIT | 7.39 km | Technical circuit |
| NEON HARBOR | 5.40 km | Street / night |
| DESERT CANYON | 9.60 km | High speed + hairpin |
| ALPINE RING | 6.70 km | S-sections + hairpins |
| COASTLINE GT | 8.40 km | Fast arcs + technical sector |

## Reproducible standalone tests

No package installation is needed:

```bash
node tests/physics_smoke.js
node tests/standalone_race_test.js
node tests/trajectory_sector_test.js
```

The first script checks high-speed slip, LEFT → RIGHT response, braking/turning, grass recovery and camera invariants. The second runs real `Track + Car + AIController` simulations for Medium/Hard/Extreme on all five tracks plus 8-, 10- and 13-car traffic races. The third checks fast-turn, hairpin, left-right S, right-left S, three-corner linked and corner-to-long-straight trajectory behavior.

Current measured results and environment limitations are documented in `TEST_REPORT.md`.

## Project structure

- `js/content.js` — tracks, themes, save migration, shop/economy.
- `js/racing-line.js` — cached minimum-time lateral-state planner, sector candidates and trajectory/speed evaluation.
- `js/track.js` — spline sampling, racing-surface classification, planned line storage, cached speed profiles and static track renderer.
- `js/car.js` — Formula-style physics, shared car model, OBB/SAT helpers, rendering.
- `js/ai.js` — difficulty profiles, racing-line following, braking, overtaking and traffic prediction.
- `js/controls.js` — ARROWS / TILT / WHEEL input and iOS multitouch handling.
- `js/game.js` — race lifecycle, collision solver, camera, HUD, mini-map and UI integration.
- `tests/physics_smoke.js` — deterministic physics/camera checks.
- `tests/standalone_race_test.js` — deterministic AI lap, curb/off-road statistics and dense traffic simulations.
- `tests/trajectory_sector_test.js` — deterministic geometry checks for fast turns, hairpins, S-sections, linked triples and long-straight exits.

## Netlify

Deploy the unpacked project as a static site with publish directory `.` and no build command. `index.html` must remain in the project root next to `css/`, `js/`, `assets/` and `manifest.webmanifest`.

## Garage categories and Porsche 911

The existing livery/shop architecture is retained for save compatibility. The car catalog now carries `category` metadata (`regular`, `sport`, `premium`); legacy entries default to `regular`. The Premium category adds `porsche-911` at exactly 40,000 CR. Its supplied top-down artwork is stored as optimized transparent WebP assets in `assets/cars/` and is rendered by the existing `Car` class as a visual sprite while keeping the same physics and collision footprint. Ownership and selection continue to use the existing `ownedLiveries` / `selectedLivery` save fields so older `velocityApex.v1` saves remain compatible.
