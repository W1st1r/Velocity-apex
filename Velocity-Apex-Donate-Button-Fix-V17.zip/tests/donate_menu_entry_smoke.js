const fs=require('fs');
const html=fs.readFileSync('public/index.html','utf8');
const mobile=fs.readFileSync('public/css/mobile-ui.css','utf8');
const payments=fs.readFileSync('public/js/payments.js','utf8');
function ok(v,msg){if(!v)throw new Error(msg)}
ok((html.match(/id="topupBtn"/g)||[]).length===1,'topupBtn must exist exactly once');
ok(html.includes('ДОНАТ · ПОПОЛНИТЬ CR'),'prominent donate label missing');
ok(html.indexOf('id="topupBtn"')<html.indexOf('menu-tools-section'),'donate entry must appear before quick access tools');
ok(mobile.includes('.topup-hero-btn'),'donate CTA mobile styles missing');
ok(payments.includes("openBtn.addEventListener('click',open)"),'donate CTA click binding missing');
console.log('donate_menu_entry_smoke: ok');
