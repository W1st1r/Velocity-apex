(function(){
  'use strict';
  const R=window.Racing=window.Racing||{};
  const clamp=R.clamp;
  const TAU=Math.PI*2;
  const angleWrap=a=>{while(a>Math.PI)a-=TAU;while(a<-Math.PI)a+=TAU;return a;};
  const moveToward=(v,target,amount)=>v<target?Math.min(target,v+amount):Math.max(target,v-amount);
  const DEBUG_COLLIDERS=false;

  // SAT helper for two car-oriented bounding boxes. The four candidate axes are
  // the local forward/right axes of each car; the smallest overlap is the MTV.
  function getCarOBB(car){
    const fx=Math.cos(car.angle),fy=Math.sin(car.angle),rx=-fy,ry=fx;
    const offset=car.collisionOffsetX||0;
    return {
      cx:car.x+fx*offset,cy:car.y+fy*offset,
      fx,fy,rx,ry,halfL:car.collisionLength*.5,halfW:car.collisionWidth*.5
    };
  }

  function intersectCarOBBs(a,b){
    const A=getCarOBB(a),B=getCarOBB(b),dx=B.cx-A.cx,dy=B.cy-A.cy;
    const axes=[[A.fx,A.fy],[A.rx,A.ry],[B.fx,B.fy],[B.rx,B.ry]];
    let depth=Infinity,nx=0,ny=0;
    for(const axis of axes){
      let ax=axis[0],ay=axis[1];
      const center=dx*ax+dy*ay;
      const ra=A.halfL*Math.abs(A.fx*ax+A.fy*ay)+A.halfW*Math.abs(A.rx*ax+A.ry*ay);
      const rb=B.halfL*Math.abs(B.fx*ax+B.fy*ay)+B.halfW*Math.abs(B.rx*ax+B.ry*ay);
      const overlap=ra+rb-Math.abs(center);
      if(overlap<=0)return null;
      if(overlap<depth){
        depth=overlap;
        if(center<0){ax=-ax;ay=-ay;}
        nx=ax;ny=ay;
      }
    }
    return {depth,nx,ny,cx:(A.cx+B.cx)*.5,cy:(A.cy+B.cy)*.5};
  }

  class Car{
    constructor(opts={}){
      this.id=opts.id||0;this.name=opts.name||('CAR '+this.id);this.player=!!opts.player;
      this.color=opts.color||'#ff4057';this.accent=opts.accent||'#ffffff';
      this.x=0;this.y=0;this.vx=0;this.vy=0;this.angle=0;this.speed=0;
      this.maxSpeed=opts.maxSpeed||338;this.baseMaxSpeed=this.maxSpeed;this.accel=opts.accel||174;this.brakePower=opts.brakePower||265;
      this.turnRate=opts.turnRate||2.18;this.radius=18;this.length=62;this.width=31;
      // Collision footprint follows the already-drawn car, including wings/tyres.
      // The drawing spans about x=-34..37 and y=-22..22, whose visual centre is +1.5px.
      this.collisionLength=71;this.collisionWidth=44;this.collisionOffsetX=1.5;
      this.collisionRadius=Math.hypot(this.collisionLength*.5,this.collisionWidth*.5);
      this.trackIndex=0;this.progress=0;this.prevProgress=0;this.laps=0;this.checkpoint=0;
      this.onRoad=true;this.offroadTime=0;this.collisionThisLap=false;this.offroadThisLap=false;
      this.lastImpact=0;this.steerVisual=0;this.throttleVisual=0;this.brakeVisual=0;
      this.ai=null;this.rank=1;this.finishedLap=false;
    }

    place(track,progress,lane=0){
      const p=track.sampleAtProgress(progress,lane);this.x=p.x;this.y=p.y;this.angle=Math.atan2(p.ty,p.tx);
      this.vx=p.tx*2;this.vy=p.ty*2;this.speed=2;this.progress=((progress%1)+1)%1;this.prevProgress=this.progress;
      this.trackIndex=p.index;this.laps=0;this.checkpoint=0;this.offroadTime=0;this.collisionThisLap=false;this.offroadThisLap=false;
    }

    update(dt,input,track){
      const steer=clamp(input.steer||0,-1,1),throttle=clamp(input.throttle||0,0,1),brake=clamp(input.brake||0,0,1);
      this.steerVisual+=(steer-this.steerVisual)*Math.min(1,dt*10);this.throttleVisual=throttle;this.brakeVisual=brake;

      const nearest=track.nearest(this.x,this.y,this.trackIndex);this.trackIndex=nearest.index;
      const roadHalf=track.roadWidth*.5;
      this.onRoad=Math.abs(nearest.signed)<roadHalf+4;
      if(!this.onRoad){this.offroadTime+=dt;this.offroadThisLap=true;}

      let mag=Math.hypot(this.vx,this.vy);
      const speedRatio=clamp(mag/Math.max(1,this.maxSpeed),0,1.15);

      // Steering is responsive at low/medium speed but progressively calmer at racing speed.
      // Keeping heading rotation separate from velocity is what gives the car believable inertia.
      const steerAtSpeed=.94-.66*Math.pow(clamp(speedRatio,0,1),.82);
      const lowSpeedAuthority=.42+.58*clamp(mag/48,0,1);
      const surfaceSteer=this.onRoad?1:.62;
      this.angle+=steer*this.turnRate*steerAtSpeed*lowSpeedAuthority*surfaceSteer*dt;

      const hx=Math.cos(this.angle),hy=Math.sin(this.angle),rx=-hy,ry=hx;
      let longitudinal=this.vx*hx+this.vy*hy;
      let lateral=this.vx*rx+this.vy*ry;

      // Strong launch, then a smooth torque falloff near vmax. Grass cuts available traction.
      const forwardRatio=clamp(Math.max(0,longitudinal)/Math.max(1,this.maxSpeed),0,1);
      const torqueCurve=Math.max(.52,1-.48*Math.pow(forwardRatio,1.35));
      const traction=this.onRoad?.52:.24;
      longitudinal+=this.accel*throttle*torqueCurve*traction*dt;

      // Brake is much stronger than coasting drag, but cannot stop the car instantly.
      if(brake>0){
        longitudinal=moveToward(longitudinal,0,this.brakePower*.78*brake*dt);
        lateral=moveToward(lateral,0,this.brakePower*.14*brake*dt);
      }

      // Rolling resistance + aerodynamic drag. The quadratic term dominates at high speed.
      const absLong=Math.abs(longitudinal);
      let dragDecel=2.4+.00033*absLong*absLong;
      if(!this.onRoad)dragDecel+=18+.00072*mag*mag;
      longitudinal=moveToward(longitudinal,0,dragDecel*dt);

      // Formula cars have high lateral grip, but not infinite grip. A hard high-speed steering
      // input briefly leaves lateral velocity (understeer/slide) before the tyres settle it.
      const steerLoad=Math.abs(steer)*clamp(speedRatio,0,1);
      let lateralGrip=this.onRoad?(7.6-3.6*steerLoad):1.85;
      if(brake>.55&&speedRatio>.5)lateralGrip*=.88;
      lateral*=Math.exp(-lateralGrip*dt);

      // Tyre scrub adds a small speed cost in demanding corners without creating permanent drift.
      const cornerScrub=(this.onRoad?9:4)*steerLoad*steerLoad;
      longitudinal=moveToward(longitudinal,0,cornerScrub*dt);

      this.vx=hx*longitudinal+rx*lateral;
      this.vy=hy*longitudinal+ry*lateral;
      mag=Math.hypot(this.vx,this.vy);

      // A soft overspeed limiter keeps numerical spikes contained without snapping velocity.
      const hardCap=this.maxSpeed*1.035;
      if(mag>hardCap){const s=hardCap/mag;this.vx*=s;this.vy*=s;mag=hardCap;}

      this.x+=this.vx*dt;this.y+=this.vy*dt;this.speed=mag;

      // Barriers: correct penetration, absorb energy, and use very low restitution to avoid pinball.
      const after=track.nearest(this.x,this.y,this.trackIndex);this.trackIndex=after.index;
      const barrier=roadHalf+20;
      let impact=0;
      if(Math.abs(after.signed)>barrier){
        const side=Math.sign(after.signed)||1,target=barrier*side;
        const excess=after.signed-target;
        this.x-=after.nx*excess;this.y-=after.ny*excess;
        const vn=this.vx*after.nx+this.vy*after.ny;
        if(vn*side>0){
          const hit=Math.abs(vn),restitution=.08;
          this.vx-=after.nx*vn*(1+restitution);this.vy-=after.ny*vn*(1+restitution);
          const loss=.94-.30*clamp(hit/180,0,1);
          this.vx*=loss;this.vy*=loss;impact=Math.min(1,hit/125);
        }
        this.collisionThisLap=true;this.lastImpact=impact;
        this.speed=Math.hypot(this.vx,this.vy);
      } else this.lastImpact=0;

      this._updateRaceProgress(after);
      return {nearest:after,impact};
    }

    _updateRaceProgress(n){
      const p=n.index/520;this.prevProgress=this.progress;this.progress=p;
      if(this.checkpoint===0&&p>.22&&p<.46)this.checkpoint=1;
      else if(this.checkpoint===1&&p>.47&&p<.70)this.checkpoint=2;
      else if(this.checkpoint===2&&p>.72&&p<.94)this.checkpoint=3;
      this.finishedLap=false;
      const forward=this.vx*n.tx+this.vy*n.ty>15;
      if(this.checkpoint===3&&this.prevProgress>.84&&p<.14&&forward){this.laps++;this.checkpoint=0;this.finishedLap=true;}
    }

    raceMetric(){return this.laps+this.progress;}

    draw(ctx,scale=1){
      ctx.save();ctx.translate(this.x,this.y);ctx.rotate(this.angle);ctx.scale(scale,scale);
      // Tires
      ctx.fillStyle='#090b0d';
      ctx.fillRect(-24,-20,17,9);ctx.fillRect(-24,11,17,9);ctx.fillRect(16,-19,15,8);ctx.fillRect(16,11,15,8);
      // Rear wing and endplates
      ctx.fillStyle=this.accent;ctx.fillRect(-31,-21,7,42);ctx.fillStyle='#111519';ctx.fillRect(-34,-22,4,44);
      // Main body
      ctx.fillStyle=this.color;ctx.beginPath();ctx.moveTo(-26,-10);ctx.lineTo(-12,-13);ctx.lineTo(3,-9);ctx.lineTo(29,-5);ctx.lineTo(34,0);ctx.lineTo(29,5);ctx.lineTo(3,9);ctx.lineTo(-12,13);ctx.lineTo(-26,10);ctx.closePath();ctx.fill();
      // Sidepods
      ctx.fillStyle=this.accent;ctx.globalAlpha=.92;ctx.beginPath();ctx.moveTo(-14,-15);ctx.lineTo(5,-13);ctx.lineTo(12,-7);ctx.lineTo(-11,-7);ctx.closePath();ctx.fill();
      ctx.beginPath();ctx.moveTo(-14,15);ctx.lineTo(5,13);ctx.lineTo(12,7);ctx.lineTo(-11,7);ctx.closePath();ctx.fill();ctx.globalAlpha=1;
      // Nose and front wing
      ctx.fillStyle=this.color;ctx.fillRect(22,-5,16,10);ctx.fillStyle=this.accent;ctx.fillRect(28,-20,5,40);ctx.fillStyle='#111519';ctx.fillRect(34,-18,3,36);
      // Cockpit / halo
      ctx.fillStyle='#0b1114';ctx.beginPath();ctx.ellipse(-2,0,9,6,0,0,TAU);ctx.fill();ctx.strokeStyle='rgba(255,255,255,.78)';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(-1,0,6,-2.4,2.4);ctx.stroke();
      ctx.fillStyle='#f5f7f7';ctx.beginPath();ctx.arc(-2,0,3.2,0,TAU);ctx.fill();
      if(DEBUG_COLLIDERS){
        ctx.strokeStyle='#00ff9c';ctx.lineWidth=1.5;ctx.globalAlpha=.9;
        ctx.strokeRect(this.collisionOffsetX-this.collisionLength*.5,-this.collisionWidth*.5,this.collisionLength,this.collisionWidth);
        ctx.globalAlpha=1;
      }
      ctx.restore();
    }
  }
  R.Car=Car;R.angleWrap=angleWrap;R.getCarOBB=getCarOBB;R.intersectCarOBBs=intersectCarOBBs;
})();
