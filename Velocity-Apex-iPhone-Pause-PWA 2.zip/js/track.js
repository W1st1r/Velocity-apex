(function () {
  'use strict';
  const R = window.Racing = window.Racing || {};

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;

  class Track {
    constructor() {
      this.roadWidth = 214;
      this.sampleCount = 520;
      this.points = [
        {x:-1240,y:40}, {x:-1120,y:-600}, {x:-560,y:-870}, {x:80,y:-810},
        {x:690,y:-905}, {x:1240,y:-560}, {x:1380,y:-20}, {x:1140,y:510},
        {x:610,y:790}, {x:20,y:690}, {x:-470,y:800}, {x:-940,y:560},
        {x:-1330,y:300}
      ];
      this.samples = [];
      this.length = 0;
      this._build();
    }

    _catmull(p0,p1,p2,p3,t) {
      const t2=t*t, t3=t2*t;
      return {
        x: .5*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),
        y: .5*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3)
      };
    }

    _build() {
      const n=this.points.length;
      const raw=[];
      const per=Math.ceil(this.sampleCount/n);
      for(let i=0;i<n;i++) {
        const p0=this.points[(i-1+n)%n], p1=this.points[i], p2=this.points[(i+1)%n], p3=this.points[(i+2)%n];
        for(let s=0;s<per;s++) raw.push(this._catmull(p0,p1,p2,p3,s/per));
      }
      raw.length=Math.min(raw.length,this.sampleCount);
      let cum=0;
      for(let i=0;i<raw.length;i++) {
        const a=raw[i], b=raw[(i+1)%raw.length];
        const dx=b.x-a.x, dy=b.y-a.y, seg=Math.hypot(dx,dy);
        const tx=dx/seg, ty=dy/seg;
        if(i>0) {
          const prev=raw[i-1]; cum += Math.hypot(a.x-prev.x,a.y-prev.y);
        }
        this.samples.push({x:a.x,y:a.y,tx,ty,nx:-ty,ny:tx,seg,cum,curve:0});
      }
      const last=raw[raw.length-1], first=raw[0];
      this.length=cum+Math.hypot(first.x-last.x,first.y-last.y);
      for(let i=0;i<this.samples.length;i++) {
        const a=this.samples[(i-4+this.samples.length)%this.samples.length];
        const b=this.samples[(i+4)%this.samples.length];
        const dot=clamp(a.tx*b.tx+a.ty*b.ty,-1,1);
        this.samples[i].curve=Math.acos(dot);
      }
    }

    sampleAtProgress(p, lane=0) {
      p=((p%1)+1)%1;
      const f=p*this.samples.length;
      const i=Math.floor(f)%this.samples.length, j=(i+1)%this.samples.length, t=f-i;
      const a=this.samples[i], b=this.samples[j];
      let tx=lerp(a.tx,b.tx,t), ty=lerp(a.ty,b.ty,t);
      const tl=Math.hypot(tx,ty)||1; tx/=tl; ty/=tl;
      const nx=-ty, ny=tx;
      return {x:lerp(a.x,b.x,t)+nx*lane,y:lerp(a.y,b.y,t)+ny*lane,tx,ty,nx,ny,index:i,curve:lerp(a.curve,b.curve,t)};
    }

    nearest(x,y,hint) {
      const n=this.samples.length;
      let bestI=0, bestD=Infinity;
      if(Number.isFinite(hint)) {
        const h=((hint%n)+n)%n;
        for(let o=-26;o<=26;o++) {
          const i=(h+o+n)%n, p=this.samples[i], dx=x-p.x,dy=y-p.y,d=dx*dx+dy*dy;
          if(d<bestD){bestD=d;bestI=i;}
        }
        if(bestD>260*260) return this.nearest(x,y,undefined);
      } else {
        for(let i=0;i<n;i++) {
          const p=this.samples[i], dx=x-p.x,dy=y-p.y,d=dx*dx+dy*dy;
          if(d<bestD){bestD=d;bestI=i;}
        }
      }
      const p=this.samples[bestI], dx=x-p.x,dy=y-p.y;
      return {
        index:bestI,
        progress:bestI/n,
        distance:Math.sqrt(bestD),
        signed:dx*p.nx+dy*p.ny,
        tx:p.tx,ty:p.ty,nx:p.nx,ny:p.ny,
        x:p.x,y:p.y,
        curve:p.curve
      };
    }

    _path(ctx, offset=0) {
      const s=this.samples;
      ctx.beginPath();
      const p0=s[0]; ctx.moveTo(p0.x+p0.nx*offset,p0.y+p0.ny*offset);
      for(let i=1;i<s.length;i++){const p=s[i];ctx.lineTo(p.x+p.nx*offset,p.y+p.ny*offset);} ctx.closePath();
    }

    draw(ctx) {
      // Large grass field and subtle mowing stripes.
      ctx.fillStyle='#174e2d'; ctx.fillRect(-2100,-1500,4200,3000);
      ctx.save(); ctx.globalAlpha=.11; ctx.strokeStyle='#b7e69c'; ctx.lineWidth=18;
      for(let y=-1500;y<1500;y+=90){ctx.beginPath();ctx.moveTo(-2100,y);ctx.lineTo(2100,y+260);ctx.stroke();}
      ctx.restore();

      // Runoff / barriers.
      this._path(ctx); ctx.lineWidth=this.roadWidth+42; ctx.strokeStyle='#d5d9d6'; ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth+27; ctx.strokeStyle='#3b4143'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth+12; ctx.strokeStyle='#171b1d'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth; ctx.strokeStyle='#303437'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth-8; ctx.strokeStyle='#34383a'; ctx.stroke();

      // Racing surface texture.
      ctx.save(); ctx.globalAlpha=.2; this._path(ctx); ctx.lineWidth=2; ctx.strokeStyle='#8d9696';ctx.stroke();
      ctx.setLineDash([18,34]); ctx.lineDashOffset=3; ctx.globalAlpha=.18;
      this._path(ctx,-this.roadWidth*.26);ctx.strokeStyle='#000';ctx.lineWidth=3;ctx.stroke();
      this._path(ctx,this.roadWidth*.26);ctx.stroke(); ctx.restore();

      // Red/white curbs, painted as short offset segments.
      const edge=this.roadWidth*.505;
      ctx.lineCap='butt';
      for(let side=-1;side<=1;side+=2){
        for(let i=0;i<this.samples.length;i+=4){
          const p=this.samples[i], q=this.samples[(i+4)%this.samples.length];
          ctx.beginPath();ctx.moveTo(p.x+p.nx*edge*side,p.y+p.ny*edge*side);ctx.lineTo(q.x+q.nx*edge*side,q.y+q.ny*edge*side);
          ctx.strokeStyle=((i/4)&1)?'#f4f4f0':'#e94b49';ctx.lineWidth=11;ctx.stroke();
        }
      }

      // Start/finish line.
      const st=this.samples[0], w=this.roadWidth*.48, rows=7, cols=2;
      ctx.save();ctx.translate(st.x,st.y);ctx.rotate(Math.atan2(st.ty,st.tx));
      for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
        ctx.fillStyle=((r+c)&1)?'#151719':'#f7f7f3';
        ctx.fillRect(-5+c*10,-w+r*(w*2/rows),10,w*2/rows+1);
      }
      ctx.restore();

      // Pit lane decoration alongside the main straight.
      ctx.save(); ctx.strokeStyle='#5d6365';ctx.lineWidth=36;ctx.lineCap='round';ctx.beginPath();
      for(let k=18;k<78;k++){
        const p=this.samples[k%this.samples.length], off=this.roadWidth*.72;
        const x=p.x+p.nx*off,y=p.y+p.ny*off; if(k===18)ctx.moveTo(x,y);else ctx.lineTo(x,y);
      }ctx.stroke();
      ctx.strokeStyle='#f0f0e7';ctx.lineWidth=2;ctx.setLineDash([12,9]);ctx.stroke();ctx.restore();

      // Trackside boards / trees - cheap geometric decoration.
      ctx.save();
      for(let i=20;i<this.samples.length;i+=34){
        const p=this.samples[i], side=((i/34)|0)%2?1:-1, off=this.roadWidth*.88+42;
        const x=p.x+p.nx*off*side,y=p.y+p.ny*off*side;
        ctx.fillStyle='#0c3620';ctx.beginPath();ctx.arc(x,y,24,0,Math.PI*2);ctx.fill();
        ctx.fillStyle='#24663a';ctx.beginPath();ctx.arc(x-5,y-7,16,0,Math.PI*2);ctx.fill();
      }
      ctx.restore();
    }
  }

  R.Track=Track;
  R.clamp=clamp;
  R.lerp=lerp;
})();
