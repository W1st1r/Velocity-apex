(function () {
  'use strict';
  const R = window.Racing = window.Racing || {};

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;

  class Track {
    constructor(config=R.TRACKS.apexCircuit) {
      this.config=config;this.id=config.id;this.theme=config.theme;this.roadWidth=config.roadWidth;
      this.points=config.points;this.samples=[];this.length=0;this._cache=null;
      this._build();
    }

    _catmull(p0,p1,p2,p3,t) {
      const t2=t*t, t3=t2*t;
      return {
        x: .5*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),
        y: .5*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3)
      };
    }

    _build() {
      // Sample the complete closed spline, then resample by arc length. Never truncate
      // its last segment: unequal control point spacing must not bias race progress.
      const raw=[],n=this.points.length;
      for(let i=0;i<n;i++)for(let k=0;k<80;k++)raw.push(this._catmull(this.points[(i+n-1)%n],this.points[i],this.points[(i+1)%n],this.points[(i+2)%n],k/80));
      raw.push({...raw[0]});
      let length=0;const cumulative=[0];
      for(let i=1;i<raw.length;i++){length+=Math.hypot(raw[i].x-raw[i-1].x,raw[i].y-raw[i-1].y);cumulative.push(length);}
      const scale=this.config.targetLength?this.config.targetLength/length:1;
      this.length=length*scale;this.sampleCount=Math.ceil(this.length/12);this.spacing=this.length/this.sampleCount;
      let j=0;
      for(let i=0;i<this.sampleCount;i++){
        const d=i*length/this.sampleCount;while(cumulative[j+1]<d)j++;
        const t=(d-cumulative[j])/(cumulative[j+1]-cumulative[j]);
        this.samples.push({x:lerp(raw[j].x,raw[j+1].x,t)*scale,y:lerp(raw[j].y,raw[j+1].y,t)*scale,cum:i*this.spacing,seg:this.spacing});
      }
      const a=this.samples,m=a.length;
      for(let i=0;i<m;i++){
        const prev=a[(i+m-1)%m],next=a[(i+1)%m],dx=next.x-prev.x,dy=next.y-prev.y,l=Math.hypot(dx,dy);
        Object.assign(a[i],{tx:dx/l,ty:dy/l,nx:-dy/l,ny:dx/l});
      }
      this.recommendedSpeed=[];this.racingLineOffset=[];
      for(let i=0;i<m;i++){
        const prev=a[(i+m-2)%m],next=a[(i+2)%m];
        const signed=Math.atan2(prev.tx*next.ty-prev.ty*next.tx,clamp(prev.tx*next.tx+prev.ty*next.ty,-1,1))/(4*this.spacing);
        a[i].curvature=signed;a[i].curve=Math.abs(signed)*8*this.spacing;
        this.recommendedSpeed[i]=Math.min(405,Math.sqrt(128/Math.max(.0001,Math.abs(signed))));
      }
      for(let i=0;i<m;i++){
        const current=a[i].curvature,approach=a[(i+Math.round(190/this.spacing))%m].curvature,exit=a[(i+m-Math.round(160/this.spacing))%m].curvature;
        this.racingLineOffset[i]=clamp((current*1.0-approach*.62-exit*.38)*7000,-this.roadWidth*.22,this.roadWidth*.22);
      }
      this.bounds={minX:Math.min(...a.map(p=>p.x))-380,minY:Math.min(...a.map(p=>p.y))-380,maxX:Math.max(...a.map(p=>p.x))+380,maxY:Math.max(...a.map(p=>p.y))+380};
    }

    sampleAtProgress(p, lane=0) {
      p=((p%1)+1)%1;
      const f=p*this.samples.length;
      const i=Math.floor(f)%this.samples.length, j=(i+1)%this.samples.length, t=f-i;
      const a=this.samples[i], b=this.samples[j];
      let tx=lerp(a.tx,b.tx,t), ty=lerp(a.ty,b.ty,t);
      const tl=Math.hypot(tx,ty)||1; tx/=tl; ty/=tl;
      const nx=-ty, ny=tx;
      return {x:lerp(a.x,b.x,t)+nx*lane,y:lerp(a.y,b.y,t)+ny*lane,tx,ty,nx,ny,index:i,curve:lerp(a.curve,b.curve,t)};
    }

    nearest(x,y,hint) {
      const n=this.samples.length;
      let bestI=0, bestD=Infinity;
      if(Number.isFinite(hint)) {
        const h=((hint%n)+n)%n;
        for(let o=-26;o<=26;o++) {
          const i=(h+o+n)%n, p=this.samples[i], dx=x-p.x,dy=y-p.y,d=dx*dx+dy*dy;
          if(d<bestD){bestD=d;bestI=i;}
        }
        if(bestD>260*260) return this.nearest(x,y,undefined);
      } else {
        for(let i=0;i<n;i++) {
          const p=this.samples[i], dx=x-p.x,dy=y-p.y,d=dx*dx+dy*dy;
          if(d<bestD){bestD=d;bestI=i;}
        }
      }
      const p=this.samples[bestI], dx=x-p.x,dy=y-p.y;
      return {
        index:bestI,
        progress:bestI/n,
        distance:Math.sqrt(bestD),
        signed:dx*p.nx+dy*p.ny,
        tx:p.tx,ty:p.ty,nx:p.nx,ny:p.ny,
        x:p.x,y:p.y,
        curve:p.curve
      };
    }

    _path(ctx, offset=0) {
      const s=this.samples;
      ctx.beginPath();
      const p0=s[0]; ctx.moveTo(p0.x+p0.nx*offset,p0.y+p0.ny*offset);
      for(let i=1;i<s.length;i++){const p=s[i];ctx.lineTo(p.x+p.nx*offset,p.y+p.ny*offset);} ctx.closePath();
    }

    draw(ctx) {
      // A single bounded static texture per active track keeps mobile frame cost low.
      if(!this._cache){
        const b=this.bounds,w=b.maxX-b.minX,h=b.maxY-b.minY;
        this.cacheScale=Math.min(.85,3072/w,2304/h);
        const c=document.createElement('canvas');c.width=Math.ceil(w*this.cacheScale);c.height=Math.ceil(h*this.cacheScale);
        const cx=c.getContext('2d');cx.scale(this.cacheScale,this.cacheScale);cx.translate(-b.minX,-b.minY);this._drawStatic(cx);this._cache=c;
      }
      const b=this.bounds;ctx.fillStyle=this.theme.ground;ctx.fillRect(b.minX-8000,b.minY-8000,16000,16000);
      ctx.drawImage(this._cache,b.minX,b.minY,this._cache.width/this.cacheScale,this._cache.height/this.cacheScale);
    }

    release(){if(this._cache){this._cache.width=this._cache.height=1;this._cache=null;}}

    _drawStatic(ctx) {
      // Large grass field and subtle mowing stripes.
      const b=this.bounds;ctx.fillStyle=this.theme.ground;ctx.fillRect(b.minX,b.minY,b.maxX-b.minX,b.maxY-b.minY);
      ctx.save();
      if(this.theme.kind==='circuit'){
        ctx.globalAlpha=.11;ctx.strokeStyle='#b7e69c';ctx.lineWidth=18;
        for(let y=b.minY;y<b.maxY;y+=90){ctx.beginPath();ctx.moveTo(b.minX,y);ctx.lineTo(b.maxX,y+260);ctx.stroke();}
      }else if(this.theme.kind==='neon'){
        ctx.strokeStyle='#26354e';ctx.lineWidth=3;
        for(let x=b.minX;x<b.maxX;x+=180)for(let y=b.minY;y<b.maxY;y+=160){ctx.fillStyle='#142237';ctx.fillRect(x+12,y+12,148,128);ctx.strokeRect(x+12,y+12,148,128);}
        this._path(ctx);ctx.strokeStyle='#256f91';ctx.lineWidth=this.roadWidth+62;ctx.globalAlpha=.45;ctx.stroke();
      }else if(this.theme.kind==='coast'){
        ctx.strokeStyle='#73d4db';ctx.globalAlpha=.19;ctx.lineWidth=2;
        for(let y=b.minY;y<b.maxY;y+=95){ctx.beginPath();for(let x=b.minX;x<b.maxX;x+=40)ctx.lineTo(x,y+Math.sin(x*.006+y)*10);ctx.stroke();}
        ctx.globalAlpha=1;this._path(ctx);ctx.lineWidth=this.roadWidth+160;ctx.strokeStyle='#94c6bc';ctx.stroke();
        this._path(ctx);ctx.lineWidth=this.roadWidth+122;ctx.strokeStyle='#a69f83';ctx.stroke();
        this._path(ctx);ctx.lineWidth=this.roadWidth+94;ctx.strokeStyle='#d2bd91';ctx.stroke();
      }else{
        ctx.globalAlpha=.17;ctx.strokeStyle=this.theme.kind==='desert'?'#683c2b':'#bccfcb';ctx.lineWidth=7;
        for(let i=0;i<18;i++){
          const x=b.minX+((i*937)%(b.maxX-b.minX)),y=b.minY+((i*541)%(b.maxY-b.minY));
          for(let k=0;k<3;k++){ctx.beginPath();ctx.ellipse(x,y,100+k*40,50+k*28,i*.7,0,Math.PI*2);ctx.stroke();}
        }
      }
      ctx.restore();

      // Runoff / barriers.
      this._path(ctx); ctx.lineWidth=this.roadWidth+42; ctx.strokeStyle=this.theme.barrier; ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth+27; ctx.strokeStyle='#3b4143'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth+12; ctx.strokeStyle='#171b1d'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth; ctx.strokeStyle='#303437'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth-8; ctx.strokeStyle=this.theme.road; ctx.stroke();

      // Racing surface texture.
      ctx.save(); ctx.globalAlpha=.2; this._path(ctx); ctx.lineWidth=2; ctx.strokeStyle='#8d9696';ctx.stroke();
      ctx.setLineDash([18,34]); ctx.lineDashOffset=3; ctx.globalAlpha=.18;
      this._path(ctx,-this.roadWidth*.26);ctx.strokeStyle='#000';ctx.lineWidth=3;ctx.stroke();
      this._path(ctx,this.roadWidth*.26);ctx.stroke(); ctx.restore();

      // Red/white curbs, painted as short offset segments.
      const edge=this.roadWidth*.505;
      ctx.lineCap='butt';
      for(let side=-1;side<=1;side+=2){
        for(let i=0;i<this.samples.length;i+=4){
          const p=this.samples[i], q=this.samples[(i+4)%this.samples.length];
          ctx.beginPath();ctx.moveTo(p.x+p.nx*edge*side,p.y+p.ny*edge*side);ctx.lineTo(q.x+q.nx*edge*side,q.y+q.ny*edge*side);
          ctx.strokeStyle=((i/4)&1)?'#f4f4f0':this.theme.curb;ctx.lineWidth=11;ctx.stroke();
        }
      }

      // Start/finish line.
      const st=this.samples[0], w=this.roadWidth*.48, rows=7, cols=2;
      ctx.save();ctx.translate(st.x,st.y);ctx.rotate(Math.atan2(st.ty,st.tx));
      for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
        ctx.fillStyle=((r+c)&1)?'#151719':'#f7f7f3';
        ctx.fillRect(-5+c*10,-w+r*(w*2/rows),10,w*2/rows+1);
      }
      ctx.restore();

      // Pit lane decoration alongside the main straight.
      if(this.theme.kind==='circuit'||this.theme.kind==='neon'){
      ctx.save(); ctx.strokeStyle='#5d6365';ctx.lineWidth=36;ctx.lineCap='round';ctx.beginPath();
      for(let k=18;k<78;k++){
        const p=this.samples[k%this.samples.length], off=this.roadWidth*.72;
        const x=p.x+p.nx*off,y=p.y+p.ny*off; if(k===18)ctx.moveTo(x,y);else ctx.lineTo(x,y);
      }ctx.stroke();
      ctx.strokeStyle='#f0f0e7';ctx.lineWidth=2;ctx.setLineDash([12,9]);ctx.stroke();ctx.restore();

      }

      // Deterministic geometric scenery, baked once with the road texture.
      ctx.save();
      for(let i=12;i<this.samples.length;i+=19){
        const p=this.samples[i],side=(i%2)?1:-1,off=this.roadWidth*.85+62;
        const x=p.x+p.nx*off*side,y=p.y+p.ny*off*side;
        if(this.nearest(x,y).distance<this.roadWidth*.64)continue;
        ctx.save();ctx.translate(x,y);ctx.rotate(Math.atan2(p.ty,p.tx));
        if(this.theme.kind==='neon'){
          ctx.fillStyle='#0a1224';ctx.fillRect(-34,-32,68,64);ctx.strokeStyle=i%3?'#31cfea':'#bc65ff';ctx.shadowColor=ctx.strokeStyle;ctx.shadowBlur=10;ctx.lineWidth=3;ctx.strokeRect(-34,-32,68,64);ctx.shadowBlur=0;
          ctx.fillStyle='#607caa';for(let k=-20;k<28;k+=12)ctx.fillRect(k,-23,4,45);
          ctx.fillStyle='#b9faff';ctx.fillRect(-3,45,6,6);
        }else if(this.theme.kind==='desert'||this.theme.kind==='alpine'){
          ctx.fillStyle=this.theme.kind==='desert'?'#875034':'#293e43';ctx.beginPath();ctx.moveTo(-37,29);ctx.lineTo(-27,-19);ctx.lineTo(12,-40);ctx.lineTo(42,4);ctx.lineTo(22,32);ctx.closePath();ctx.fill();
          ctx.fillStyle=this.theme.kind==='desert'?'#d89a62':'#e5eded';ctx.beginPath();ctx.moveTo(-27,-19);ctx.lineTo(12,-40);ctx.lineTo(30,-10);ctx.lineTo(5,-17);ctx.fill();
          if(this.theme.kind==='alpine'){ctx.fillStyle='#173e39';ctx.beginPath();ctx.moveTo(40,-50);ctx.lineTo(23,0);ctx.lineTo(57,0);ctx.fill();}
        }else if(this.theme.kind==='coast'){
          ctx.fillStyle='#cfbd92';ctx.beginPath();ctx.ellipse(0,0,56,35,0,0,Math.PI*2);ctx.fill();
          ctx.strokeStyle='#497768';ctx.lineWidth=5;for(let k=0;k<5;k++){const t=k*Math.PI*2/5;ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(Math.cos(t)*13,Math.sin(t)*13-10,Math.cos(t)*29,Math.sin(t)*29);ctx.stroke();}
          ctx.strokeStyle='#79d2d3';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,67,.2,2.6);ctx.stroke();
        }else{
          ctx.fillStyle='#0c3620';ctx.beginPath();ctx.arc(0,0,24,0,Math.PI*2);ctx.fill();ctx.fillStyle='#24663a';ctx.beginPath();ctx.arc(-5,-7,16,0,Math.PI*2);ctx.fill();
        }
        ctx.restore();
      }
      ctx.restore();
    }
  }

  R.Track=Track;
  R.clamp=clamp;
  R.lerp=lerp;
})();
