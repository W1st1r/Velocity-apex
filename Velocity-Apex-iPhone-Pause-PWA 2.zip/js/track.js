(function () {
  'use strict';
  const R = window.Racing = window.Racing || {};

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;

  class Track {
    constructor(config=R.TRACKS.apexCircuit) {
      this.config=config;this.id=config.id;this.theme=config.theme;this.roadWidth=config.roadWidth;
      this.points=config.points;this.samples=[];this.length=0;this._cache=null;
      this._build();
    }

    _catmull(p0,p1,p2,p3,t) {
      const t2=t*t, t3=t2*t;
      return {
        x: .5*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),
        y: .5*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3)
      };
    }

    _build() {
      // Sample the complete closed spline, then resample by arc length. Never truncate
      // its last segment: unequal control point spacing must not bias race progress.
      const raw=[],n=this.points.length;
      for(let i=0;i<n;i++)for(let k=0;k<80;k++)raw.push(this._catmull(this.points[(i+n-1)%n],this.points[i],this.points[(i+1)%n],this.points[(i+2)%n],k/80));
      raw.push({...raw[0]});
      let length=0;const cumulative=[0];
      for(let i=1;i<raw.length;i++){length+=Math.hypot(raw[i].x-raw[i-1].x,raw[i].y-raw[i-1].y);cumulative.push(length);}
      const scale=this.config.targetLength?this.config.targetLength/length:1;
      this.length=length*scale;this.sampleCount=Math.ceil(this.length/12);this.spacing=this.length/this.sampleCount;
      let j=0;
      for(let i=0;i<this.sampleCount;i++){
        const d=i*length/this.sampleCount;while(cumulative[j+1]<d)j++;
        const t=(d-cumulative[j])/(cumulative[j+1]-cumulative[j]);
        this.samples.push({x:lerp(raw[j].x,raw[j+1].x,t)*scale,y:lerp(raw[j].y,raw[j+1].y,t)*scale,cum:i*this.spacing,seg:this.spacing});
      }
      const a=this.samples,m=a.length;
      for(let i=0;i<m;i++){
        const prev=a[(i+m-1)%m],next=a[(i+1)%m],dx=next.x-prev.x,dy=next.y-prev.y,l=Math.hypot(dx,dy);
        Object.assign(a[i],{tx:dx/l,ty:dy/l,nx:-dy/l,ny:dx/l});
      }
      this.recommendedSpeed=[];this.racingLineOffset=[];this.lineCurvature=[];this._speedProfileCache=new Map();
      for(let i=0;i<m;i++){
        const prev=a[(i+m-2)%m],next=a[(i+2)%m];
        const signed=Math.atan2(prev.tx*next.ty-prev.ty*next.tx,clamp(prev.tx*next.tx+prev.ty*next.ty,-1,1))/(4*this.spacing);
        a[i].curvature=signed;a[i].curve=Math.abs(signed)*8*this.spacing;
      }
      this._buildRacingLine();
      this.bounds={minX:Math.min(...a.map(p=>p.x))-380,minY:Math.min(...a.map(p=>p.y))-380,maxX:Math.max(...a.map(p=>p.x))+380,maxY:Math.max(...a.map(p=>p.y))+380};
    }


    _buildRacingLine() {
      const s=this.samples,n=s.length,spacing=this.spacing;
      const maxOffset=Math.max(20,this.roadWidth*.5-30);
      const smooth=Array(n).fill(0),radius=Math.max(2,Math.round(42/spacing));
      for(let i=0;i<n;i++){
        let sum=0,wSum=0;
        for(let k=-radius;k<=radius;k++){
          const w=1-Math.abs(k)/(radius+1);sum+=s[(i+k+n)%n].curvature*w;wSum+=w;
        }
        smooth[i]=sum/wSum;
      }

      // Find real corner apices on the complete lap instead of reacting only to the
      // current sample. The influence lobes below encode approach -> apex -> exit;
      // overlapping lobes naturally compromise through linked corners and S-sections.
      const candidates=[],peakWindow=Math.max(2,Math.round(34/spacing));
      for(let i=0;i<n;i++){
        const mag=Math.abs(smooth[i]);if(mag<.00042)continue;
        let peak=true;
        for(let k=1;k<=peakWindow;k++)if(Math.abs(smooth[(i+k)%n])>mag||Math.abs(smooth[(i-k+n)%n])>mag){peak=false;break;}
        if(peak)candidates.push({i,mag,sign:Math.sign(smooth[i])||1});
      }
      candidates.sort((a,b)=>b.mag-a.mag);
      const apices=[];
      const circularDistance=(a,b)=>{const d=Math.abs(a-b);return Math.min(d,n-d)*spacing;};
      for(const c of candidates){
        if(apices.some(p=>circularDistance(p.i,c.i)<58&&p.sign===c.sign))continue;
        apices.push(c);
      }
      apices.sort((a,b)=>a.i-b.i);

      const raw=Array(n).fill(0),weight=Array(n).fill(0);
      const signedDistance=(from,to)=>{
        let d=(from-to)*spacing;const lap=this.length;
        if(d>lap*.5)d-=lap;else if(d<-lap*.5)d+=lap;return d;
      };
      for(const apex of apices){
        const severity=clamp((apex.mag-.00035)/.0042,.20,1);
        const reach=270;
        for(let k=-Math.ceil(reach/spacing);k<=Math.ceil(reach/spacing);k++){
          const i=(apex.i+k+n)%n,d=signedDistance(i,apex.i);
          const apexLobe=1.12*Math.exp(-(d*d)/(2*48*48));
          const approach=-.88*Math.exp(-((d+145)*(d+145))/(2*78*78));
          const exit=-.62*Math.exp(-((d-125)*(d-125))/(2*84*84));
          const shape=apexLobe+approach+exit;
          const w=Math.exp(-(d*d)/(2*170*170));
          raw[i]+=apex.sign*shape*severity*w;weight[i]+=Math.abs(shape)*severity*w;
        }
      }
      for(let i=0;i<n;i++){
        const normalized=weight[i]>1e-6?raw[i]/Math.max(.72,weight[i]):0;
        this.racingLineOffset[i]=clamp(normalized*maxOffset*1.32,-maxOffset,maxOffset);
      }

      // Low-pass the complete closed line. This is build-time work only and prevents
      // adjacent sample steering chatter on iPhone while preserving useful apex movement.
      for(let pass=0;pass<96;pass++){
        const prev=this.racingLineOffset.slice();
        for(let i=0;i<n;i++)this.racingLineOffset[i]=clamp(prev[i]*.56+(prev[(i-1+n)%n]+prev[(i+1)%n])*.22,-maxOffset,maxOffset);
      }

      const pts=Array(n);
      for(let i=0;i<n;i++){const p=s[i],o=this.racingLineOffset[i];pts[i]={x:p.x+p.nx*o,y:p.y+p.ny*o};}
      for(let i=0;i<n;i++){
        const p0=pts[(i-2+n)%n],p1=pts[i],p2=pts[(i+2)%n];
        const ax=p1.x-p0.x,ay=p1.y-p0.y,bx=p2.x-p1.x,by=p2.y-p1.y;
        const al=Math.hypot(ax,ay)||1,bl=Math.hypot(bx,by)||1;
        const cross=(ax/al)*(by/bl)-(ay/al)*(bx/bl),dot=clamp((ax/al)*(bx/bl)+(ay/al)*(by/bl),-1,1);
        const ds=Math.max(1,(al+bl)*.5);
        const curvature=Math.atan2(cross,dot)/ds;
        this.lineCurvature[i]=curvature;
        // Formula-style speed limit: mechanical grip plus speed-squared downforce.
        // v^2*k <= base + aero*v^2  =>  v <= sqrt(base/(k-aero)).
        const kAbs=Math.abs(curvature),baseLat=150,aero=.00145;
        this.recommendedSpeed[i]=kAbs<=aero?405:Math.min(405,Math.sqrt(baseLat/Math.max(.00012,kAbs-aero)));
      }
    }

    getSpeedProfile(car,opts={}) {
      const grip=clamp(opts.gripUsage??.94,.65,1),brakeUse=clamp(opts.brakeUsage??.92,.55,1),accelUse=clamp(opts.accelUsage??.94,.55,1);
      const pace=clamp(opts.pace??1,.72,1),key=[Math.round(car.maxSpeed),Math.round(car.accel),Math.round(car.brakePower),grip.toFixed(3),brakeUse.toFixed(3),accelUse.toFixed(3),pace.toFixed(3)].join(':');
      const cached=this._speedProfileCache.get(key);if(cached)return cached;
      const n=this.samples.length,profile=Array(n),cap=car.maxSpeed*pace;
      for(let i=0;i<n;i++)profile[i]=Math.min(cap,this.recommendedSpeed[i]*grip);
      const brake=Math.max(40,car.brakePower*.80*brakeUse),accel=Math.max(30,car.accel*.84*accelUse),ds=this.spacing;
      // Repeated closed-loop forward/backward passes propagate braking zones before
      // apices and acceleration limits after them without per-frame global work.
      for(let pass=0;pass<4;pass++){
        for(let i=n-1;i>=0;i--){const next=(i+1)%n;profile[i]=Math.min(profile[i],Math.sqrt(profile[next]*profile[next]+2*brake*ds));}
        for(let i=0;i<n;i++){const prev=(i-1+n)%n;profile[i]=Math.min(profile[i],Math.sqrt(profile[prev]*profile[prev]+2*accel*ds));}
      }
      this._speedProfileCache.set(key,profile);return profile;
    }

    sampleAtProgress(p, lane=0) {
      p=((p%1)+1)%1;
      const f=p*this.samples.length;
      const i=Math.floor(f)%this.samples.length, j=(i+1)%this.samples.length, t=f-i;
      const a=this.samples[i], b=this.samples[j];
      let tx=lerp(a.tx,b.tx,t), ty=lerp(a.ty,b.ty,t);
      const tl=Math.hypot(tx,ty)||1; tx/=tl; ty/=tl;
      const nx=-ty, ny=tx;
      return {x:lerp(a.x,b.x,t)+nx*lane,y:lerp(a.y,b.y,t)+ny*lane,tx,ty,nx,ny,index:i,curve:lerp(a.curve,b.curve,t)};
    }

    nearest(x,y,hint) {
      const n=this.samples.length;
      let bestI=0, bestD=Infinity;
      if(Number.isFinite(hint)) {
        const h=((hint%n)+n)%n;
        for(let o=-26;o<=26;o++) {
          const i=(h+o+n)%n, p=this.samples[i], dx=x-p.x,dy=y-p.y,d=dx*dx+dy*dy;
          if(d<bestD){bestD=d;bestI=i;}
        }
        if(bestD>260*260) return this.nearest(x,y,undefined);
      } else {
        for(let i=0;i<n;i++) {
          const p=this.samples[i], dx=x-p.x,dy=y-p.y,d=dx*dx+dy*dy;
          if(d<bestD){bestD=d;bestI=i;}
        }
      }
      const p=this.samples[bestI], dx=x-p.x,dy=y-p.y;
      return {
        index:bestI,
        progress:bestI/n,
        distance:Math.sqrt(bestD),
        signed:dx*p.nx+dy*p.ny,
        tx:p.tx,ty:p.ty,nx:p.nx,ny:p.ny,
        x:p.x,y:p.y,
        curve:p.curve
      };
    }

    _path(ctx, offset=0) {
      const s=this.samples;
      ctx.beginPath();
      const p0=s[0]; ctx.moveTo(p0.x+p0.nx*offset,p0.y+p0.ny*offset);
      for(let i=1;i<s.length;i++){const p=s[i];ctx.lineTo(p.x+p.nx*offset,p.y+p.ny*offset);} ctx.closePath();
    }

    draw(ctx) {
      // A single bounded static texture per active track keeps mobile frame cost low.
      if(!this._cache){
        const b=this.bounds,w=b.maxX-b.minX,h=b.maxY-b.minY;
        this.cacheScale=Math.min(.85,3072/w,2304/h);
        const c=document.createElement('canvas');c.width=Math.ceil(w*this.cacheScale);c.height=Math.ceil(h*this.cacheScale);
        const cx=c.getContext('2d');cx.scale(this.cacheScale,this.cacheScale);cx.translate(-b.minX,-b.minY);this._drawStatic(cx);this._cache=c;
      }
      const b=this.bounds;ctx.fillStyle=this.theme.ground;ctx.fillRect(b.minX-8000,b.minY-8000,16000,16000);
      ctx.drawImage(this._cache,b.minX,b.minY,this._cache.width/this.cacheScale,this._cache.height/this.cacheScale);
    }

    release(){if(this._cache){this._cache.width=this._cache.height=1;this._cache=null;}}

    _drawGroundDetails(ctx) {
      const b=this.bounds,kind=this.theme.kind;
      let seed=2166136261;
      for(let i=0;i<kind.length;i++)seed=Math.imul(seed^kind.charCodeAt(i),16777619)>>>0;
      const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
      ctx.save();
      for(let i=0;i<115;i++){
        const x=lerp(b.minX,b.maxX,rand()),y=lerp(b.minY,b.maxY,rand());
        if(this.nearest(x,y).distance<this.roadWidth*.78)continue;
        const a=.035+rand()*.055,size=4+rand()*15;ctx.globalAlpha=a;
        if(kind==='desert'){
          ctx.strokeStyle=rand()>.5?'#ffe0ac':'#6f432e';ctx.lineWidth=1+rand()*2;ctx.beginPath();ctx.ellipse(x,y,size*2.2,size*.55,rand()*Math.PI,0,Math.PI*2);ctx.stroke();
        }else if(kind==='alpine'){
          ctx.fillStyle=rand()>.42?'#dbe7e5':'#183b35';ctx.beginPath();ctx.moveTo(x,y-size*1.7);ctx.lineTo(x-size*.8,y+size);ctx.lineTo(x+size*.8,y+size);ctx.closePath();ctx.fill();
        }else if(kind==='coast'){
          ctx.strokeStyle=rand()>.5?'#bfe9df':'#0f5965';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x,y,size*1.6,.15,2.7);ctx.stroke();
        }else if(kind==='neon'){
          ctx.fillStyle=rand()>.55?'#2f8fa0':'#7550aa';ctx.fillRect(x-size*.5,y-size*.5,1.5+rand()*3,1.5+rand()*3);
        }else{
          ctx.fillStyle=rand()>.5?'#9fd47e':'#092f1c';ctx.beginPath();ctx.ellipse(x,y,size*1.4,size*.45,rand()*Math.PI,0,Math.PI*2);ctx.fill();
        }
      }
      ctx.restore();
    }

    _drawAsphaltDetails(ctx) {
      const s=this.samples,n=s.length;
      ctx.save();ctx.lineCap='round';
      // Fine deterministic aggregate: points live on the road, so no clipping path is needed.
      for(let i=0;i<n;i+=4){
        const p=s[i],phase=Math.sin(i*12.9898)*43758.5453,unit=phase-Math.floor(phase),offset=(unit-.5)*this.roadWidth*.68;
        const x=p.x+p.nx*offset,y=p.y+p.ny*offset,len=3+(i%5);ctx.globalAlpha=.07+(i%3)*.015;ctx.strokeStyle=(i&4)?'#d7dcda':'#080a0b';ctx.lineWidth=.7+(i%2)*.45;
        ctx.beginPath();ctx.moveTo(x-p.tx*len,y-p.ty*len);ctx.lineTo(x+p.tx*len,y+p.ty*len);ctx.stroke();
      }
      // Baked braking/skid traces in the most loaded corners.
      ctx.strokeStyle='#070809';ctx.lineWidth=2.1;ctx.globalAlpha=.15;
      for(let i=0;i<n;i+=6){
        const p=s[i];if(p.curve<.34)continue;
        const q=s[(i+5)%n],line=this.racingLineOffset[i]*.7;
        for(let tyre=-1;tyre<=1;tyre+=2){
          const off=line+tyre*13;ctx.beginPath();ctx.moveTo(p.x+p.nx*off-p.tx*9,p.y+p.ny*off-p.ty*9);ctx.lineTo(q.x+q.nx*off+q.tx*8,q.y+q.ny*off+q.ty*8);ctx.stroke();
        }
      }
      ctx.restore();
    }

    _drawStatic(ctx) {
      // Large grass field and subtle mowing stripes.
      const b=this.bounds;ctx.fillStyle=this.theme.ground;ctx.fillRect(b.minX,b.minY,b.maxX-b.minX,b.maxY-b.minY);
      ctx.save();
      if(this.theme.kind==='circuit'){
        ctx.globalAlpha=.11;ctx.strokeStyle='#b7e69c';ctx.lineWidth=18;
        for(let y=b.minY;y<b.maxY;y+=90){ctx.beginPath();ctx.moveTo(b.minX,y);ctx.lineTo(b.maxX,y+260);ctx.stroke();}
      }else if(this.theme.kind==='neon'){
        ctx.strokeStyle='#26354e';ctx.lineWidth=3;
        for(let x=b.minX;x<b.maxX;x+=180)for(let y=b.minY;y<b.maxY;y+=160){ctx.fillStyle='#142237';ctx.fillRect(x+12,y+12,148,128);ctx.strokeRect(x+12,y+12,148,128);}
        this._path(ctx);ctx.strokeStyle='#256f91';ctx.lineWidth=this.roadWidth+62;ctx.globalAlpha=.45;ctx.stroke();
      }else if(this.theme.kind==='coast'){
        ctx.strokeStyle='#73d4db';ctx.globalAlpha=.19;ctx.lineWidth=2;
        for(let y=b.minY;y<b.maxY;y+=95){ctx.beginPath();for(let x=b.minX;x<b.maxX;x+=40)ctx.lineTo(x,y+Math.sin(x*.006+y)*10);ctx.stroke();}
        ctx.globalAlpha=1;this._path(ctx);ctx.lineWidth=this.roadWidth+160;ctx.strokeStyle='#94c6bc';ctx.stroke();
        this._path(ctx);ctx.lineWidth=this.roadWidth+122;ctx.strokeStyle='#a69f83';ctx.stroke();
        this._path(ctx);ctx.lineWidth=this.roadWidth+94;ctx.strokeStyle='#d2bd91';ctx.stroke();
      }else{
        ctx.globalAlpha=.17;ctx.strokeStyle=this.theme.kind==='desert'?'#683c2b':'#bccfcb';ctx.lineWidth=7;
        for(let i=0;i<18;i++){
          const x=b.minX+((i*937)%(b.maxX-b.minX)),y=b.minY+((i*541)%(b.maxY-b.minY));
          for(let k=0;k<3;k++){ctx.beginPath();ctx.ellipse(x,y,100+k*40,50+k*28,i*.7,0,Math.PI*2);ctx.stroke();}
        }
      }
      ctx.restore();
      this._drawGroundDetails(ctx);

      // Runoff / barriers. A broad baked shadow gives walls and shoulders more depth.
      ctx.save();ctx.globalAlpha=.18;this._path(ctx);ctx.lineWidth=this.roadWidth+58;ctx.strokeStyle='#050708';ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();ctx.restore();
      this._path(ctx); ctx.lineWidth=this.roadWidth+42; ctx.strokeStyle=this.theme.barrier; ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth+27; ctx.strokeStyle='#3b4143'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth+12; ctx.strokeStyle='#171b1d'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth; ctx.strokeStyle='#303437'; ctx.stroke();
      this._path(ctx); ctx.lineWidth=this.roadWidth-8; ctx.strokeStyle=this.theme.road; ctx.stroke();

      // Racing surface texture.
      ctx.save(); ctx.globalAlpha=.2; this._path(ctx); ctx.lineWidth=2; ctx.strokeStyle='#8d9696';ctx.stroke();
      ctx.setLineDash([18,34]); ctx.lineDashOffset=3; ctx.globalAlpha=.18;
      this._path(ctx,-this.roadWidth*.26);ctx.strokeStyle='#000';ctx.lineWidth=3;ctx.stroke();
      this._path(ctx,this.roadWidth*.26);ctx.stroke(); ctx.restore();
      this._drawAsphaltDetails(ctx);

      // Red/white curbs, with a dark lower edge and a fine highlight for more volume.
      const edge=this.roadWidth*.505;
      ctx.save();ctx.globalAlpha=.24;ctx.strokeStyle='#060708';ctx.lineWidth=15;ctx.lineCap='round';this._path(ctx,-edge);ctx.stroke();this._path(ctx,edge);ctx.stroke();ctx.restore();
      ctx.lineCap='butt';
      for(let side=-1;side<=1;side+=2){
        for(let i=0;i<this.samples.length;i+=4){
          const p=this.samples[i], q=this.samples[(i+4)%this.samples.length];
          ctx.beginPath();ctx.moveTo(p.x+p.nx*edge*side,p.y+p.ny*edge*side);ctx.lineTo(q.x+q.nx*edge*side,q.y+q.ny*edge*side);
          ctx.strokeStyle=((i/4)&1)?'#f4f4f0':this.theme.curb;ctx.lineWidth=11;ctx.stroke();
          ctx.globalAlpha=.28;ctx.strokeStyle='#fff';ctx.lineWidth=1.2;ctx.stroke();ctx.globalAlpha=1;
        }
      }

      // Start/finish line.
      const st=this.samples[0], w=this.roadWidth*.48, rows=7, cols=2;
      ctx.save();ctx.translate(st.x,st.y);ctx.rotate(Math.atan2(st.ty,st.tx));
      for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
        ctx.fillStyle=((r+c)&1)?'#151719':'#f7f7f3';
        ctx.fillRect(-5+c*10,-w+r*(w*2/rows),10,w*2/rows+1);
      }
      ctx.restore();

      // Pit lane decoration alongside the main straight.
      if(this.theme.kind==='circuit'||this.theme.kind==='neon'){
      ctx.save(); ctx.strokeStyle='#5d6365';ctx.lineWidth=36;ctx.lineCap='round';ctx.beginPath();
      for(let k=18;k<78;k++){
        const p=this.samples[k%this.samples.length], off=this.roadWidth*.72;
        const x=p.x+p.nx*off,y=p.y+p.ny*off; if(k===18)ctx.moveTo(x,y);else ctx.lineTo(x,y);
      }ctx.stroke();
      ctx.strokeStyle='#f0f0e7';ctx.lineWidth=2;ctx.setLineDash([12,9]);ctx.stroke();ctx.restore();

      }

      // Deterministic geometric scenery, baked once with the road texture.
      ctx.save();
      for(let i=12;i<this.samples.length;i+=19){
        const p=this.samples[i],side=(i%2)?1:-1,off=this.roadWidth*.85+62;
        const x=p.x+p.nx*off*side,y=p.y+p.ny*off*side;
        if(this.nearest(x,y).distance<this.roadWidth*.64)continue;
        ctx.save();ctx.translate(x,y);ctx.rotate(Math.atan2(p.ty,p.tx));
        if(this.theme.kind==='neon'){
          ctx.fillStyle='#0a1224';ctx.fillRect(-34,-32,68,64);ctx.strokeStyle=i%3?'#31cfea':'#bc65ff';ctx.shadowColor=ctx.strokeStyle;ctx.shadowBlur=10;ctx.lineWidth=3;ctx.strokeRect(-34,-32,68,64);ctx.shadowBlur=0;
          ctx.fillStyle='#607caa';for(let k=-20;k<28;k+=12)ctx.fillRect(k,-23,4,45);
          ctx.fillStyle='#b9faff';ctx.fillRect(-3,45,6,6);
        }else if(this.theme.kind==='desert'||this.theme.kind==='alpine'){
          ctx.fillStyle=this.theme.kind==='desert'?'#875034':'#293e43';ctx.beginPath();ctx.moveTo(-37,29);ctx.lineTo(-27,-19);ctx.lineTo(12,-40);ctx.lineTo(42,4);ctx.lineTo(22,32);ctx.closePath();ctx.fill();
          ctx.fillStyle=this.theme.kind==='desert'?'#d89a62':'#e5eded';ctx.beginPath();ctx.moveTo(-27,-19);ctx.lineTo(12,-40);ctx.lineTo(30,-10);ctx.lineTo(5,-17);ctx.fill();
          if(this.theme.kind==='alpine'){ctx.fillStyle='#173e39';ctx.beginPath();ctx.moveTo(40,-50);ctx.lineTo(23,0);ctx.lineTo(57,0);ctx.fill();}
        }else if(this.theme.kind==='coast'){
          ctx.fillStyle='#cfbd92';ctx.beginPath();ctx.ellipse(0,0,56,35,0,0,Math.PI*2);ctx.fill();
          ctx.strokeStyle='#497768';ctx.lineWidth=5;for(let k=0;k<5;k++){const t=k*Math.PI*2/5;ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(Math.cos(t)*13,Math.sin(t)*13-10,Math.cos(t)*29,Math.sin(t)*29);ctx.stroke();}
          ctx.strokeStyle='#79d2d3';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,67,.2,2.6);ctx.stroke();
        }else{
          ctx.fillStyle='#0c3620';ctx.beginPath();ctx.arc(0,0,24,0,Math.PI*2);ctx.fill();ctx.fillStyle='#24663a';ctx.beginPath();ctx.arc(-5,-7,16,0,Math.PI*2);ctx.fill();
        }
        ctx.restore();
      }
      ctx.restore();
    }
  }

  R.Track=Track;
  R.clamp=clamp;
  R.lerp=lerp;
})();
