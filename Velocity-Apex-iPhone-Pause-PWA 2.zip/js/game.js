(function(){
  'use strict';
  const R=window.Racing, clamp=R.clamp, lerp=R.lerp;
  const $=id=>document.getElementById(id);
  const canvas=$('game'),ctx=canvas.getContext('2d',{alpha:false,desynchronized:true});

  const UI={
    menu:$('menu'),play:$('playBtn'),menuBestScore:$('menuBestScore'),menuBestLap:$('menuBestLap'),menuMaxLaps:$('menuMaxLaps'),menuMute:$('menuMute'),
    countdown:$('countdown'),hud:$('hud'),pos:$('posText'),lap:$('lapText'),speed:$('speedText'),score:$('scoreText'),lapTime:$('lapTime'),bestLap:$('bestLap'),
    controls:$('controls'),pauseBtn:$('pauseBtn'),pause:$('pause'),continueBtn:$('continueBtn'),restartBtn:$('restartBtn'),mainMenuBtn:$('mainMenuBtn'),pauseMute:$('pauseMute'),toasts:$('toastLayer')
  };

  const STORAGE='velocityApex.v1';
  const palette=[
    ['#80ff44','#f5f5ed'],['#ff405f','#ffe45d'],['#3bb8ff','#f7f7f1'],['#9c63ff','#ff66c4'],['#ff8a34','#fff1d8'],['#21d7c5','#eaffff'],['#f5d94d','#20252b'],
    ['#e9edf2','#ec3c50'],['#ff5be7','#d7ff43'],['#6d7cff','#f2f2ff'],['#36dd6f','#13252b'],['#ff6548','#72e9ff'],['#d8ff4f','#4b2eff'],['#f0a4ff','#272a31']
  ];

  function loadSave(){
    try{const d=JSON.parse(localStorage.getItem(STORAGE)||'{}');return{bestScore:+d.bestScore||0,bestLap:+d.bestLap||0,maxLaps:+d.maxLaps||0,muted:!!d.muted};}
    catch(e){return{bestScore:0,bestLap:0,maxLaps:0,muted:false};}
  }
  function writeSave(){try{localStorage.setItem(STORAGE,JSON.stringify(save));}catch(e){}}
  function fmt(ms){
    if(!ms||!isFinite(ms))return'--:--.---';
    const m=Math.floor(ms/60000),s=Math.floor(ms/1000)%60,x=Math.floor(ms%1000);
    return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')+'.'+String(x).padStart(3,'0');
  }
  const save=loadSave();
  const audio=new R.AudioSystem();audio.setMuted(save.muted);
  const track=new R.Track();

  let W=innerWidth,H=innerHeight,DPR=1,last=performance.now(),state='menu',raceTime=0,lapTime=0,score=0,scoreCarry=0;
  let cars=[],player=null,demoCars=[],demoT=0,prevRank=14,shake=0,impactCooldown=0,grassSoundCooldown=0,countdownToken=0;
  let cam={x:0,y:0,rot:0,zoom:.65};
  const input={left:false,right:false,gas:false,brake:false};
  const particles=Array.from({length:190},()=>({active:false,x:0,y:0,vx:0,vy:0,life:0,max:1,size:2,type:'dust'}));
  let pCursor=0;
  const skid=Array.from({length:220},()=>({active:false,x1:0,y1:0,x2:0,y2:0,life:0}));let skidCursor=0,skidTick=0;

  function resize(){
    W=Math.max(1,innerWidth);H=Math.max(1,innerHeight);DPR=Math.min(window.devicePixelRatio||1,2);
    canvas.width=Math.round(W*DPR);canvas.height=Math.round(H*DPR);canvas.style.width=W+'px';canvas.style.height=H+'px';ctx.setTransform(DPR,0,0,DPR,0,0);
  }
  resize();addEventListener('resize',resize,{passive:true});addEventListener('orientationchange',()=>setTimeout(resize,100),{passive:true});

  function initDemo(){
    demoCars=[];for(let i=0;i<7;i++){const c=new R.Car({id:i,color:palette[i][0],accent:palette[i][1]});c.demoOffset=i/7;demoCars.push(c);}
  }
  initDemo();

  function updateMenuStats(){UI.menuBestScore.textContent=Math.floor(save.bestScore).toLocaleString();UI.menuBestLap.textContent=fmt(save.bestLap);UI.menuMaxLaps.textContent=save.maxLaps;UI.menuMute.textContent=save.muted?'SOUND OFF':'SOUND ON';UI.pauseMute.textContent=save.muted?'SOUND OFF':'SOUND ON';}
  updateMenuStats();

  // Use pointer/touch release directly for game UI taps. In iOS Safari a synthetic
  // click can be cancelled when another finger is holding a control or touchmove is
  // prevented, so relying on click alone makes Pause/Continue feel intermittent.
  function bindTap(el,handler){
    let activePointer=null,lastHandled=-Infinity,touchActive=false;
    if(window.PointerEvent){
      el.addEventListener('pointerdown',e=>{
        if(e.pointerType==='mouse'&&e.button!==0)return;
        activePointer=e.pointerId;
        try{el.setPointerCapture(e.pointerId);}catch(_){}
      });
      el.addEventListener('pointerup',e=>{
        if(activePointer!==e.pointerId)return;
        activePointer=null;e.preventDefault();lastHandled=performance.now();handler(e);
      });
      el.addEventListener('pointercancel',e=>{if(activePointer===e.pointerId)activePointer=null;});
      el.addEventListener('lostpointercapture',e=>{if(activePointer===e.pointerId)activePointer=null;});
    }else{
      el.addEventListener('touchstart',()=>{touchActive=true;},{passive:true});
      el.addEventListener('touchend',e=>{if(!touchActive)return;touchActive=false;e.preventDefault();lastHandled=performance.now();handler(e);},{passive:false});
      el.addEventListener('touchcancel',()=>{touchActive=false;},{passive:true});
    }
    // Keyboard/assistive activation still arrives as click. Suppress only the
    // compatibility click generated after a pointer/touch release we handled.
    el.addEventListener('click',e=>{
      if(performance.now()-lastHandled<700){e.preventDefault();return;}
      handler(e);
    });
  }

  function setMute(v){save.muted=v;audio.setMuted(v);writeSave();updateMenuStats();}
  bindTap(UI.menuMute,()=>{audio.init();setMute(!save.muted);});
  bindTap(UI.pauseMute,()=>setMute(!save.muted));

  function createCars(){
    cars=[];
    const names=['NOVA','VECTOR','PULSE','KITE','EMBER','VOLT','RIFT','ION','COMET','ARC','ZENITH','FLUX','NEON','APEX'];
    const playerGrid=7;
    for(let i=0;i<14;i++){
      const isPlayer=i===playerGrid;
      const c=new R.Car({id:i,name:isPlayer?'YOU':names[i],player:isPlayer,color:palette[i][0],accent:palette[i][1],maxSpeed:isPlayer?352:316+Math.random()*31,accel:isPlayer?184:164+Math.random()*26,brakePower:isPlayer?282:240+Math.random()*45,turnRate:isPlayer?2.25:2.04+Math.random()*.25});
      const row=i,prog=.025+row*.0062,lane=(row%2===0?-1:1)*(25+(row%3)*4);
      c.place(track,prog,lane);
      if(!isPlayer){c.ai=new R.AIController(c,i);}
      else player=c;
      cars.push(c);
    }
    prevRank=14;cam.x=player.x;cam.y=player.y;cam.rot=-Math.PI/2-player.angle;lapTime=0;raceTime=0;score=0;scoreCarry=0;shake=0;
    UI.toasts.replaceChildren();particles.forEach(p=>p.active=false);skid.forEach(s=>s.active=false);
  }

  function resetInput(){input.left=input.right=input.gas=input.brake=false;}
  function setPauseButton(enabled,visible=true){
    UI.pauseBtn.disabled=!enabled;
    UI.pauseBtn.classList.toggle('hidden',!visible);
    UI.pauseBtn.setAttribute('aria-hidden',visible?'false':'true');
  }
  function showRaceUI(show){UI.hud.classList.toggle('hidden',!show);UI.controls.classList.toggle('hidden',!show);if(!show)setPauseButton(false,false);}
  function startRace(){
    audio.init();resetInput();createCars();state='countdown';UI.menu.classList.add('hidden');UI.pause.classList.add('hidden');showRaceUI(true);setPauseButton(false,false);runCountdown();
  }
  function runCountdown(){
    const token=++countdownToken;const seq=['3','2','1','GO!'];let i=0;UI.countdown.classList.remove('hidden');
    const step=()=>{if(token!==countdownToken)return;UI.countdown.textContent=seq[i];UI.countdown.style.animation='none';void UI.countdown.offsetWidth;UI.countdown.style.animation='countPop .52s ease';audio.countdown(i===3?0:3-i);i++;if(i<seq.length)setTimeout(step,650);else setTimeout(()=>{if(token!==countdownToken)return;UI.countdown.classList.add('hidden');state='racing';setPauseButton(true,true);last=performance.now();},570);};step();
  }
  function persistRecords(){save.bestScore=Math.max(save.bestScore,Math.floor(score));if(player)save.maxLaps=Math.max(save.maxLaps,player.laps);writeSave();updateMenuStats();}
  function pauseRace(){
    if(state!=='racing')return;
    state='paused';resetInput();persistRecords();audio.updateEngine(0,0,false);setPauseButton(false,true);UI.pause.classList.remove('hidden');UI.controls.classList.add('hidden');
  }
  function continueRace(){
    if(state!=='paused')return;
    resetInput();audio.init();state='racing';UI.pause.classList.add('hidden');UI.controls.classList.remove('hidden');setPauseButton(true,true);last=performance.now();
    if(player)audio.updateEngine(player.speed,0,true);
  }
  function restartRace(){countdownToken++;resetInput();audio.updateEngine(0,0,false);UI.pause.classList.add('hidden');startRace();}
  function mainMenu(){countdownToken++;resetInput();persistRecords();state='menu';audio.updateEngine(0,0,false);UI.pause.classList.add('hidden');UI.countdown.classList.add('hidden');UI.menu.classList.remove('hidden');UI.toasts.replaceChildren();showRaceUI(false);updateMenuStats();}
  bindTap(UI.play,startRace);bindTap(UI.pauseBtn,pauseRace);bindTap(UI.continueBtn,continueRace);bindTap(UI.restartBtn,restartRace);bindTap(UI.mainMenuBtn,mainMenu);

  function bindHold(el,key){
    const on=e=>{e.preventDefault();input[key]=true;try{el.setPointerCapture(e.pointerId);}catch(_){}};
    const off=e=>{e.preventDefault();input[key]=false;};
    el.addEventListener('pointerdown',on);el.addEventListener('pointerup',off);el.addEventListener('pointercancel',off);el.addEventListener('lostpointercapture',off);
  }
  bindHold($('leftBtn'),'left');bindHold($('rightBtn'),'right');bindHold($('gasBtn'),'gas');bindHold($('brakeBtn'),'brake');
  const keyMap={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'gas',KeyW:'gas',ArrowDown:'brake',KeyS:'brake'};
  addEventListener('keydown',e=>{if(keyMap[e.code]){input[keyMap[e.code]]=true;e.preventDefault();}if((e.code==='Escape'||e.code==='KeyP')&&!e.repeat){state==='racing'?pauseRace():state==='paused'&&continueRace();}});
  addEventListener('keyup',e=>{if(keyMap[e.code]){input[keyMap[e.code]]=false;e.preventDefault();}});
  document.addEventListener('touchmove',e=>e.preventDefault(),{passive:false});
  document.addEventListener('contextmenu',e=>e.preventDefault());
  document.addEventListener('visibilitychange',()=>{if(document.hidden){resetInput();if(state==='racing')pauseRace();}});

  function toast(text,kind='good'){
    while(UI.toasts.children.length>=2)UI.toasts.firstElementChild.remove();
    const d=document.createElement('div');d.className='toast '+kind;d.textContent=text;UI.toasts.appendChild(d);setTimeout(()=>d.remove(),900);
  }
  function spawnParticle(x,y,type,count=1){
    for(let k=0;k<count;k++){const p=particles[pCursor++%particles.length];p.active=true;p.x=x+(Math.random()-.5)*10;p.y=y+(Math.random()-.5)*10;p.life=p.max=type==='spark'?.28:type==='smoke'?.65:.48;p.type=type;p.size=type==='smoke'?4+Math.random()*5:1.5+Math.random()*3;const a=Math.random()*Math.PI*2,sp=type==='spark'?90+Math.random()*150:20+Math.random()*45;p.vx=Math.cos(a)*sp-(player?player.vx*.1:0);p.vy=Math.sin(a)*sp-(player?player.vy*.1:0);}
  }
  function addSkid(c){const s=skid[skidCursor++%skid.length],hx=Math.cos(c.angle),hy=Math.sin(c.angle),nx=-hy,ny=hx;const backX=c.x-hx*20,backY=c.y-hy*20;s.active=true;s.life=1;s.x1=backX+nx*13;s.y1=backY+ny*13;s.x2=backX-nx*13;s.y2=backY-ny*13;}
  function updateEffects(dt){
    for(const p of particles)if(p.active){p.life-=dt;if(p.life<=0){p.active=false;continue;}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(.95,dt*60);p.vy*=Math.pow(.95,dt*60);if(p.type==='smoke')p.size+=dt*8;}
    for(const s of skid)if(s.active){s.life-=dt*.18;if(s.life<=0)s.active=false;}
  }

  function resolveCarCollisions(){
    for(let i=0;i<cars.length;i++)for(let j=i+1;j<cars.length;j++){
      const a=cars[i],b=cars[j],dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy,min=29;
      if(d2>0&&d2<min*min){
        const d=Math.sqrt(d2),nx=dx/d,ny=dy/d,over=min-d;
        a.x-=nx*over*.5;a.y-=ny*over*.5;b.x+=nx*over*.5;b.y+=ny*over*.5;
        const rv=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny;
        if(rv<0){
          const imp=Math.min(58,-rv*.34);
          a.vx-=nx*imp;a.vy-=ny*imp;b.vx+=nx*imp;b.vy+=ny*imp;
          const loss=.985-.055*clamp(Math.abs(rv)/150,0,1);
          a.vx*=loss;a.vy*=loss;b.vx*=loss;b.vy*=loss;
          a.speed=Math.hypot(a.vx,a.vy);b.speed=Math.hypot(b.vx,b.vy);
        }
        a.collisionThisLap=b.collisionThisLap=true;
        if((a.player||b.player)&&impactCooldown<=0){impactCooldown=.18;shake=Math.max(shake,3+Math.min(6,Math.abs(rv)*.04));audio.collision(Math.min(1,Math.abs(rv)/110));spawnParticle((a.x+b.x)/2,(a.y+b.y)/2,'spark',4);}
      }
    }
  }

  function updateRace(dt){
    raceTime+=dt;lapTime+=dt*1000;impactCooldown-=dt;grassSoundCooldown-=dt;skidTick-=dt;
    const steer=(input.right?1:0)-(input.left?1:0);const pResult=player.update(dt,{steer,throttle:input.gas?1:0,brake:input.brake?1:0},track);
    const difficulty=Math.min(.42,player.laps*.035+raceTime/900);
    for(const c of cars)if(c!==player){c.maxSpeed=c.baseMaxSpeed*(1+difficulty*.085);const ctl=c.ai.think(dt,track,cars,difficulty);const r=c.update(dt,ctl,track);if(r.impact>.45)spawnParticle(c.x,c.y,'spark',2);}
    resolveCarCollisions();

    if(pResult.impact>.05&&impactCooldown<=0){impactCooldown=.16;shake=Math.max(shake,3+pResult.impact*10);audio.collision(pResult.impact);spawnParticle(player.x,player.y,'spark',7);}
    if(!player.onRoad&&player.speed>100){if(Math.random()<dt*26)spawnParticle(player.x-player.vx*.035,player.y-player.vy*.035,'grass',2);if(grassSoundCooldown<=0){audio.grass();grassSoundCooldown=.16;}}
    const lateral=Math.abs(-Math.sin(player.angle)*player.vx+Math.cos(player.angle)*player.vy);
    if(skidTick<=0&&player.speed>160&&(lateral>32||input.brake)){addSkid(player);skidTick=.055;if(input.brake&&Math.random()<.6)spawnParticle(player.x-player.vx*.05,player.y-player.vy*.05,'smoke',1);}
    updateEffects(dt);

    scoreCarry+=player.speed*dt*(.055+(15-player.rank)*.0018);if(scoreCarry>=1){const add=Math.floor(scoreCarry);score+=add;scoreCarry-=add;}
    updateRanks();
    if(player.rank<prevRank){score+=100*(prevRank-player.rank);audio.overtake();}prevRank=player.rank;

    if(player.finishedLap){
      const completed=player.laps,lapMs=lapTime;lapTime=0;let bonus=750+Math.max(0,15-player.rank)*45;score+=bonus;
      const clean=!player.collisionThisLap&&!player.offroadThisLap;if(clean){score+=350;toast('CLEAN LAP  +350');}
      let best=false;if(!save.bestLap||lapMs<save.bestLap){save.bestLap=lapMs;best=true;score+=600;toast('NEW BEST LAP  +600');}
      else toast('LAP '+completed+'  +'+bonus);
      save.maxLaps=Math.max(save.maxLaps,completed);save.bestScore=Math.max(save.bestScore,Math.floor(score));writeSave();audio.lap(best);
      player.collisionThisLap=false;player.offroadThisLap=false;player.offroadTime=0;
    }
    save.bestScore=Math.max(save.bestScore,Math.floor(score));
    audio.updateEngine(player.speed,input.gas?1:0,true);
    updateCamera(dt);updateHUD();
  }

  function updateRanks(){const sorted=cars.slice().sort((a,b)=>b.raceMetric()-a.raceMetric());for(let i=0;i<sorted.length;i++)sorted[i].rank=i+1;}
  function updateHUD(){UI.pos.textContent=player.rank+' / '+cars.length;UI.lap.textContent=(player.laps+1);UI.speed.textContent=Math.round(player.speed*.88);UI.score.textContent=Math.floor(score).toLocaleString();UI.lapTime.textContent=fmt(lapTime);UI.bestLap.textContent=fmt(save.bestLap);}

  function updateCamera(dt){
    const look=95+clamp(player.speed/352,0,1)*55,tx=player.x+Math.cos(player.angle)*look,ty=player.y+Math.sin(player.angle)*look;
    const follow=1-Math.pow(.0025,dt);cam.x=lerp(cam.x,tx,follow);cam.y=lerp(cam.y,ty,follow);
    let target=-Math.PI/2-player.angle,d=target-cam.rot;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;cam.rot+=d*Math.min(1,dt*5.2);
    const base=clamp(Math.min(W/920,H/520)*.78,.52,.92),speedZoom=1-clamp(player.speed/352,0,1)*.12;cam.zoom=lerp(cam.zoom,base*speedZoom,Math.min(1,dt*4));shake*=Math.pow(.05,dt);
  }

  function drawParticles(){
    for(const s of skid)if(s.active){ctx.globalAlpha=.25*s.life;ctx.fillStyle='#090b0c';ctx.beginPath();ctx.arc(s.x1,s.y1,2.2,0,Math.PI*2);ctx.arc(s.x2,s.y2,2.2,0,Math.PI*2);ctx.fill();}
    for(const p of particles)if(p.active){const a=p.life/p.max;ctx.globalAlpha=Math.min(1,a);if(p.type==='spark')ctx.fillStyle='#ffd45e';else if(p.type==='grass')ctx.fillStyle='#a8d66f';else ctx.fillStyle='#d7dedc';ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();}
    ctx.globalAlpha=1;
  }

  function drawRace(){
    ctx.setTransform(DPR,0,0,DPR,0,0);ctx.fillStyle='#102e20';ctx.fillRect(0,0,W,H);
    const sx=shake?(Math.random()-.5)*shake:0,sy=shake?(Math.random()-.5)*shake:0;
    ctx.save();ctx.translate(W*.5+sx,H*.5+sy);ctx.rotate(cam.rot);ctx.scale(cam.zoom,cam.zoom);ctx.translate(-cam.x,-cam.y);
    track.draw(ctx);drawParticles();
    // Draw AI first, player last for readability.
    for(const c of cars)if(c!==player)c.draw(ctx);if(player)player.draw(ctx);
    ctx.restore();drawSpeedLines();
  }

  function drawSpeedLines(){
    if(!player||player.speed<245||state==='paused')return;const t=clamp((player.speed-245)/110,0,1);ctx.save();ctx.globalAlpha=.12*t;ctx.strokeStyle='#ffffff';ctx.lineWidth=1;
    const cx=W*.5,cy=H*.57;for(let i=0;i<18;i++){const a=(i*2.399+raceTime*.7)%6.283,r=90+((i*73+raceTime*330)%Math.max(120,W*.55));const len=18+45*t;ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);ctx.lineTo(cx+Math.cos(a)*(r+len),cy+Math.sin(a)*(r+len));ctx.stroke();}ctx.restore();
  }

  function drawMenu(dt){
    demoT+=dt;ctx.setTransform(DPR,0,0,DPR,0,0);ctx.fillStyle='#123521';ctx.fillRect(0,0,W,H);ctx.save();ctx.translate(W*.5,H*.5);const z=Math.min(W/3200,H/2050)*1.18;ctx.scale(z,z);ctx.rotate(-.08);track.draw(ctx);
    for(const c of demoCars){const pr=(demoT*.032+c.demoOffset)%1,p=track.sampleAtProgress(pr,Math.sin(pr*18+c.id)*18);c.x=p.x;c.y=p.y;c.angle=Math.atan2(p.ty,p.tx);c.draw(ctx,1.1);}ctx.restore();
    const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(0,0,0,.06)');g.addColorStop(1,'rgba(0,0,0,.32)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  }

  function frame(now){
    let dt=(now-last)/1000;last=now;dt=Math.min(.033,Math.max(0,dt));
    if(state==='menu'){drawMenu(dt);}
    else {if(state==='racing')updateRace(dt);else if(state==='countdown')updateCamera(dt);drawRace();}
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
