(function(){
  'use strict';
  const R=window.Racing=window.Racing||{};
  const points=a=>a.map(([x,y])=>({x,y}));
  R.TRACKS={
    apexCircuit:{id:'apexCircuit',name:'APEX CIRCUIT',type:'TECHNICAL',description:'Классический автодром · точность и темп',roadWidth:214,
      points:points([[-1240,40],[-1120,-600],[-560,-870],[80,-810],[690,-905],[1240,-560],[1380,-20],[1140,510],[610,790],[20,690],[-470,800],[-940,560],[-1330,300]]),
      theme:{kind:'circuit',ground:'#174e2d',road:'#34383a',curb:'#e94b49',barrier:'#d5d9d6',accent:'#8dff49',surface:'grass',drag:1,dust:'#a8d66f'}},
    neonHarbor:{id:'neonHarbor',name:'NEON HARBOR',type:'STREET / NIGHT',description:'Ночной порт · прямая, шикана, поздний тормоз',targetLength:5400,roadWidth:204,
      points:points([[-600,-520],[200,-520],[650,-500],[760,-310],[760,90],[510,180],[550,380],[190,510],[-260,510],[-380,300],[-640,280],[-780,80],[-780,-280]]),
      theme:{kind:'neon',ground:'#111c30',road:'#252c3c',curb:'#31cfea',barrier:'#8866ec',accent:'#53dfff',surface:'runoff',drag:.65,dust:'#87a4c3'}},
    desertCanyon:{id:'desertCanyon',name:'DESERT CANYON',type:'HIGH SPEED',description:'Каньон · максимальная скорость и шпилька',targetLength:9600,roadWidth:230,
      points:points([[-1500,-670],[-500,-670],[700,-670],[1570,-590],[1790,-360],[1570,-100],[740,-70],[550,220],[970,530],[590,800],[-110,690],[-750,850],[-1420,650],[-1680,130]]),
      theme:{kind:'desert',ground:'#b77c4b',road:'#353331',curb:'#eb9d56',barrier:'#f1ce9a',accent:'#ffac64',surface:'sand',drag:1.55,dust:'#e9be7e'}},
    alpineRing:{id:'alpineRing',name:'ALPINE RING',type:'MOUNTAIN / EXPERT',description:'Горные S-связки · две шпильки',targetLength:6700,roadWidth:202,
      points:points([[-700,-650],[0,-650],[600,-650],[810,-450],[640,-210],[100,-250],[-120,-60],[220,110],[610,40],[810,270],[580,550],[10,490],[-320,650],[-760,510],[-820,260],[-500,80],[-720,-120],[-970,-260],[-980,-510]]).map(p=>({x:p.x*.9,y:p.y*1.2})),
      theme:{kind:'alpine',ground:'#465e5c',road:'#343d42',curb:'#a6c5d1',barrier:'#eef5f6',accent:'#b5e5ff',surface:'grass',drag:1.1,dust:'#b9cec6'}},
    coastlineGT:{id:'coastlineGT',name:'COASTLINE GT',type:'GRAND TOURING',description:'Морская дуга · быстрые связки и длинный разгон',targetLength:8400,roadWidth:222,
      points:points([[-1200,-650],[-300,-650],[760,-650],[1200,-410],[1460,40],[1250,550],[800,850],[210,920],[-310,730],[-370,400],[-760,380],[-1010,620],[-1380,420],[-1480,80],[-1240,-210]]),
      theme:{kind:'coast',ground:'#227b8a',road:'#384144',curb:'#55c3cc',barrier:'#e2e9df',accent:'#5fe4da',surface:'sand',drag:1.25,dust:'#e4d4af'}}
  };
  R.LIVERIES={
    apexLime:{name:'APEX LIME',price:0,primary:'#80ff44',secondary:'#f5f5ed',accent:'#183b24',stripe:'#eaffdf'},
    crimsonVelocity:{name:'CRIMSON VELOCITY',price:300,primary:'#f3274f',secondary:'#20242c',accent:'#ffffff',stripe:'#f6ecec'},
    iceVector:{name:'ICE VECTOR',price:500,primary:'#36d5ff',secondary:'#f0faff',accent:'#173f75',stripe:'#173f75'},
    auroraPulse:{name:'AURORA PULSE',price:800,primary:'#9860ff',secondary:'#f34ebc',accent:'#e8ff8a',stripe:'#e8ff8a'}
  };
  R.EFFECTS={standard:{name:'STANDARD',price:0},blueFlame:{name:'BLUE FLAME',price:350,outer:'#2372ff',inner:'#a9faff'},redFlame:{name:'RED FLAME',price:550,outer:'#ff2453',inner:'#fff299'},rainbowFlame:{name:'RAINBOW FLAME',price:900,rainbow:true}};
  R.DIFFICULTY_LABELS={easy:'ЛЕГКО',medium:'СРЕДНЕ',hard:'СЛОЖНО',extreme:'ЭКСТРИМ'};
  const has=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
  const safeNumber=(v,fallback=0)=>typeof v==='number'&&Number.isFinite(v)?Math.min(Number.MAX_SAFE_INTEGER,Math.max(0,v)):fallback;
  R.normalizeSave=function(raw){
    const d=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
    const own=(value,catalog,free)=>Array.from(new Set([free,...(Array.isArray(value)?value.filter(id=>typeof id==='string'&&has(catalog,id)):[])]));
    const ownedLiveries=own(d.ownedLiveries,R.LIVERIES,'apexLime'),ownedEffects=own(d.ownedEffects,R.EFFECTS,'standard');
    return {saveVersion:2,bestScore:safeNumber(d.bestScore),bestLap:safeNumber(d.bestLap),maxLaps:Math.floor(safeNumber(d.maxLaps)),muted:!!d.muted,
      botCount:Math.max(1,Math.min(13,Math.round(safeNumber(d.botCount,7)))),raceLaps:[3,5,7,10,15].includes(d.raceLaps)?d.raceLaps:5,
      difficulty:has(R.DIFFICULTY_LABELS,d.difficulty)?d.difficulty:'medium',trackId:has(R.TRACKS,d.trackId)?d.trackId:'apexCircuit',
      credits:Math.floor(safeNumber(d.credits,200)),ownedLiveries,ownedEffects,
      selectedLivery:ownedLiveries.includes(d.selectedLivery)?d.selectedLivery:'apexLime',selectedEffect:ownedEffects.includes(d.selectedEffect)?d.selectedEffect:'standard'};
  };
  R.shopAction=function(save,kind,id){
    const catalog=kind==='livery'?R.LIVERIES:kind==='effect'?R.EFFECTS:null;
    if(!catalog||!has(catalog,id))return 'invalid';
    const owned=save[kind==='livery'?'ownedLiveries':'ownedEffects'],selected=kind==='livery'?'selectedLivery':'selectedEffect';
    if(owned.includes(id)){save[selected]=id;return 'selected';}
    if(!Number.isFinite(save.credits)||save.credits<catalog[id].price)return 'insufficient';
    save.credits-=catalog[id].price;owned.push(id);return 'purchased';
  };
  R.raceReward=function({bots,laps,difficulty},place){
    const rankFactor=(bots+1-Math.max(1,Math.min(bots+1,place)))/Math.max(1,bots);
    return Math.max(1,Math.round((30+laps*8+bots*6+180*rankFactor*(.75+bots/20))*({easy:.9,medium:1,hard:1.15,extreme:1.35}[difficulty]||1)));
  };
})();
