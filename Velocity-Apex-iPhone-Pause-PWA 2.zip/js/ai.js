(function(){
  'use strict';
  const R=window.Racing,clamp=R.clamp,angleWrap=R.angleWrap;
  const PROFILES={
    easy:{aggression:.48,precision:.82,errorChance:.05,cornerSkill:.77,reaction:.82,brakeLead:1.22,brakeThreshold:4,overtakeWidth:.9},
    medium:{aggression:.64,precision:.90,errorChance:.026,cornerSkill:.87,reaction:.91,brakeLead:1.12,brakeThreshold:6,overtakeWidth:1},
    hard:{aggression:.77,precision:.97,errorChance:.009,cornerSkill:.96,reaction:.98,brakeLead:1.02,brakeThreshold:8,overtakeWidth:1.06},
    extreme:{aggression:.84,precision:.985,errorChance:.003,cornerSkill:.995,reaction:.995,brakeLead:.90,brakeThreshold:11,overtakeWidth:1.10}
  };
  class AIController{
    constructor(car,index,difficulty='medium'){
      this.car=car;this.index=index;this.difficulty=PROFILES[difficulty]?difficulty:'medium';
      Object.assign(this,PROFILES[this.difficulty]);
      this.cornerSkill*=.99+Math.random()*.02;this.aggression+=(Math.random()-.5)*.04;
      this.preference=(index%3-1)*7;this.lane=this.preference;this.targetLane=this.lane;
      this.mistake=0;this.mistakeTimer=3+Math.random()*5;this.overtakeSide=index%2?1:-1;
      this.output={steer:0,throttle:0,brake:0};
    }
    think(dt,track,cars){
      const c=this.car,n=track.samples.length,out=this.output,speed=c.speed,spacing=track.spacing;
      this.mistakeTimer-=dt;
      if(this.mistakeTimer<=0){this.mistakeTimer=3+Math.random()*5;if(Math.random()<this.errorChance)this.mistake=(Math.random()-.5)*32;}
      this.mistake*=Math.exp(-dt*.8);
      const look=42+speed*(.20+(1-this.precision)*.18),ahead=Math.max(2,Math.round(look/spacing)),aimIndex=(c.trackIndex+ahead)%n;
      const local=track.samples[c.trackIndex],lateral=(c.x-local.x)*local.nx+(c.y-local.y)*local.ny;
      let desired=c.maxSpeed*(.87+.13*this.cornerSkill);
      // v² = u² + 2as: scan physical metres within the actual stopping horizon.
      const decel=c.brakePower*.68/this.brakeLead,horizon=speed*speed/(2*decel)+200;
      for(let k=0;k*spacing<=horizon;k+=3){
        const index=(c.trackIndex+k)%n,corner=track.recommendedSpeed[index]*this.cornerSkill;
        desired=Math.min(desired,Math.sqrt(corner*corner+2*decel*Math.max(0,k*spacing-42)));
      }
      this.targetLane=track.racingLineOffset[aimIndex]*this.precision+this.preference;
      let lead=null,leadGap=Infinity,leadLane=0;
      const trafficHorizon=100+speed*.55;
      for(const o of cars){
        if(o===c)continue;
        const gap=((o.progress-c.progress+1)%1)*track.length;
        const p=track.samples[o.trackIndex],otherLane=(o.x-p.x)*p.nx+(o.y-p.y)*p.ny;
        if(gap>0&&gap<trafficHorizon&&gap<leadGap&&Math.abs(otherLane-lateral)<57){lead=o;leadGap=gap;leadLane=otherLane;}
      }
      if(lead){
        const limit=track.roadWidth*.5-34,passOffset=55*this.overtakeWidth;
        let bestLane=null,bestClear=-Infinity;
        for(const side of [-1,1]){
          const lane=leadLane+side*passOffset;if(Math.abs(lane)>limit)continue;
          let clearance=Infinity;
          for(const o of cars){
            if(o===c||o===lead)continue;
            let gap=((o.progress-c.progress+1.5)%1-.5)*track.length;
            const p=track.samples[o.trackIndex],ol=(o.x-p.x)*p.nx+(o.y-p.y)*p.ny;
            if(gap>-100&&gap<leadGap+100&&Math.abs(ol-lane)<51)clearance=Math.min(clearance,Math.abs(gap));
          }
          if(clearance>90&&clearance>bestClear){bestLane=lane;bestClear=clearance;}
        }
        if(bestLane!==null){this.targetLane=bestLane;this.overtakeSide=Math.sign(bestLane-leadLane);}
        const aligned=Math.abs(lateral-leadLane)<52;
        if(aligned){
          const gap=Math.max(0,leadGap-88);
          desired=Math.min(desired,Math.sqrt(lead.speed*lead.speed+2*decel*gap));
          if(leadGap<95)desired=Math.min(desired,Math.max(0,lead.speed-(95-leadGap)*2));
        }
      }
      this.targetLane=clamp(this.targetLane,-track.roadWidth*.32,track.roadWidth*.32);
      this.lane+=(this.targetLane-this.lane)*(1-Math.exp(-dt*(1.5+this.aggression*1.5)*this.reaction));
      const aim=track.samples[aimIndex],tx=aim.x+aim.nx*(this.lane+this.mistake)-c.x,ty=aim.y+aim.ny*(this.lane+this.mistake)-c.y;
      const distance=Math.max(20,Math.hypot(tx,ty)),diff=angleWrap(Math.atan2(ty,tx)-c.angle);
      // Pure pursuit requests a yaw rate, then maps it to the shared car's steering authority.
      const ratio=clamp(speed/c.maxSpeed,0,1),authority=c.turnRate*(.94-.66*Math.pow(ratio,.82))*(.42+.58*clamp(speed/48,0,1))*(c.onRoad?1:.62);
      const slip=angleWrap(Math.atan2(c.vy,c.vx)-c.angle);
      const yaw=2*Math.max(35,speed)*Math.sin(diff)/distance-slip*.75;
      out.steer=clamp(yaw/Math.max(.1,authority),-1,1);
      if(Math.abs(diff)>1)desired=Math.min(desired,65);
      if(!c.onRoad)desired=Math.min(desired,105);
      const over=speed-desired;
      out.brake=over>Math.max(1,this.brakeThreshold*.18)?clamp(over/28,0,1):0;
      out.throttle=out.brake>.04?0:clamp((desired-speed)/20+.65,0,1);
      return out;
    }
  }
  R.AIController=AIController;R.AI_PROFILES=PROFILES;
})();
