(function(){
  'use strict';
  const R=window.Racing,clamp=R.clamp,angleWrap=R.angleWrap;
  const PROFILES={
    easy:{aggression:.60,precision:.88,errorChance:.028,errorSize:21,cornerSkill:.91,reaction:.91,brakeLead:1.07,brakeMargin:8.5,overtakeWidth:1.00,laneRate:2.05,followGap:88,recoverySpeed:126,throttleBase:.57,driverVariance:.025},
    medium:{aggression:.73,precision:.945,errorChance:.013,errorSize:13,cornerSkill:.975,reaction:.98,brakeLead:1.00,brakeMargin:6.5,overtakeWidth:1.06,laneRate:2.35,followGap:82,recoverySpeed:138,throttleBase:.59,driverVariance:.018},
    hard:{aggression:.87,precision:.985,errorChance:.0035,errorSize:6,cornerSkill:1.035,reaction:1.055,brakeLead:.95,brakeMargin:4.5,overtakeWidth:1.13,laneRate:2.72,followGap:76,recoverySpeed:151,throttleBase:.615,driverVariance:.011},
    extreme:{aggression:.965,precision:.998,errorChance:.0006,errorSize:2.5,cornerSkill:1.075,reaction:1.12,brakeLead:.92,brakeMargin:3.0,overtakeWidth:1.18,laneRate:3.05,followGap:70,recoverySpeed:165,throttleBase:.635,driverVariance:.006}
  };

  class AIController{
    constructor(car,index,difficulty='medium'){
      this.car=car;this.index=index;this.difficulty=PROFILES[difficulty]?difficulty:'medium';
      Object.assign(this,PROFILES[this.difficulty]);
      const variance=1+(Math.random()-.5)*2*this.driverVariance;
      this.cornerSkill*=variance;this.aggression=clamp(this.aggression+(Math.random()-.5)*this.driverVariance*.8,.35,1);
      this.preference=(index%3-1)*(this.difficulty==='extreme'?4.5:this.difficulty==='hard'?5.5:7);
      this.lane=this.preference;this.targetLane=this.lane;this.mistake=0;this.mistakeTimer=4+Math.random()*5;this.overtakeSide=index%2?1:-1;
      this.output={steer:0,throttle:0,brake:0};
    }

    think(dt,track,cars){
      const c=this.car,n=track.samples.length,out=this.output,speed=c.speed,spacing=track.spacing;
      this.mistakeTimer-=dt;
      if(this.mistakeTimer<=0){
        this.mistakeTimer=4+Math.random()*6;
        if(Math.random()<this.errorChance)this.mistake=(Math.random()-.5)*2*this.errorSize;
      }
      this.mistake*=Math.exp(-dt*(1.0+this.precision*.65));

      // Read the next few hundred metres to distinguish a straight from a real braking zone.
      let curveAhead=0;
      const curveScan=Math.max(5,Math.round(230/spacing));
      for(let k=2;k<=curveScan;k+=Math.max(1,Math.round(30/spacing))){
        curveAhead=Math.max(curveAhead,Math.abs(track.samples[(c.trackIndex+k)%n].curvature));
      }
      const curveFactor=clamp(curveAhead*155,0,1);
      const look=52+speed*(.225+(1-this.precision)*.08)-curveFactor*(18+speed*.035);
      const ahead=Math.max(2,Math.round(clamp(look,48,150)/spacing)),aimIndex=(c.trackIndex+ahead)%n;
      const local=track.samples[c.trackIndex],lateral=(c.x-local.x)*local.nx+(c.y-local.y)*local.ny;

      let desired=c.maxSpeed;
      // Braking envelope: use the car's real braking authority, then work backwards from upcoming apex speeds.
      const brakeModel=c.brakePower*(.68+.06*Math.min(1,this.cornerSkill))/this.brakeLead;
      const horizon=Math.min(620,speed*speed/(2*Math.max(80,brakeModel))+230);
      const step=Math.max(1,Math.round(24/spacing));
      for(let k=0;k*spacing<=horizon;k+=step){
        const index=(c.trackIndex+k)%n;
        const corner=Math.min(c.maxSpeed,track.recommendedSpeed[index]*this.cornerSkill);
        const distance=Math.max(0,k*spacing-(30+speed*.028));
        desired=Math.min(desired,Math.sqrt(corner*corner+2*brakeModel*distance));
      }

      const baseLine=track.racingLineOffset[aimIndex]*this.precision;
      this.targetLane=baseLine+this.preference;
      let lead=null,leadGap=Infinity,leadLane=0;
      const trafficHorizon=125+speed*.62;
      for(const o of cars){
        if(o===c||o.raceFinished)continue;
        const gap=((o.progress-c.progress+1)%1)*track.length;
        if(gap<=0||gap>=trafficHorizon||gap>=leadGap)continue;
        const p=track.samples[o.trackIndex],otherLane=(o.x-p.x)*p.nx+(o.y-p.y)*p.ny;
        if(Math.abs(otherLane-lateral)<track.roadWidth*.38){lead=o;leadGap=gap;leadLane=otherLane;}
      }

      let passing=false;
      if(lead){
        const limit=track.roadWidth*.5-31,passOffset=56*this.overtakeWidth;
        let bestLane=null,bestScore=-Infinity;
        const lineAtLead=track.racingLineOffset[(lead.trackIndex+Math.max(2,Math.round(65/spacing)))%n]*this.precision;
        for(const side of [this.overtakeSide,-this.overtakeSide]){
          const lane=clamp(leadLane+side*passOffset,-limit,limit);
          if(Math.abs(lane-leadLane)<47)continue;
          let clearance=240;
          for(const o of cars){
            if(o===c||o===lead||o.raceFinished)continue;
            const signedGap=(((o.progress-c.progress+1.5)%1)-.5)*track.length;
            if(signedGap<-85||signedGap>leadGap+120)continue;
            const p=track.samples[o.trackIndex],ol=(o.x-p.x)*p.nx+(o.y-p.y)*p.ny;
            if(Math.abs(ol-lane)<49)clearance=Math.min(clearance,Math.abs(signedGap));
          }
          const edgePenalty=Math.abs(lane)/Math.max(1,limit)*18,linePenalty=Math.abs(lane-lineAtLead)*.12;
          const score=clearance-edgePenalty-linePenalty+(side===this.overtakeSide?3:0);
          if(clearance>62&&score>bestScore){bestLane=lane;bestScore=score;}
        }
        if(bestLane!==null&&leadGap<trafficHorizon*.92){
          passing=true;this.targetLane=bestLane;this.overtakeSide=Math.sign(bestLane-leadLane)||this.overtakeSide;
        }

        const laneSeparation=Math.abs(lateral-leadLane),closing=Math.max(0,speed-lead.speed);
        if(!passing||laneSeparation<34){
          const safeGap=this.followGap+closing*.19;
          const room=Math.max(0,leadGap-safeGap);
          desired=Math.min(desired,Math.sqrt(Math.max(0,lead.speed*lead.speed+2*brakeModel*room)));
          if(leadGap<safeGap*.72)desired=Math.min(desired,Math.max(35,lead.speed-(safeGap*.72-leadGap)*1.15));
        }else if(leadGap<54&&laneSeparation<42){
          desired=Math.min(desired,lead.speed+8);
        }
      }

      if(!c.onRoad){
        this.targetLane=0;desired=Math.min(desired,this.recoverySpeed);
      }
      const laneLimit=track.roadWidth*(c.onRoad?.34:.27);
      this.targetLane=clamp(this.targetLane,-laneLimit,laneLimit);
      const laneResponse=(this.laneRate+this.aggression*.75)*this.reaction*(c.onRoad?1:1.35);
      this.lane+=(this.targetLane-this.lane)*(1-Math.exp(-dt*laneResponse));

      const recoveryAhead=!c.onRoad?Math.max(2,Math.round(52/spacing)):ahead;
      const aim=track.samples[(c.trackIndex+recoveryAhead)%n];
      const laneAim=!c.onRoad?this.lane*.35:this.lane;
      const tx=aim.x+aim.nx*(laneAim+this.mistake)-c.x,ty=aim.y+aim.ny*(laneAim+this.mistake)-c.y;
      const distance=Math.max(22,Math.hypot(tx,ty)),diff=angleWrap(Math.atan2(ty,tx)-c.angle);
      const ratio=clamp(speed/c.maxSpeed,0,1),authority=c.turnRate*(.94-.66*Math.pow(ratio,.82))*(.42+.58*clamp(speed/48,0,1))*(c.onRoad?1:.62);
      const velocityAngle=speed>8?Math.atan2(c.vy,c.vx):c.angle,slip=angleWrap(velocityAngle-c.angle);
      let yaw=2*Math.max(42,speed)*Math.sin(diff)/distance-slip*(.68+.18*this.precision);
      if(!c.onRoad)yaw+=clamp(-lateral/(track.roadWidth*.35),-1,1)*.18;
      out.steer=clamp(yaw/Math.max(.1,authority),-1,1);

      if(Math.abs(diff)>1.05)desired=Math.min(desired,78+35*this.cornerSkill);
      const over=speed-desired;
      out.brake=over>this.brakeMargin?clamp((over-this.brakeMargin)/24+.16,0,1):0;
      if(out.brake>.045)out.throttle=0;
      else{
        const error=desired-speed;
        out.throttle=clamp(this.throttleBase+error/34+(passing?.035:0),0,1);
        if(error>24)out.throttle=1;
      }
      return out;
    }
  }
  R.AIController=AIController;R.AI_PROFILES=PROFILES;
})();
