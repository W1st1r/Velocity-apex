(function(){
  'use strict';
  const R=window.Racing,clamp=R.clamp,angleWrap=R.angleWrap;
  const PROFILES={
    easy:{aggression:.54,precision:.86,errorChance:.030,errorSize:20,lineUse:.82,pace:.88,gripUsage:.80,brakeUsage:.76,accelUsage:.86,reaction:.88,brakeMargin:10,laneRate:1.85,followGap:96,recoverySpeed:124,edgeUse:.68,trafficSkill:.60,driverVariance:.030},
    medium:{aggression:.70,precision:.94,errorChance:.012,errorSize:11,lineUse:.92,pace:.945,gripUsage:.89,brakeUsage:.86,accelUsage:.92,reaction:.97,brakeMargin:6.5,laneRate:2.25,followGap:86,recoverySpeed:139,edgeUse:.79,trafficSkill:.76,driverVariance:.018},
    hard:{aggression:.86,precision:.982,errorChance:.003,errorSize:5,lineUse:.975,pace:.985,gripUsage:.96,brakeUsage:.94,accelUsage:.97,reaction:1.04,brakeMargin:3.8,laneRate:2.70,followGap:80,recoverySpeed:153,edgeUse:.90,trafficSkill:.91,driverVariance:.010},
    extreme:{aggression:.96,precision:.997,errorChance:.0005,errorSize:2,lineUse:.995,pace:1,gripUsage:.995,brakeUsage:.985,accelUsage:.995,reaction:1.09,brakeMargin:1.8,laneRate:3.05,followGap:75,recoverySpeed:164,edgeUse:.965,trafficSkill:.985,driverVariance:.004}
  };

  const laneOf=(car,track)=>{const p=track.samples[car.trackIndex];return (car.x-p.x)*p.nx+(car.y-p.y)*p.ny;};
  const forwardSpeed=(car,track)=>{const p=track.samples[car.trackIndex];return car.vx*p.tx+car.vy*p.ty;};

  class AIController{
    constructor(car,index,difficulty='medium'){
      this.car=car;this.index=index;this.difficulty=PROFILES[difficulty]?difficulty:'medium';
      Object.assign(this,PROFILES[this.difficulty]);
      const variance=1+(Math.random()-.5)*2*this.driverVariance;
      this.pace=clamp(this.pace*variance,.72,1);this.aggression=clamp(this.aggression+(Math.random()-.5)*this.driverVariance,.35,1);
      this.preference=(index%3-1)*(this.difficulty==='extreme'?2.0:this.difficulty==='hard'?2.8:4.0);
      this.lane=this.preference;this.targetLane=this.lane;this.mistake=0;this.mistakeTimer=4+Math.random()*5;this.overtakeSide=index%2?1:-1;
      this.output={steer:0,throttle:0,brake:0};this.speedProfile=null;this.profileTrack=null;
    }

    _profile(track){
      if(this.profileTrack!==track||!this.speedProfile){
        this.speedProfile=track.getSpeedProfile(this.car,{gripUsage:this.gripUsage,brakeUsage:this.brakeUsage,accelUsage:this.accelUsage,pace:this.pace});
        this.profileTrack=track;
      }
      return this.speedProfile;
    }

    _futureTurn(track,index,distance=180){
      const n=track.samples.length,step=Math.max(1,Math.round(24/track.spacing)),count=Math.max(1,Math.round(distance/(step*track.spacing)));
      let best=0;
      for(let q=1;q<=count;q++){const k=track.samples[(index+q*step)%n].curvature;if(Math.abs(k)>Math.abs(best))best=k;}
      return best;
    }

    _trafficChoice(track,cars,baseLane,lateral,speed){
      const c=this.car,limit=track.roadWidth*.5-27,trafficEdge=clamp(.88+.12*this.trafficSkill,.88,1);
      const horizon=125+speed*.72,metric=c.raceMetric(),cForward=Math.max(0,forwardSpeed(c,track));
      let lead=null,leadGap=Infinity,leadLane=0,alongside=null,alongGap=Infinity,alongLane=0;
      const nearby=[];
      for(const o of cars){
        if(o===c||o.raceFinished)continue;
        const gap=(o.raceMetric()-metric)*track.length;if(gap<-105||gap>horizon+170)continue;
        const ol=laneOf(o,track),ov=Math.max(0,forwardSpeed(o,track));nearby.push({o,gap,ol,ov});
        const predicted=gap+(ov-cForward)*.70;
        if(gap>0&&gap<horizon&&(Math.abs(ol-lateral)<66||Math.abs(ol-baseLane)<56)&&predicted<leadGap){lead=o;leadGap=Math.max(0,predicted);leadLane=ol;}
        if(Math.abs(gap)<78&&Math.abs(ol-lateral)<78&&Math.abs(gap)<alongGap){alongside=o;alongGap=Math.abs(gap);alongLane=ol;}
      }
      if(!lead&&!alongside)return {lane:baseLane,lead:null,leadGap:Infinity,leadLane:0,passing:false,sideBySide:false,sideCar:null};

      // When cars are already wheel-to-wheel, preserve a corridor instead of snapping
      // both of them back to the same optimal line. The id tie-break makes equal-lane
      // situations deterministic and symmetric.
      if(alongside){
        const safeSep=72,delta=lateral-alongLane;
        let side=Math.abs(delta)>3?Math.sign(delta):(c.id<alongside.id?-1:1);
        let hold=alongLane+side*safeSep;
        if(Math.abs(hold)>limit*trafficEdge){side=-side;hold=alongLane+side*safeSep;}
        hold=clamp(hold,-limit*trafficEdge,limit*trafficEdge);
        const gap=(alongside.raceMetric()-metric)*track.length;
        return {lane:hold,lead:gap>0?alongside:lead,leadGap:gap>0?gap:leadGap,leadLane:gap>0?alongLane:leadLane,passing:true,sideBySide:true,sideCar:alongside};
      }

      const nextTurn=this._futureTurn(track,c.trackIndex,230),turnSide=Math.sign(nextTurn)||0,turnSeverity=clamp(Math.abs(nextTurn)*240,0,1);
      const passWidth=70+6*this.aggression,candidates=[baseLane,leadLane-passWidth,leadLane+passWidth];
      if(turnSide){candidates.push(turnSide*limit*this.edgeUse*.72);candidates.push(-turnSide*limit*this.edgeUse*.82);}
      let best=baseLane,bestScore=-Infinity;
      for(let lane of candidates){
        lane=clamp(lane,-limit*trafficEdge,limit*trafficEdge);
        const edgeRoom=limit-Math.abs(lane);let score=54-Math.abs(lane-baseLane)*(.22+(1-this.trafficSkill)*.18)+edgeRoom*.055;
        const moveCost=Math.abs(lane-lateral);score-=moveCost*(.10+(1-this.reaction)*.18);
        score-=Math.abs(lane-baseLane)*turnSeverity*(.22+.12*(1-this.trafficSkill));
        if(turnSide&&leadGap<112)score+=(Math.sign(lane)===turnSide?3.6:0)*this.aggression;
        if(Math.sign(lane-leadLane)===this.overtakeSide)score+=2.5;
        let minClear=260,danger=0,crossingDanger=0;
        const sweepLo=Math.min(lateral,lane)-28,sweepHi=Math.max(lateral,lane)+28;
        for(const item of nearby){
          const {gap,ol,ov}=item;
          for(const t of [.2,.45,.75,1.05,1.35]){
            const futureGap=gap+(ov-cForward)*t,latSep=Math.abs(lane-ol);
            if(latSep<58){minClear=Math.min(minClear,Math.abs(futureGap));if(futureGap>-48&&futureGap<82)danger+=1;}
            if(ol>sweepLo&&ol<sweepHi&&futureGap>-52&&futureGap<80)crossingDanger+=1;
          }
        }
        score+=Math.min(90,minClear)*.36-danger*(62+38*this.trafficSkill)-crossingDanger*(80+48*this.trafficSkill);
        if(Math.abs(lane-leadLane)<60)score-=105;
        if(score>bestScore){bestScore=score;best=lane;}
      }
      const passTurnLimit=.48+.24*this.trafficSkill;
      const passing=Math.abs(best-leadLane)>64&&leadGap<horizon*.95&&(turnSeverity<passTurnLimit||leadGap<48*this.aggression);
      if(passing)this.overtakeSide=Math.sign(best-leadLane)||this.overtakeSide;
      return {lane:best,lead,leadGap,leadLane,passing,sideBySide:false,sideCar:null};
    }

    think(dt,track,cars){
      const c=this.car,n=track.samples.length,out=this.output,speed=c.speed,spacing=track.spacing,profile=this._profile(track);
      this.mistakeTimer-=dt;
      if(this.mistakeTimer<=0){this.mistakeTimer=4+Math.random()*6;if(Math.random()<this.errorChance)this.mistake=(Math.random()-.5)*2*this.errorSize;}
      this.mistake*=Math.exp(-dt*(1.05+this.precision*.8));

      const local=track.samples[c.trackIndex],lateral=(c.x-local.x)*local.nx+(c.y-local.y)*local.ny;
      const futureTurn=this._futureTurn(track,c.trackIndex,240),curveFactor=clamp(Math.abs(futureTurn)*210,0,1);
      const look=clamp(50+speed*.19-curveFactor*(13+speed*.022),46,126);
      const ahead=Math.max(2,Math.round(look/spacing)),aimIndex=(c.trackIndex+ahead)%n;
      const baseLine=track.racingLineOffset[aimIndex]*this.lineUse+this.preference*(1-curveFactor*.75);

      const traffic=this._trafficChoice(track,cars,baseLine,lateral,speed);
      this.targetLane=traffic.lane;
      if(!c.onRoad)this.targetLane=0;
      const laneLimit=track.roadWidth*.5-28;
      const targetEdge=(traffic.lead||traffic.sideBySide)?Math.max(this.edgeUse,.88+.12*this.trafficSkill):this.edgeUse;
      this.targetLane=clamp(this.targetLane,-laneLimit*targetEdge,laneLimit*targetEdge);
      const trafficRate=traffic.sideBySide?.68:(traffic.lead?.82:1);
      const laneResponse=(this.laneRate+.65*this.aggression)*this.reaction*trafficRate*(c.onRoad?1:1.35);
      this.lane+=(this.targetLane-this.lane)*(1-Math.exp(-dt*laneResponse));

      // Pure-pursuit steering follows the precomputed line (or a traffic candidate)
      // using the same yaw authority exposed by Car, avoiding duplicated old constants.
      const recoveryAhead=!c.onRoad?Math.max(2,Math.round(46/spacing)):ahead;
      const aim=track.samples[(c.trackIndex+recoveryAhead)%n],laneAim=!c.onRoad?this.lane*.28:this.lane;
      const tx=aim.x+aim.nx*(laneAim+this.mistake)-c.x,ty=aim.y+aim.ny*(laneAim+this.mistake)-c.y;
      const distance=Math.max(24,Math.hypot(tx,ty)),diff=angleWrap(Math.atan2(ty,tx)-c.angle);
      const velocityAngle=speed>10?Math.atan2(c.vy,c.vx):c.angle,slip=angleWrap(velocityAngle-c.angle);
      let desiredYaw=2*Math.max(46,speed)*Math.sin(diff)/distance-slip*(.42+.20*this.precision);
      if(!c.onRoad)desiredYaw+=clamp(-lateral/(track.roadWidth*.30),-1,1)*.30;
      out.steer=clamp(desiredYaw/Math.max(.12,c.steeringAuthority(speed,c.onRoad)),-1,1);

      let desired=profile[c.trackIndex];
      // A short sample of the already backward-propagated speed profile suppresses
      // single-sample noise while preserving late but achievable braking on Extreme.
      for(let k=1;k<=3;k++)desired=Math.min(desired,profile[(c.trackIndex+k*Math.max(1,Math.round(18/spacing)))%n]+k*2.5);
      if(!c.onRoad)desired=Math.min(desired,this.recoverySpeed);

      // An alternate overtaking lane can have a tighter effective radius than the
      // precomputed racing line. Pay that physical speed cost instead of letting a bot
      // carry ideal-line apex speed on every side-by-side route.
      const cornerSeverity=clamp(Math.max(Math.abs(local.curvature),Math.abs(futureTurn))*235,0,1);
      const idealHere=track.racingLineOffset[c.trackIndex]*this.lineUse;
      const lineDelta=Math.abs(this.lane-idealHere),linePenalty=cornerSeverity*clamp(lineDelta/(track.roadWidth*.32),0,1);
      desired*=1-linePenalty*(.22+.07*(1-this.trafficSkill));
      if(traffic.sideBySide&&traffic.sideCar){
        desired*=1-cornerSeverity*.065;
        if(cornerSeverity>.28)desired=Math.min(desired,traffic.sideCar.speed+10+12*(1-cornerSeverity));
      }

      // Short-horizon TTC guard uses relative velocity and the swept lateral corridor.
      // It does not pick a line; it only prevents a committed pass from driving through
      // a slower car before the lateral separation is actually established.
      const metric=c.raceMetric(),brakeAvail=Math.max(40,c.brakePower*.80*this.brakeUsage);
      for(const o of cars){
        if(o===c||o.raceFinished)continue;
        const gap=(o.raceMetric()-metric)*track.length;if(gap<=0||gap>185)continue;
        const ol=laneOf(o,track),sep=Math.min(Math.abs(lateral-ol),Math.abs(this.lane-ol));
        const closing=Math.max(0,forwardSpeed(c,track)-forwardSpeed(o,track));if(sep>62||closing<3)continue;
        const room=Math.max(0,gap-(46+closing*.17));
        desired=Math.min(desired,Math.sqrt(Math.max(0,o.speed*o.speed+2*brakeAvail*room)));
        if(gap/Math.max(1,closing)<.72&&sep<54)desired=Math.min(desired,o.speed*.96);
      }

      if(traffic.lead){
        const closing=Math.max(0,speed-traffic.lead.speed),laneSeparation=Math.abs(lateral-traffic.leadLane);
        if(!traffic.passing||laneSeparation<64){
          const safe=this.followGap+closing*.22,room=Math.max(0,traffic.leadGap-safe);
          const brake=Math.max(40,c.brakePower*.80*this.brakeUsage);
          desired=Math.min(desired,Math.sqrt(Math.max(0,traffic.lead.speed*traffic.lead.speed+2*brake*room)));
          if(traffic.leadGap<safe*.67)desired=Math.min(desired,Math.max(34,traffic.lead.speed-(safe*.67-traffic.leadGap)*1.10));
        }
      }
      if(Math.abs(diff)>1.08)desired=Math.min(desired,76+34*this.pace);

      const over=speed-desired;
      out.brake=over>this.brakeMargin?clamp((over-this.brakeMargin)/22+.12,0,1):0;
      if(out.brake>.035)out.throttle=0;
      else{
        const error=desired-speed;
        out.throttle=clamp(.28+error/25+(traffic.passing?.05:0),0,1);
        if(error>18)out.throttle=1;
        if(error<-2)out.throttle=0;
      }
      return out;
    }
  }
  R.AIController=AIController;R.AI_PROFILES=PROFILES;
})();
