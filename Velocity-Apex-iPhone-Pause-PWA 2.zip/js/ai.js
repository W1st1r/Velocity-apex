(function(){
  'use strict';
  const R=window.Racing=window.Racing||{},clamp=R.clamp,angleWrap=R.angleWrap;

  const PROFILES={
    easy:{aggression:.52,precision:.82,errorChance:.050,cornerSkill:.81,reaction:.82,brakeLead:1.08,brakeThreshold:4,overtakeWidth:.90},
    medium:{aggression:.62,precision:.87,errorChance:.032,cornerSkill:.87,reaction:.88,brakeLead:1.00,brakeThreshold:7,overtakeWidth:1.00},
    hard:{aggression:.70,precision:.93,errorChance:.017,cornerSkill:.94,reaction:.95,brakeLead:.96,brakeThreshold:9,overtakeWidth:1.06}
  };

  class AIController{
    constructor(car,index,difficulty='medium'){
      this.car=car;this.index=index;this.difficulty=PROFILES[difficulty]?difficulty:'medium';
      const p=PROFILES[this.difficulty],r=Math.random;
      // Small per-driver variance keeps a field organic without allowing one bot to
      // randomly drift into another difficulty tier.
      const v=()=> (r()-.5)*2;
      this.aggression=clamp(p.aggression+v()*.035,.35,.82);
      this.precision=clamp(p.precision+v()*.018,.76,.97);
      this.errorChance=clamp(p.errorChance*(.88+r()*.24),.008,.065);
      this.cornerSkill=clamp(p.cornerSkill+v()*.018,.74,.98);
      this.reaction=clamp(p.reaction+v()*.018,.75,.99);
      this.brakeLead=p.brakeLead*(.99+r()*.02);
      this.brakeThreshold=p.brakeThreshold;
      this.overtakeWidth=p.overtakeWidth;
      this.lane=(r()-.5)*14;this.targetLane=this.lane;
      this.mistake=0;this.mistakeTimer=3+r()*5;this.overtakeSide=r()<.5?-1:1;
      this.steerMemory=0;this.speedBias=.988+r()*.024;
      this.output={steer:0,throttle:0,brake:0};
    }

    think(dt,track,cars){
      const c=this.car,n=track.samples.length,out=this.output;
      this.mistakeTimer-=dt;
      if(this.mistakeTimer<=0){
        this.mistakeTimer=4.5+Math.random()*6.5;
        if(Math.random()<this.errorChance)this.mistake=(Math.random()-.5)*(27-18*this.precision);
      }
      this.mistake*=Math.pow(.78,dt);

      // Read traffic ahead and move toward a passing lane progressively. Difficulty
      // changes willingness to pass, not just raw speed.
      let blocked=false,nearestGap=999,closing=0;
      const trafficDistance=(c.collisionLength||71)+56+18*(1-this.aggression);
      const closeDistance=(c.collisionLength||71)+13;
      const emergencyDistance=(c.collisionLength||71)+5;
      for(const o of cars){
        if(o===c||o.raceFinished)continue;
        let gap=o.raceMetric()-c.raceMetric();
        if(gap<0)gap+=1;
        if(gap>0&&gap<.038){
          const dx=o.x-c.x,dy=o.y-c.y,dist=Math.hypot(dx,dy);
          if(dist<trafficDistance&&dist<nearestGap){
            nearestGap=dist;blocked=true;closing=Math.max(0,c.speed-o.speed);
            const local=track.nearest(o.x,o.y,o.trackIndex);this.overtakeSide=local.signed>=0?-1:1;
          }
        }
      }
      if(blocked)this.targetLane=this.overtakeSide*(22+17*this.aggression)*this.overtakeWidth;
      else this.targetLane=Math.sin((c.progress*6.28)+(this.index*1.73))*5.5*(1-this.precision)+(this.index%3-1)*5;
      const laneRate=.68+.60*this.aggression;
      this.lane+=(this.targetLane-this.lane)*Math.min(1,dt*laneRate);

      const speed=c.speed;
      const steerLook=Math.floor(13+speed*.055+this.precision*5);
      const aim=track.samples[(c.trackIndex+steerLook)%n];
      const tx=aim.x+aim.nx*(this.lane+this.mistake),ty=aim.y+aim.ny*(this.lane+this.mistake);
      const desiredAngle=Math.atan2(ty-c.y,tx-c.x),diff=angleWrap(desiredAngle-c.angle);
      const rawSteer=clamp(diff*(1.52+this.precision*.61),-1,1);
      const steerBlend=Math.min(1,dt*(3.9+this.reaction*1.95));
      this.steerMemory+=(rawSteer-this.steerMemory)*steerBlend;
      const steer=clamp(this.steerMemory,-1,1);

      // Scan ahead for corners. Easy reads farther and brakes earlier; Hard is more
      // precise and can wait slightly longer while keeping only a modest pace edge.
      let curveDemand=0;
      const horizon=Math.floor((42+speed*.13)*this.brakeLead);
      for(let k=10;k<=horizon;k+=7){
        const curve=track.samples[(c.trackIndex+k)%n].curve;
        const proximity=1-k/(horizon+10);
        curveDemand=Math.max(curveDemand,curve*(.72+.48*proximity));
      }
      const curveSeverity=clamp((curveDemand-.075)/.44,0,1);
      const base=c.maxSpeed*this.speedBias;
      const cornerReduction=.39-.15*this.cornerSkill;
      let desired=base*(1-curveSeverity*cornerReduction);

      if(blocked){
        const proximity=clamp((trafficDistance-nearestGap)/(trafficDistance-closeDistance+24),0,1);
        const caution=1.05-this.aggression*.15;
        desired=Math.min(desired,c.speed-closing*.35*caution+22*(1-proximity));
        if(nearestGap<closeDistance)desired=Math.min(desired,Math.max(80,c.speed-(44+10*(1-this.aggression))));
      }
      if(!c.onRoad)desired=Math.min(desired,126+10*this.cornerSkill);

      const overspeed=speed-desired;
      let brake=overspeed>this.brakeThreshold?clamp((overspeed-this.brakeThreshold)/(56+8*this.cornerSkill),0,1):0;
      if(blocked&&nearestGap<emergencyDistance)brake=Math.max(brake,clamp((emergencyDistance+2-nearestGap)/28+.18,0,1));
      let throttle=brake>.08?0:clamp((desired-speed)/(50-5*this.reaction)+.34,0,1);

      // Skilled bots feed power in more cleanly through the apex; less skilled bots
      // leave a slightly larger safety margin while steering hard.
      const cornerThrottle=1-(.46-.08*this.cornerSkill)*Math.abs(steer)*clamp(speed/c.maxSpeed,0,1);
      throttle*=clamp(cornerThrottle,.46+.07*this.cornerSkill,1);

      out.steer=steer;out.throttle=throttle;out.brake=brake;
      return out;
    }
  }
  R.AIController=AIController;
})();
