# Velocity Apex

Top-down / rotating-top-down racing PWA for iPhone/Safari, Android and desktop. The existing HTML/CSS/JavaScript/Canvas 2D architecture is preserved: no framework, npm build, CDN, Three.js, Matter.js or other runtime dependency is required.

## Launch

Open `index.html` in a modern browser. On iPhone use landscape orientation. For Home Screen installation, deploy the project over HTTPS and use Safari → Share → Add to Home Screen. The existing manifest, safe-area layout and static hosting configuration are unchanged.

## Controls

Control mode is stored in `localStorage` and is available both from the main menu and PAUSE.

- **ARROWS** — left/right steering plus independent GAS / BRAKE; multitouch remains supported.
- **TILT** — DeviceOrientation analog steering with iOS permission flow, dead zone and sensitivity selection.
- **WHEEL** — analog virtual wheel, independent GAS / BRAKE.
- Desktop: ← / A, → / D — steer; ↑ / W — gas; ↓ / S — brake; P / Escape — pause.

The physics now expects circuit-racing technique: brake before a slow corner, turn in, then open the throttle on exit. There is no automatic player brake and no hidden track-centering steering assist.

## Formula-style physics

`js/car.js` now uses a high-grip Formula-style yaw/tyre model instead of preserving a large lateral velocity during ordinary cornering.

- Steering requests yaw; available tyre grip limits achievable yaw, so an excessive high-speed steering request becomes **understeer / speed scrub**, not persistent drift.
- Mechanical grip is supplemented by a speed-squared aero/downforce term, giving strong high-speed stability without making low-speed steering rotate the car in place.
- Asphalt lateral velocity relaxes quickly toward the body direction. Heavy braking + steering, impacts, barriers and off-road surfaces temporarily allow more slip.
- Steering release damps yaw quickly and LEFT → RIGHT transitions reverse naturally without a long residual slide.
- GAS, BRAKE, coasting and off-road drag remain distinct.
- The existing OBB/SAT collision footprint is retained. Car-to-car and barrier impacts can temporarily disturb grip instead of being visually erased immediately.

The fixed/substep physics path remains `1/120 s` with the existing bounded number of per-frame substeps.

## Precomputed racing line and speed profile

`js/track.js` performs the expensive planning work once when a `Track` is created.

1. The closed centerline is arc-length resampled as before.
2. Smoothed curvature is scanned for meaningful apex regions over the **whole lap**.
3. Each apex contributes a phase-shaped `approach → apex → exit` lateral target. Contributions from neighboring corners overlap, so S-sections and linked corners naturally compromise rather than treating each sample in isolation.
4. The resulting closed `racingLineOffset[]` is heavily smoothed to avoid sample-to-sample steering chatter.
5. Curvature is recalculated on the offset racing line itself.
6. `recommendedSpeed[]` uses the Formula-style lateral-grip/downforce envelope.
7. `Track.getSpeedProfile()` builds and caches a closed-loop target-speed array with repeated backward braking and forward acceleration passes using the actual car `brakePower`, acceleration and max speed.

No global racing-line or braking optimization runs inside the per-frame game loop.

## Racing AI

`js/ai.js` uses the precomputed line/speed profile plus short-horizon traffic prediction.

- Medium / Hard / Extreme differ by line precision, grip/brake utilization, reaction, error rate, edge usage and traffic skill.
- **They no longer receive difficulty-based max-speed, acceleration, braking or turn-rate bonuses.** Player and bots are created with the same physical performance values.
- Pure-pursuit steering uses `Car.steeringAuthority()` so AI steering is tied to the same yaw model as the player car rather than duplicated legacy constants.
- Traffic planning evaluates the optimal line and alternate passing corridors, checks future longitudinal gap, relative speed, swept lateral space, track edge and upcoming turn severity.
- Cars already side-by-side reserve a lateral corridor instead of both snapping back to the same racing line.
- Alternate/off-line corner routes pay a speed penalty because their effective corner radius is worse than the ideal racing line.
- A short-horizon TTC guard prevents a committed pass from driving through a slower car before lateral separation is established.
- After traffic clears, lane response returns smoothly toward the precomputed racing line.

There is no rubber-band, teleport, position-dependent boost or position-dependent slowdown.

## Camera

Race camera transform is now isotropic top-down / rotating top-down:

```js
ctx.scale(cam.zoom, cam.zoom)
```

`cam.pitch` and speed-dependent anisotropic Y scaling have been removed from race camera code. Therefore a car keeps the same geometric length/width ratio at world headings 0°, 45°, 90° and every other angle. Speed-dependent look-ahead and zoom remain; rotation tracking is faster so camera lag does not create a false impression of sliding. Collision shake is preserved.

## Tracks and race setup

The existing five tracks, 1–13 bots, Easy / Medium / Hard / Extreme and 3 / 5 / 7 / 10 / 15 lap choices are retained. Shop/economy, save key, HUD, mini-map, lap counting, finish flow, credits, PWA manifest and iPhone landscape/safe-area UI are unchanged unless directly required by physics/AI/camera integration.

| Track | Length | Character |
| --- | ---: | --- |
| APEX CIRCUIT | 7.39 km | Technical circuit |
| NEON HARBOR | 5.40 km | Street / night |
| DESERT CANYON | 9.60 km | High speed + hairpin |
| ALPINE RING | 6.70 km | S-sections + hairpins |
| COASTLINE GT | 8.40 km | Fast arcs + technical sector |

## Reproducible standalone tests

No package installation is needed:

```bash
node tests/physics_smoke.js
node tests/standalone_race_test.js
```

The first script checks high-speed slip, LEFT → RIGHT response, braking/turning, grass recovery and the no-pitch/uniform-scale camera invariant. The second runs real `Track + Car + AIController` simulations for Medium/Hard/Extreme on all five tracks plus 8-, 10- and 13-car traffic races.

Current measured results and environment limitations are documented in `TEST_REPORT.md`.

## Project structure

- `js/content.js` — tracks, themes, save migration, shop/economy.
- `js/track.js` — spline sampling, precomputed racing line, line curvature, cached speed profiles, static track renderer.
- `js/car.js` — Formula-style physics, shared car model, OBB/SAT helpers, rendering.
- `js/ai.js` — difficulty profiles, racing-line following, braking, overtaking and traffic prediction.
- `js/controls.js` — ARROWS / TILT / WHEEL input and iOS multitouch handling.
- `js/game.js` — race lifecycle, collision solver, camera, HUD, mini-map and UI integration.
- `tests/physics_smoke.js` — deterministic physics/camera checks.
- `tests/standalone_race_test.js` — deterministic AI lap and traffic simulations.

## Netlify

Deploy the unpacked project as a static site with publish directory `.` and no build command. `index.html` must remain in the project root next to `css/`, `js/`, `assets/` and `manifest.webmanifest`.
