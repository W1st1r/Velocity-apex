# Velocity Apex

Self-contained top-down arcade racing game for mobile Safari, Android and desktop browsers.

## Play locally
Open `index.html` in a modern browser. No build step, package manager, server or external assets are required.

Desktop controls:
- Arrow Left / A — steer left
- Arrow Right / D — steer right
- Arrow Up / W — throttle
- Arrow Down / S — brake
- P / Escape — pause

Mobile controls are shown on screen in landscape mode.

## HOW TO DEPLOY TO NETLIFY

1. Open Netlify.
2. Go to Netlify Drop.
3. Drag the extracted project folder / deploy folder.
4. Wait for deployment.
5. Open generated URL.

## Notes
- Sound is synthesized with Web Audio API and starts after the first PLAY gesture.
- Best Score, Best Lap, Max Laps and mute state are stored in `localStorage`.
- There are no external network requests or CDN dependencies.
