# Velocity Apex

Self-contained top-down arcade racing game for mobile Safari / iPhone PWA, Android and desktop browsers.

## Play locally
Open `index.html` in a modern browser. No build step, package manager, server or external assets are required.

Desktop controls:
- Arrow Left / A — steer left
- Arrow Right / D — steer right
- Arrow Up / W — throttle
- Arrow Down / S — brake
- P / Escape — pause

Mobile controls are shown on screen in landscape mode and use Pointer Events for multi-touch-friendly steering, throttle and braking.

## Race setup
From the main menu choose **ИГРАТЬ**, then configure the event:
- Track: APEX CIRCUIT (the original built-in track)
- Opponents: 1–13 bots
- Laps: 3 / 5 / 7 / 10 / 15
- Difficulty: Easy / Medium / Hard

The selected settings are retained for Restart / ЕЩЁ РАЗ and are stored alongside the existing records in `localStorage`.

## HOW TO DEPLOY TO NETLIFY

1. Open Netlify.
2. Go to Netlify Drop.
3. Drag the extracted project folder / deploy folder.
4. Wait for deployment.
5. Open generated URL.

## Notes
- Sound is synthesized with Web Audio API and starts after a user gesture.
- Best Score, Best Lap, Max Laps, mute state and the latest race settings are stored in `localStorage`.
- Existing saves using the `velocityApex.v1` key remain compatible.
- There are no external network requests, CDN dependencies or framework dependencies.
