# Velocity Apex — test report

## Scope of this iteration

This report covers the Formula-style physics rewrite, precomputed racing-line/speed planner, traffic/overtaking AI and removal of race-camera pitch deformation. Existing UI/content/PWA files were intentionally left untouched where not required.

Binary comparison with the supplied ZIP confirms these files are unchanged:

- `index.html`
- `css/style.css`
- `js/controls.js`
- `js/content.js`
- `js/audio.js`
- `js/garage.js`
- `manifest.webmanifest`
- `netlify.toml`

The functional code changes are concentrated in `js/car.js`, `js/track.js`, `js/ai.js` and `js/game.js`.

## Static / syntax checks

All `js/*.js` and both standalone test scripts pass `node --check`.

Source checks confirm:

- race camera contains no `cam.pitch`;
- race world transform uses `ctx.scale(cam.zoom, cam.zoom)`;
- no difficulty-specific `maxSpeed`, `accel`, `brakePower` or `turnRate` multiplier remains in race car creation;
- existing `R.intersectCarOBBs()` SAT OBB helper remains in use;
- fixed/substep game physics remains `PHYSICS_STEP = 1/120` with bounded substeps.

## Player-physics smoke tests

`node tests/physics_smoke.js` runs deterministic direct physics scenarios against the real `Car.update()` implementation.

| Scenario | Result |
| --- | ---: |
| Fast asphalt turn at ~300 units/s | max slip **2.14°** |
| LEFT → RIGHT yaw sign change | **0.058 s** |
| LEFT → RIGHT max slip | **2.26°** |
| Slip 0.35 s after steering release | **0.02°** |
| Full brake + turn, 1 s from 310 | speed reduced to **26.4** |
| Full brake + turn max slip | **4.66°** |
| Off-road disturbed slip | **5.76°** |
| Slip 0.5 s after asphalt recovery | **0.00°** |

A forced barrier test also confirms the impact response drops speed and sets a temporary grip disturbance; SAT overlap detection remains functional for rotated car OBBs.

These results are consistent with the requested behavior: ordinary asphalt cornering stays close to the body direction, braking/impacts/grass can create additional slip, and steering release/reversal stabilizes quickly.

## Racing-line planner checks

The planner is built once per `Track`; the final line is closed and smoothed before line curvature and speed limits are calculated.

| Track | Max precomputed line offset | Max adjacent offset step |
| --- | ---: | ---: |
| Apex Circuit | 40.1 | 6.88 |
| Neon Harbor | 41.6 | 7.01 |
| Desert Canyon | 47.2 | 6.50 |
| Alpine Ring | 56.8 | 7.19 |
| Coastline GT | 54.6 | 7.21 |

Traffic logic can use substantially more road width than the base ideal line when a pass or side-by-side corridor requires it.

## AI single-car simulations — all tracks

`node tests/standalone_race_test.js` runs each difficulty at 60 Hz AI / 120 Hz physics for **3 complete laps** on every track. The same `Car`, `Track` and `AIController` used by the game are executed; there is no simplified movement model.

| Track | Medium avg lap | Hard avg lap | Extreme avg lap |
| --- | ---: | ---: | ---: |
| Apex Circuit | 32.00 s | 30.43 s | **29.76 s** |
| Neon Harbor | 29.28 s | 27.97 s | **27.43 s** |
| Desert Canyon | 40.98 s | 39.02 s | **38.22 s** |
| Alpine Ring | 40.72 s | 39.01 s | **38.28 s** |
| Coastline GT | 36.61 s | 34.81 s | **34.09 s** |

For all 15 three-lap runs:

- all requested laps completed;
- off-road time: **0.00 s**;
- barrier impacts: **0**;
- Extreme < Hard < Medium average lap time on every track;
- maximum measured normal-racing slip ranged from **2.88° to 3.33°**;
- Hard/Extreme use progressively more lateral track space than Medium.

The hierarchy therefore comes from better driving parameters/line use rather than higher physical car performance.

## Multi-car traffic simulations

The same test script also runs dense races with the production SAT OBB collision response copied from the game solver. A "confirmed pass" is counted only after a pair establishes more than 35 world units of longitudinal separation on the opposite ordering, reducing rank-jitter false positives.

| Scenario | Finishers | Off-road | Barrier impacts | Confirmed passes | Max lane spread | Heavy contact episodes* |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 8 cars · Neon Harbor · Hard · 2 laps | 8 / 8 | 0.00 s | 0 | 10 | 116.4 | 4 |
| 10 cars · Alpine Ring · Extreme · 2 laps | 10 / 10 | 0.00 s | 0 | 33 | 140.4 | 13 |
| 13 cars · Desert Canyon · Extreme · 2 laps | 13 / 13 | 0.00 s | 0 | 39 | 161.6 | 17 |

\* "Heavy" here means the start of a new OBB contact episode with relative normal closing speed > 50. Light wheel-to-wheel rubbing is counted separately and is expected to be more frequent in tightly packed AI-only fields.

The dense tests demonstrate that bots do not form a single centerline train: they spread laterally, complete passes, and all cars finish without the traffic fight turning into repeated barrier/off-road pileups. Hard/Extreme remain intentionally willing to run wheel-to-wheel, so contact is reduced rather than eliminated.

## Camera checks

Race camera code now has a strict isotropic transform:

```js
ctx.scale(cam.zoom, cam.zoom)
```

`cam.pitch` is absent from race camera state/update/draw code. A uniform scale followed by rotation preserves Euclidean lengths and aspect ratio, so a car at world headings 0°, ~45° and 90° has the same geometric length/width ratio. Look-ahead, speed zoom, rotation tracking and collision shake remain.

The attempted live headless-Chromium UI capture in this execution environment was blocked by an administrator policy (`ERR_BLOCKED_BY_ADMINISTRATOR`) for both localhost and `file://`. Therefore this iteration does **not** claim a fresh browser screenshot/UI automation pass. Camera geometry was instead checked through the actual source transform plus standalone invariants.

## iPhone / UI / PWA regression scope

The supplied iPhone UI and input implementation was preserved byte-for-byte: HTML, CSS, controls, content/economy, garage, manifest and hosting config are unchanged. In particular this avoids introducing regression risk to:

- ARROWS / TILT / WHEEL;
- steering + GAS and steering + BRAKE multitouch;
- safe-area / landscape layout;
- menu, setup, Settings, Shop and HUD markup;
- mini-map markup/style;
- save schema/economy;
- manifest / static PWA metadata.

`js/game.js` changes are limited to equalized car physical stats, impact-to-grip disturbance integration, and race-camera behavior. Lap counting, ranking, finish, rewards and mini-map code paths were not rewritten.

## Environment limitation / recommended device smoke test

A physical iPhone/Safari/PWA runtime is not available here, and local Chromium navigation is administratively blocked. Before release, perform one short device pass covering: landscape safe area, ARROWS multitouch, TILT permission, WHEEL, Pause/Continue, Shop/Settings return flow, and a few high-speed 45°/90° camera headings. The deterministic Node tests included in the project can be rerun independently with no dependencies.
