# Отчёт проверки Velocity Apex

## Финальная проверка этой версии

Проект проверен после добавления mini-map, нового Canvas renderer автомобилей, статических
деталей трассы, 2.5D camera transform и усиленной защиты iOS steering-кнопок. Базовая
архитектура сохранена: HTML/CSS/JavaScript/Canvas 2D, без npm, framework, CDN и внешних
runtime-зависимостей. Ключ сохранения остаётся `velocityApex.v1`.

Все `js/*.js` проходят `node --check`. В Chromium-прогоне не обнаружено новых
`pageerror`/console errors при переходах Main Menu → Shop → Settings → Race → Pause →
Continue. Garage Preview и карточки магазина реально отрисовывают тот же обновлённый
`Car.draw()`.

## iPhone landscape / HUD

Проверены viewport: `844×390`, `852×393`, `932×430`, `667×375`. Для первых трёх
дополнительно смоделированы боковые safe-area inset 47 / 47 / 59 px. В этих тестах нет
пересечений между mini-map/HUD center/HUD right, а также между mini-map, Pause и нижними
controls. На `667×375` mini-map автоматически уменьшается до компактного режима.

Mini-map использует отдельный Canvas. Геометрия трассы и start/finish запекаются один раз
в backing canvas; в игровом кадре рисуются только подготовленный bitmap и маркеры машин.
В основном кадре нет `getBoundingClientRect()`/пересчёта геометрии mini-map.

## iOS steering / multitouch

У steering-кнопок SVG вместо текстовых Unicode-стрелок, сохранены `aria-label`, а SVG имеет
`pointer-events:none` и `aria-hidden="true"`. Программно подтверждено, что `selectstart`,
`dragstart`, `dblclick` и touch default action отменяются, текст кнопки пуст и Selection
остаётся пустым.

Отдельно отправлены два независимых touch PointerEvent с разными pointerId одновременно:
левый руль + GAS. Фактический `InputController.getControl()` показал примерно
`steer=-0.99`, `throttle=1`, `brake=0`; после отпускания throttle возвращается в 0 и руль
плавно центрируется. То есть steering и педали не блокируют друг друга.

## Camera / renderer / track

Экранная позиция машины при `844×390` после стабилизации камеры измерена примерно как
`y=233 px` (`~59.7%` высоты). Camera pitch/zoom/look-ahead интерполируются и применяются
только к Canvas transform, не к физическим координатам.

Все пять тем трасс отдельно прогнаны через полный static renderer; кэш успешно создаётся
для `circuit`, `neon`, `desert`, `alpine`, `coast` без ошибок. Асфальтовая фактура,
статические тормозные следы, kerb depth, ground variations и scenery запекаются в cache.
Dynamic части остаются дешёвыми: cars, частицы, skid marks и маркеры mini-map.

## AI / физика / круги

Визуальные изменения не меняют collision box автомобиля и не меняют формулы `Car.update()`.
Дополнительно выполнен standalone smoke-test реальных `Track + Car.update + AIController`
на Medium: AI завершил полный круг на всех пяти трассах без offroad и barrier impacts:

| Трасса | 1 круг, с | Offroad | Barrier impacts |
| --- | ---: | ---: | ---: |
| Apex Circuit | 27.69 | 0.00 s | 0 |
| Neon Harbor | 26.03 | 0.00 s | 0 |
| Desert Canyon | 36.27 | 0.00 s | 0 |
| Alpine Ring | 37.47 | 0.00 s | 0 |
| Coastline GT | 33.45 | 0.00 s | 0 |

Этот прогон одновременно проверяет AI steering/throttle/brake, nearest-track lookup,
barriers и lap detection после текущих визуальных изменений.

## Ограничения среды

Физический iPhone/Safari/PWA runtime в этой среде недоступен, поэтому невозможно честно
измерить реальный FPS/GPU memory и системное меню iOS на конкретном устройстве. Safe Area,
pointer/touch paths и отмена browser gestures проверены программно; перед публичным релизом
полезен короткий финальный smoke-test на реальном iPhone в Safari и установленной PWA.
