# Velocity Apex — AI / trajectory planner test report

## Scope

This iteration is focused on racing AI, trajectory planning, linked-corner reasoning, braking/throttle control, controlled curb/shoulder use and dense traffic stability. The goal is minimum sector/lap time from better driving rather than any physics advantage for bots.

The major architectural change is the new precomputed `js/racing-line.js` planner. It works with `js/track.js`, `js/car.js` and `js/ai.js`; expensive trajectory work is performed when a `Track` is created and cached, not every physics frame.

## Algorithmic changes

### Time-oriented trajectory planner

The new planner no longer relies on one heavily smoothed curvature-lobe line. For Hard and Extreme it first runs a coarse second-order dynamic program across lateral states. Transitions are scored from real three-point path geometry so path length, curvature, lateral movement, smoothness and edge/surface risk compete directly.

Each detected corner group is then evaluated as a sector with candidate styles:

- conservative / normal;
- early / late apex;
- maximum-radius;
- attack;
- controlled curb cut;
- S-straightening;
- sacrifice-corner.

For each candidate the planner rebuilds the path geometry, recalculates curvature, derives lateral-speed limits, propagates braking backward and acceleration forward, estimates travel time, then adds small surface/risk/smoothness penalties. The lowest-scoring candidate is kept.

### Linked corners and S-sections

Apexes are grouped across a forward horizon into linked sectors. Sign changes in curvature identify left→right and right→left transitions. Groups can contain up to four apexes so the planner can sacrifice the first corner, preserve position for the next one and value the exit of the whole sequence rather than optimizing each apex independently.

The new line is lightly relaxed after optimization; it is not subjected to the old very high smoothing-pass count that could erase useful local apex movement.

### Shared asphalt / shoulder / true-offroad physics

The physical surface model is shared by player and AI:

- **asphalt** — full grip;
- **curb / narrow shoulder** — modest steering/grip/drag penalty while remaining driveable;
- **true off-road** — strong grip/traction/drag penalty;
- **barrier** — separate OBB-aware collision boundary.

Surface classification uses a wheel/contact envelope close to the visible car width, while barrier clearance uses the full orientation-aware 44-unit collision OBB. This allows brief two-wheel curb use without giving bots hidden grip or allowing the body to intersect the wall.

### Steering, braking and throttle

AI steering still uses a Pure-Pursuit-style controller, but the target is taken from the precomputed trajectory polyline at a dynamic distance. Look-ahead grows with speed, contracts near sharp apexes and is stabilized through quick direction changes.

Braking uses the cached speed profile plus a forward deceleration-demand calculation. Hard/Extreme use progressively more of the real brake capability. Brake release is reduced as the line opens on corner exit. Throttle uses hysteresis and exit-speed priority so the controller avoids repeated throttle→brake→throttle oscillation and can open throttle before the car is completely straight when the next profile samples are rising.

### Traffic

Traffic AI keeps the time-optimal line when clear, considers alternate lanes for passes, and reserves a separate side-by-side corridor. In dense packs the usable lateral envelope is reduced dynamically so three-wide traffic cannot simultaneously use both curb edges. The resulting safety reserve is traffic-only route selection; it does not change car grip, power, max speed or braking capability.

## Static / syntax checks

All JavaScript files are checked with `node --check`, including the new planner and sector test.

Required static-site architecture remains intact: no npm/runtime dependency was introduced, and `index.html` loads `js/racing-line.js` before `js/track.js`.

## Physics smoke test

Command:

```bash
node tests/physics_smoke.js
```

Key deterministic results:

| Scenario | Result |
| --- | ---: |
| Fast asphalt turn | max slip **2.14°** |
| LEFT → RIGHT yaw sign change | **0.058 s** |
| LEFT → RIGHT max slip | **2.26°** |
| Slip after steering release | **0.02°** |
| Full brake + turn | end speed **26.4** |
| Full brake + turn max slip | **4.66°** |
| Grass disturbed slip | **5.76°** |
| Recovered asphalt slip | **0.00°** |

The Extreme racing line also remains smooth: maximum adjacent lateral step is between **4.14** and **5.75** world units on all five tracks.

## BEFORE → AFTER single-car results

The BEFORE values are the deterministic baseline from the supplied project. AFTER uses the real `Track + Car + AIController` at 60 Hz AI / 120 Hz physics for three completed laps per difficulty.

| Track | Medium BEFORE → AFTER | Hard BEFORE → AFTER | Extreme BEFORE → AFTER | Extreme best | Barrier impacts | True off-road | Curb / shoulder | Max lateral usage |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Apex Circuit | 32.00 → **28.65 s** | 30.43 → **22.24 s** | 29.76 → **21.87 s** | **21.49 s** | 0 | 0.00 s | 0.00 s | 77.9 |
| Neon Harbor | 29.28 → **27.03 s** | 27.97 → **25.60 s** | 27.43 → **25.39 s** | **25.02 s** | 0 | 0.00 s | **2.07 s** | 78.5 |
| Desert Canyon | 40.98 → **36.88 s** | 39.02 → **32.29 s** | 38.22 → **31.70 s** | **31.37 s** | 0 | 0.00 s | **0.33 s** | 88.2 |
| Alpine Ring | 40.72 → **34.93 s** | 39.01 → **32.04 s** | 38.28 → **31.40 s** | **30.95 s** | 0 | 0.00 s | 0.00 s | 62.1 |
| Coastline GT | 36.61 → **37.29 s** | 34.81 → **30.78 s** | 34.09 → **30.16 s** | **29.88 s** | 0 | 0.00 s | 0.00 s | 53.1 |

Important observations:

- Hard and Extreme complete all requested laps on all five tracks.
- Extreme remains faster than Hard, and Hard faster than Medium, on every track.
- No single-car run enters true grass/off-road or hits a barrier.
- Controlled shoulder use now occurs on appropriate clean Extreme runs instead of being forced to zero everywhere.
- Shoulder use is selective: it is not added artificially to every track or every corner.
- Steering variation is materially lower than the old baseline on the fast difficulties; no major steering corrections were recorded in the deterministic single-car runs.

Coastline GT Medium is slightly slower than the old baseline, while Hard/Extreme are substantially faster. This is intentional: difficulty now differs more by line quality and physical-limit usage rather than making every level a scaled copy of the same trajectory.

## Sector / trajectory tests

Command:

```bash
node tests/trajectory_sector_test.js
```

The test searches the actual tracks for representative geometry instead of hardcoding a manual steering instruction at a track coordinate.

| Sector type | Representative result |
| --- | --- |
| Fast turn | Apex Circuit local path length reduced by **20.8%**, with 77.6 units of lateral offset |
| Hairpin | Neon Harbor apex target **47.5**, from **180.1** before apex to **182.1** after apex |
| Left → Right S | Neon Harbor straightness ratio **0.909 → 0.980** |
| Right → Left S | Neon Harbor straightness ratio **0.905 → 0.982** |
| Three-turn linked S | Neon Harbor straightness ratio **0.880 → 0.973** |
| Corner → long straight | Coastline GT target speed **106.9 → 345.4** over the exit, gain **238.4** |

The left/right S metrics use chord-length / driven-path-length over the linked section; a value closer to 1 means a straighter route through the combination. These tests therefore verify that the new line does not simply reproduce the centerline shape.

### Alpine Ring

Alpine Ring remains the main S-section stress track. Its Extreme average lap improves from **38.28 s to 31.40 s** with zero true-offroad time and zero barrier impacts. The planner detects several linked groups with curvature sign changes and the optimized line crosses the road earlier instead of chasing each centerline bend independently.

## Dense traffic tests

`tests/standalone_race_test.js` also runs deterministic dense AI-only races using the same OBB collision response as the game.

| Scenario | Finishers | True off-road | Shoulder | Barrier impacts | Contact episodes | Heavy contacts | Confirmed passes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 8 cars · Neon Harbor · Hard · 2 laps | 8 / 8 | 0.00 s | 0.00 s | 0 | 36 | 6 | 8 |
| 10 cars · Alpine Ring · Extreme · 2 laps | 10 / 10 | 0.00 s | 0.00 s | 0 | 30 | 10 | 5 |
| 13 cars · Desert Canyon · Extreme · 2 laps | 13 / 13 | **0.00 s** | 4.30 s | **0** | 24 | 6 | 10 |

The 13-car Desert Canyon case is specifically used as a regression guard against pack-induced grass excursions and barrier pileups. All cars finish, and the dense pack stays out of true off-road.

## How shoulder use is bounded

The planner distinguishes the nominal asphalt envelope from a narrow driveable margin. The margin is only a few world units beyond the car-center asphalt limit and remains far inside the physical barrier boundary. The line itself is additionally constrained by a curvature-aware inner-offset cap so a large offset cannot approach the singular region of a normal-offset curve on a tight corner.

The car then classifies the actual contact surface using its orientation-dependent wheel envelope. This means a small yaw angle can put the outer/inner tyres on the curb even when the car center remains safely inside the line corridor. The same calculation is used for player and bots.

True off-road remains slow because it retains substantially lower traction/steering authority and much larger drag. The AI also caps recovery speed and targets the track interior when true off-road is detected.

## Performance / iPhone considerations

- Dynamic programming and candidate-sector evaluation run only during track construction.
- Planner output, line points, segment lengths, curvature and recommended speed are cached on the Track.
- Per-car speed profiles are cached by car/difficulty parameters.
- Per-frame AI reuses small objects/arrays where practical and only performs short forward scans.
- No external dependency, worker, WebAssembly module or runtime solver was added.

The architecture therefore remains suitable for a static iPhone PWA and avoids global trajectory optimization inside the physics loop.

## Commands executed for final validation

```bash
node --check js/*.js
node --check tests/*.js
node tests/physics_smoke.js
node tests/standalone_race_test.js
node tests/trajectory_sector_test.js
```

All final quality gates pass: complete races, difficulty hierarchy, zero true off-road in single-car runs, zero single-car barrier impacts, controlled shoulder use on multiple Extreme tracks, wide track usage, full traffic completion, no traffic barrier pileup and controlled true-offroad time.
