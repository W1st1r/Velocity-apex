(function(){
  'use strict';
  const R=window.Racing,$=id=>document.getElementById(id);
  const formatCredits=value=>Math.max(0,Math.floor(Number(value)||0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g,' ');
  const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const categoryOf=item=>R.normalizeCarCategory(item&&item.category);
  const chanceText=bps=>(Math.max(0,Number(bps)||0)/100).toFixed(2).replace(/\.00$/,'')+'%';
  const assetUrl=src=>{
    if(typeof src!=='string'||!src)return '';
    if(/^(?:https?:|data:|blob:|\/)/i.test(src))return src;
    return '/'+src.replace(/^\.\//,'').replace(/^\/+/, '');
  };
  const effectVisualMarkup=(id,item)=>{
    if(id==='standard')return `<span class="effect-swatch standard" aria-hidden="true"><i>STD</i></span>`;
    const a=item.rainbow?'#70ff9d':(item.outer||'#61e8ff'),b=item.rainbow?'#ff58ce':(item.inner||'#efffff');
    return `<span class="effect-swatch ${item.rainbow?'rainbow':''}" style="--effect-a:${a};--effect-b:${b}" aria-hidden="true"><i></i><b></b><em></em></span>`;
  };
  const catalogVisualMarkup=(id,item,isCars)=>{
    if(!isCars)return effectVisualMarkup(id,item);
    const src=item?.sprite?.thumbnail||item?.sprite?.src;
    if(src)return `<span class="catalog-car-visual"><img class="catalog-car-thumb" src="${assetUrl(src)}" alt="" loading="lazy" decoding="async"><span class="catalog-car-fallback" aria-hidden="true">VA</span></span>`;
    return `<canvas class="catalog-fallback-canvas" width="280" height="112" aria-hidden="true"></canvas>`;
  };
  const badgeMarkup=id=>{
    const meta=R.CAR_CATEGORIES[id]||R.CAR_CATEGORIES.basic;
    return `<span class="rarity-badge ${meta.className}" data-rarity="${id}"><span class="rarity-icon" aria-hidden="true"><i></i></span><b>${meta.label}</b></span>`;
  };
  const rewardVisual=reward=>{
    if(reward.kind==='livery'&&reward.thumbnail)return `<span class="case-reward-visual car"><img src="${assetUrl(reward.thumbnail)}" alt="" loading="lazy" decoding="async"></span>`;
    const a=reward.rainbow?'#70ff9d':(reward.outer||'#61e8ff'),b=reward.rainbow?'#ff58ce':(reward.inner||'#efffff');
    return `<span class="case-reward-visual effect" style="--effect-a:${a};--effect-b:${b}" aria-hidden="true"><i></i><b></b></span>`;
  };
  const rewardRarity=reward=>reward.kind==='livery'?(R.CAR_CATEGORIES[reward.category]||R.CAR_CATEGORIES.basic):{label:'EFFECT',className:'rarity-effect',color:'#61E8FF'};

  class Garage{
    constructor(save,onChange){
      this.save=save;this.onChange=onChange;this.mode='shop';this.cards=[];this.categoryEmpty=false;this.activeCaseId=null;this.caseSpinning=false;this.caseSpinToken=0;this.caseQuantity=1;this.previewLoadToken=0;this.catalogPreloadToken=0;this.tuningTab='performance';this.tuningStylePurchase=null;this.pendingSell=null;this.upgradeQuoteTimer=0;this.upgradeQuoteToken=0;this.upgradeState={cars:[],effects:[],credits:0,target:null,chanceBps:0,stakeValue:0,targetValue:0,quoted:false,busy:false,pickerMode:'stake',pickerKind:'car',pickerCategory:'all',pickerSort:'asc'};
      this.state={
        shop:{tab:'livery',category:'all',previewLivery:save.selectedLivery,previewEffect:save.selectedEffect,previewCase:'all'},
        garage:{tab:'livery',category:'all',previewLivery:save.selectedLivery,previewEffect:save.selectedEffect}
      };
      this.car=new R.Car();this.car.x=280;this.car.y=190;this.car.angle=-.20;this.car.speed=260;this.car.throttleVisual=1;
      this.bindView('shop');this.bindView('garage');this.bindCaseDialog();this.bindTuning();this.bindSellDialog();this.bindUpgrade();
    }
    view(mode=this.mode){
      const prefix=mode==='shop'?'shop':'garage';
      return {
        tabs:$(prefix+'Tabs'),categories:$(prefix+'CategoryTabs'),items:$(prefix+'Items'),message:$(prefix+'Message'),
        preview:$(prefix+'Preview'),previewName:$(prefix+'PreviewName'),previewEffect:$(prefix+'PreviewEffect'),previewCopy:mode==='shop'?$('shopPreviewCopy'):null,caseHero:mode==='shop'?$('shopCaseHero'):null,
        credits:mode==='shop'?$('shopCredits'):$('garageCollection'),standardBody:mode==='garage'?$('garageStandardBody'):null,upgradePanel:mode==='garage'?$('garageUpgradePanel'):null
      };
    }
    caseDialog(){
      return {modal:$('caseModal'),title:$('caseModalTitle'),subtitle:$('caseModalSubtitle'),credits:$('caseModalCredits'),close:$('caseCloseBtn'),crate:$('caseModalCrate'),owned:$('caseOwnedCount'),price:$('casePriceLabel'),qtyMinus:$('caseQtyMinus'),qtyValue:$('caseQtyValue'),qtyPlus:$('caseQtyPlus'),buyBatch:$('caseBuyBatchBtn'),roulette:$('caseRoulette'),viewport:document.querySelector('#caseRoulette .case-roulette-viewport'),strip:$('caseRollStrip'),ready:$('caseReadyLabel'),result:$('caseResult'),open:$('caseOpenBtn'),rewardCount:$('caseRewardCount'),rewardList:$('caseRewardList')};
    }
    bindView(mode){
      const v=this.view(mode);if(!v.tabs||!v.categories||!v.items)return;
      v.tabs.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{this.mode=mode;this.state[mode].tab=b.dataset.tab;this.render();}));
      v.categories.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{this.mode=mode;this.state[mode].category=b.dataset.category;this.render();}));
      v.items.addEventListener('pointerdown',e=>{const card=e.target.closest('[data-item]');if(card&&this.state[mode].tab==='livery')this.prewarmLivery(card.dataset.item);},{passive:true});
      v.items.addEventListener('click',e=>this.handleItemsClick(mode,e));
    }
    bindCaseDialog(){
      const d=this.caseDialog();if(!d.modal)return;
      d.close.addEventListener('click',()=>this.closeCaseDialog());
      d.open.addEventListener('click',()=>this.spinActiveCase());
      d.buyBatch.addEventListener('click',()=>this.buyCaseBatch());
      d.qtyMinus.addEventListener('click',()=>this.setCaseQuantity(this.caseQuantity-1));
      d.qtyPlus.addEventListener('click',()=>this.setCaseQuantity(this.caseQuantity+1));
      d.modal.addEventListener('click',e=>{if(e.target===d.modal)this.closeCaseDialog();});
      document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!d.modal.classList.contains('hidden'))this.closeCaseDialog();});
    }
    bindSellDialog(){
      let modal=$('garageSellModal');
      if(!modal){
        modal=document.createElement('div');modal.id='garageSellModal';modal.className='garage-sell-modal hidden';modal.setAttribute('aria-hidden','true');
        modal.innerHTML=`<section class="garage-sell-card" role="dialog" aria-modal="true" aria-labelledby="garageSellTitle">
          <div class="garage-sell-kicker">СИСТЕМНАЯ ПРОДАЖА</div>
          <h3 id="garageSellTitle">ПРОДАТЬ МАШИНУ?</h3>
          <p id="garageSellQuestion"></p>
          <div class="garage-sell-breakdown">
            <span><small>МАШИНА + ТЮНИНГ</small><strong id="garageSellTotal">0 CR</strong></span>
            <span class="garage-sell-payout"><small>ВЫ ПОЛУЧИТЕ · 70%</small><strong id="garageSellPayout">0 CR</strong></span>
          </div>
          <p class="garage-sell-warning">Машина, улучшения, купленные цвета и винилы будут удалены из гаража. Отменить продажу после подтверждения нельзя.</p>
          <div class="garage-sell-actions"><button id="garageSellNo" type="button">НЕТ</button><button id="garageSellYes" type="button">ДА, ПРОДАТЬ</button></div>
        </section>`;
        document.body.appendChild(modal);
      }
      $('garageSellNo')?.addEventListener('click',()=>this.closeSellDialog());
      $('garageSellYes')?.addEventListener('click',()=>this.confirmSell());
      modal.addEventListener('click',e=>{if(e.target===modal)this.closeSellDialog();});
      document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.classList.contains('hidden'))this.closeSellDialog();});
    }
    openSellDialog(id){
      const item=R.LIVERIES?.[id],quote=R.getCarInvestmentValue?.(this.save,id),modal=$('garageSellModal');
      if(!item||!quote||quote.status!=='ok'||quote.payout<=0||!modal)return;
      this.pendingSell={id,payout:quote.payout};
      $('garageSellQuestion').textContent=`Вы точно хотите продать ${item.name} системе за 70% от всей вложенной суммы?`;
      $('garageSellTotal').textContent=`${formatCredits(quote.total)} CR`;
      $('garageSellPayout').textContent=`+${formatCredits(quote.payout)} CR`;
      modal.classList.remove('hidden');modal.setAttribute('aria-hidden','false');
      $('garageSellNo')?.focus();
    }
    closeSellDialog(){
      const modal=$('garageSellModal');if(!modal)return;
      modal.classList.add('hidden');modal.setAttribute('aria-hidden','true');this.pendingSell=null;
    }
    confirmSell(){
      const pending=this.pendingSell;if(!pending)return;
      const result=R.sellOwnedCar?.(this.save,pending.id,pending.payout),v=this.view('garage');
      if(result?.status==='sold'){
        this.pendingSell=null;this.closeSellDialog();
        for(const s of Object.values(this.state)){if(s.previewLivery===pending.id)s.previewLivery=this.save.selectedLivery;}
        v.message.textContent=`ПРОДАНО СИСТЕМЕ · +${formatCredits(result.payout)} CR · 70% ОТ МАШИНЫ И ТЮНИНГА`;
        v.message.classList.remove('warning');
        this.onChange();this.render();return;
      }
      if(result?.status==='stale'){
        this.pendingSell={id:pending.id,payout:result.quote.payout};
        $('garageSellTotal').textContent=`${formatCredits(result.quote.total)} CR`;
        $('garageSellPayout').textContent=`+${formatCredits(result.quote.payout)} CR`;
        v.message.textContent='Цена машины изменилась · сумма продажи пересчитана';v.message.classList.add('warning');return;
      }
      this.closeSellDialog();v.message.textContent=result?.status==='protected'?'БАЗОВАЯ МАШИНА НЕ ПРОДАЁТСЯ':'Продажа недоступна';v.message.classList.add('warning');this.render();
    }
    handleItemsClick(mode,e){
      const tuning=e.target.closest('[data-tune]');if(tuning&&mode==='garage'){this.openTuning(tuning.dataset.tune);return;}
      const caseCard=e.target.closest('[data-case]');
      if(caseCard&&mode==='shop'&&this.state.shop.tab==='case'){
        const id=caseCard.dataset.case;this.state.shop.previewCase=id;
        const buy=e.target.closest('.case-buy-btn'),open=e.target.closest('.case-owned-open-btn');
        if(buy||open)this.openCaseDialog(id);else this.render();
        return;
      }
      const card=e.target.closest('[data-item]');if(!card)return;
      this.mode=mode;const s=this.state[mode],id=card.dataset.item,action=e.target.closest('.purchase-btn,.select-btn,.sell-btn');
      const previewKey=s.tab==='livery'?'previewLivery':'previewEffect',changed=s[previewKey]!==id;s[previewKey]=id;
      // Preview taps are the hot path on iPhone. Do not rebuild dozens of car cards
      // just to move the preview highlight; update only the two affected cards and
      // the hero preview. Purchases/equips still use a full render because ownership changes.
      if(!action){if(changed)this.updatePreviewOnly(mode,id);return;}
      if(action&&mode==='garage'&&action.classList.contains('sell-btn')){this.openSellDialog(id);return;}
      if(action&&mode==='shop'&&action.classList.contains('purchase-btn')){
        const kind=s.tab,result=R.shopAction(this.save,kind,id),v=this.view(mode);
        v.message.textContent=result==='insufficient'?'НЕДОСТАТОЧНО CR':result==='purchased'?'КУПЛЕНО · предмет уже доступен в ГАРАЖЕ':'Предмет недоступен';
        v.message.classList.toggle('warning',result==='insufficient');
        if(result==='purchased')this.onChange();
      }else if(action&&mode==='garage'&&action.classList.contains('select-btn')){
        const result=R.selectOwned(this.save,s.tab,id),v=this.view(mode);
        v.message.textContent=result==='selected'?'ВЫБРАНО · готово к следующему заезду':'Предмет недоступен';
        v.message.classList.toggle('warning',result!=='selected');
        if(result==='selected')this.onChange();
      }
      this.render();
    }
    bindTuning(){
      const modal=$('tuningModal');if(!modal)return;
      $('tuningClose').addEventListener('click',()=>modal.close());
      modal.addEventListener('click',e=>{if(e.target===modal)modal.close();});
      modal.addEventListener('close',()=>{this.tuningPurchase=null;this.tuningStylePurchase=null;this.tuningTrigger?.focus();});
      modal.querySelectorAll('[data-tuning-tab]').forEach(b=>b.addEventListener('click',()=>{this.tuningTab=b.dataset.tuningTab==='appearance'?'appearance':'performance';this.tuningPurchase=null;this.tuningStylePurchase=null;this.renderTuning();}));
      $('tuningRows').addEventListener('click',e=>{
        const b=e.target.closest('[data-upgrade]');if(!b||b.disabled)return;
        this.tuningPurchase={key:b.dataset.upgrade,level:Number(b.dataset.level)};this.renderTuning();$('tuningConfirm').focus();
      });
      $('tuningCancel').addEventListener('click',()=>{this.tuningPurchase=null;this.renderTuning();});
      $('tuningConfirm').addEventListener('click',()=>{
        const pending=this.tuningPurchase;if(!pending)return;this.tuningPurchase=null;
        const result=R.buyCarUpgrade(this.save,this.tuningId,pending.key,pending.level);
        if(result.status==='purchased'){this.onChange();this.render();}
        this.renderTuning();$('tuningStatus').textContent=result.status==='purchased'?`Установлено · уровень ${result.level} · −${formatCredits(result.cost)} CR`:result.status==='insufficient'?'Недостаточно CR. Покупка не выполнена.':'Данные изменились. Выберите улучшение заново.';
      });
      const styleClick=e=>{
        const b=e.target.closest('[data-paint],[data-vinyl]');if(!b||b.disabled)return;
        const kind=b.dataset.paint?'color':'vinyl',value=b.dataset.paint||b.dataset.vinyl,c=R.getCarCustomization(this.save,this.tuningId),owned=kind==='color'?c.ownedColors:c.ownedVinyls;
        if(owned.includes(value)){
          const result=R.buyCarStyle(this.save,this.tuningId,kind,value);if(result.status==='applied'){this.onChange();this.render();this.renderTuning();$('tuningStatus').textContent='Стиль применён. Машина обновлена во всех режимах.';}
        }else{this.tuningStylePurchase={kind,value};this.renderTuning();$('tuningStyleConfirm').focus();}
      };
      $('tuningColorGrid').addEventListener('click',styleClick);$('tuningVinylGrid').addEventListener('click',styleClick);
      $('tuningStyleCancel').addEventListener('click',()=>{this.tuningStylePurchase=null;this.renderTuning();});
      $('tuningStyleConfirm').addEventListener('click',()=>{
        const pending=this.tuningStylePurchase;if(!pending)return;this.tuningStylePurchase=null;
        const result=R.buyCarStyle(this.save,this.tuningId,pending.kind,pending.value);
        if(result.status==='purchased'||result.status==='applied'){this.onChange();this.render();}
        this.renderTuning();$('tuningStatus').textContent=result.status==='purchased'?`Куплено и применено · −${formatCredits(result.cost)} CR`:result.status==='applied'?'Стиль применён.':result.status==='insufficient'?'Недостаточно CR для этого оформления.':'Не удалось применить оформление.';
      });
    }
    openTuning(id){
      if(!this.save.ownedLiveries.includes(id))return;
      this.tuningId=id;this.tuningPurchase=null;this.tuningStylePurchase=null;this.tuningTab='performance';this.tuningTrigger=document.activeElement;this.renderTuning();$('tuningStatus').textContent='Улучшения, цвет и винилы сохраняются отдельно для каждой машины.';
      $('tuningModal').showModal();$('tuningClose').focus();
    }
    renderTuning(){
      const id=this.tuningId,item=R.LIVERIES[id];if(!item)return;
      const levels=R.getUpgradeLevels(this.save,id),stats=R.getCarPerformance(id,this.save),base=R.CAR_PERFORMANCE[id],appearance=this.tuningTab==='appearance';
      $('tuningTitle').textContent=item.name;$('tuningCredits').textContent=formatCredits(this.save.credits)+' CR';
      $('tuningCategory').textContent=R.CAR_CATEGORIES[categoryOf(item)].label+' / '+Object.values(levels).reduce((a,b)=>a+b,0)+' ИЗ 15 УЛУЧШЕНИЙ';
      document.querySelectorAll('#tuningModal [data-tuning-tab]').forEach(b=>b.classList.toggle('selected',(b.dataset.tuningTab==='appearance')===appearance));
      $('tuningPerformancePanel').classList.toggle('hidden',appearance);$('tuningAppearancePanel').classList.toggle('hidden',!appearance);
      if(!appearance){
        $('tuningRows').innerHTML=Object.entries(R.UPGRADE_TYPES).map(([key,type])=>{
          const level=levels[key],cost=R.getUpgradeCost(id,key,level),max=level>=5,next=Math.round(base[type.stat]*(1+(level+1)*type.step)),missing=Math.max(0,(cost||0)-this.save.credits);
          return `<article class="tuning-row"><div class="tuning-row-heading"><strong>${type.name}</strong><span>УРОВЕНЬ ${level} / 5</span></div><p>${type.description}</p><div class="tuning-levels" aria-hidden="true">${Array.from({length:5},(_,i)=>`<i class="${i<level?'filled':''}"></i>`).join('')}</div><div class="tuning-values"><span>БАЗА <b>${base[type.stat]}</b></span><span>СЕЙЧАС <b>${stats[type.stat]}${key==='speed'?' км/ч':''}</b></span>${max?'':`<span>ДАЛЕЕ <b>${next}</b></span>`}</div><button type="button" data-upgrade="${key}" data-level="${level}" ${max||missing?'disabled':''}>${max?'✓ МАКСИМУМ':`УРОВЕНЬ ${level+1} · ${formatCredits(cost)} CR`}</button>${missing?`<small>Не хватает ${formatCredits(missing)} CR</small>`:''}</article>`;
        }).join('');
        const pending=this.tuningPurchase;$('tuningPurchase').classList.toggle('hidden',!pending);
        if(pending){const cost=R.getUpgradeCost(id,pending.key,pending.level);$('tuningPurchaseText').textContent=`${R.UPGRADE_TYPES[pending.key].name}: уровень ${pending.level+1}. Списать ${formatCredits(cost)} CR?`;$('tuningConfirm').disabled=cost===null||cost>this.save.credits;}
        return;
      }
      const c=R.getCarCustomization(this.save,id),style=R.getCarStyle(this.save,id),colorMeta=R.CAR_COLOR_MAP[c.colorId],vinylMeta=R.VINYL_MAP[c.vinylId],look=$('tuningLookPreview');
      look.style.setProperty('--paint',style.color||item.primary||'#8dff49');look.dataset.vinyl=c.vinylId;$('tuningLookCurrent').textContent=`${colorMeta.name} · ${vinylMeta.name}`;
      $('tuningColorGrid').innerHTML=R.CAR_COLORS.map(opt=>{const owned=c.ownedColors.includes(opt.id),selected=c.colorId===opt.id,cost=R.getPaintCost(id,opt.id),missing=!owned&&cost>this.save.credits;return `<button type="button" class="tuning-color ${selected?'selected':''}" data-paint="${opt.id}" ${missing?'disabled':''}><i style="--swatch:${opt.hex||item.primary||'#8dff49'}"></i><span><strong>${opt.name}</strong><small>${selected?'УСТАНОВЛЕНО':owned?'КУПЛЕНО':formatCredits(cost)+' CR'}</small></span>${selected?'<b>✓</b>':''}</button>`;}).join('');
      $('tuningVinylGrid').innerHTML=R.VINYLS.map(opt=>{const owned=c.ownedVinyls.includes(opt.id),selected=c.vinylId===opt.id,cost=R.getVinylCost(id,opt.id),missing=!owned&&cost>this.save.credits;return `<button type="button" class="tuning-vinyl ${selected?'selected':''}" data-vinyl="${opt.id}" data-vinyl-preview="${opt.id}" ${missing?'disabled':''}><i><em></em><b></b></i><span><strong>${opt.name}</strong><small>${opt.description}</small><mark>${selected?'УСТАНОВЛЕНО':owned?'КУПЛЕНО':formatCredits(cost)+' CR'}</mark></span></button>`;}).join('');
      const pending=this.tuningStylePurchase;$('tuningStylePurchase').classList.toggle('hidden',!pending);
      if(pending){const meta=pending.kind==='color'?R.CAR_COLOR_MAP[pending.value]:R.VINYL_MAP[pending.value],cost=pending.kind==='color'?R.getPaintCost(id,pending.value):R.getVinylCost(id,pending.value);$('tuningStylePurchaseText').textContent=`${meta.name}: купить для ${item.name} за ${formatCredits(cost)} CR? После покупки можно переключать бесплатно.`;$('tuningStyleConfirm').disabled=cost>this.save.credits;}
    }
    prewarmLivery(id){
      const item=R.LIVERIES[id],src=item?.sprite?.src;if(src&&R.preloadSprite)R.preloadSprite(src);
    }
    upgradeErrorText(code){
      return ({AUTH_REQUIRED:'Войдите в аккаунт, чтобы использовать Upgrade.',STAKE_REQUIRED:'Добавьте хотя бы один предмет или CR.',TARGET_REQUIRED:'Выберите цель.',INSUFFICIENT_CREDITS:'Недостаточно CR.',PROTECTED_ITEM:'Базовые предметы нельзя использовать.',CAR_NOT_OWNED:'Одна из машин больше не принадлежит вам.',EFFECT_NOT_OWNED:'Один из эффектов больше не принадлежит вам.',TARGET_ALREADY_OWNED:'Этот предмет уже есть в гараже.',TARGET_UNAVAILABLE:'Эта цель временно недоступна.',TARGET_NOT_HIGHER:'Цель должна быть дороже общей ставки.',CHANCE_TOO_LOW:'Стоимость ставки слишком мала для этой цели.',TOO_MANY_ITEMS:'Можно поставить максимум 12 предметов.',UPGRADE_PROCESSING:'Upgrade уже обрабатывается сервером.',UPGRADE_SERVER_ERROR:'Ошибка сервера Upgrade. Попробуйте ещё раз.'}[code]||'Не удалось выполнить Upgrade. Проверьте выбор и соединение.');
    }
    async upgradeApi(path,body){
      const r=await fetch(path,{method:body===undefined?'GET':'POST',credentials:'same-origin',headers:{'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});let data={};try{data=await r.json();}catch{}if(!r.ok)throw Object.assign(new Error(data.error||'UPGRADE_ERROR'),{code:data.error||'UPGRADE_ERROR',data});return data;
    }
    bindUpgrade(){
      if(!$('garageUpgradePanel'))return;
      $('upgradeAddItems')?.addEventListener('click',()=>this.openUpgradePicker('stake'));
      $('upgradeChooseTarget')?.addEventListener('click',()=>this.openUpgradePicker('target'));
      $('upgradeCreditsInput')?.addEventListener('input',e=>{const max=Math.max(0,Math.floor(Number(this.save.credits)||0)),value=Math.max(0,Math.min(max,Math.floor(Number(e.target.value)||0)));this.upgradeState.credits=value;e.target.value=String(value);this.upgradeState.quoted=false;this.renderUpgrade();this.scheduleUpgradeQuote();});
      document.querySelectorAll('[data-upgrade-credit]').forEach(b=>b.addEventListener('click',()=>{const max=Math.max(0,Math.floor(Number(this.save.credits)||0)),v=b.dataset.upgradeCredit==='max'?max:Math.min(max,this.upgradeState.credits+Math.max(0,Number(b.dataset.upgradeCredit)||0));this.upgradeState.credits=Math.floor(v);this.upgradeState.quoted=false;this.renderUpgrade();this.scheduleUpgradeQuote();}));
      $('upgradeStart')?.addEventListener('click',()=>this.openUpgradeConfirm());
      $('upgradeConfirmCancel')?.addEventListener('click',()=>$('upgradeConfirmModal')?.close());
      $('upgradeConfirmStart')?.addEventListener('click',()=>this.performUpgrade());
      $('upgradePickerClose')?.addEventListener('click',()=>this.closeUpgradePicker());
      $('upgradePickerDone')?.addEventListener('click',()=>this.closeUpgradePicker());
      $('upgradePicker')?.addEventListener('click',e=>{if(e.target===$('upgradePicker'))this.closeUpgradePicker();});
      document.querySelectorAll('[data-upgrade-picker-kind]').forEach(b=>b.addEventListener('click',()=>{this.upgradeState.pickerKind=b.dataset.upgradePickerKind==='effect'?'effect':'car';this.upgradeState.pickerCategory='all';this.renderUpgradePicker();}));
      $('upgradePickerCategories')?.addEventListener('click',e=>{const sort=e.target.closest('[data-upgrade-sort]');if(sort){this.upgradeState.pickerSort=this.upgradeState.pickerSort==='desc'?'asc':'desc';this.renderUpgradePicker();return;}const b=e.target.closest('[data-upgrade-category]');if(!b)return;this.upgradeState.pickerCategory=b.dataset.upgradeCategory||'all';this.renderUpgradePicker();});
      $('upgradePickerList')?.addEventListener('click',e=>{const b=e.target.closest('[data-upgrade-pick]');if(!b)return;this.toggleUpgradePickerItem(b.dataset.kind,b.dataset.upgradePick);});
      $('upgradeHistoryBtn')?.addEventListener('click',()=>this.openUpgradeHistory());
      $('upgradeHistoryClose')?.addEventListener('click',()=>$('upgradeHistoryModal')?.close());
    }
    cleanUpgradeSelection(){
      const u=this.upgradeState,ownedCars=new Set(this.save.ownedLiveries||[]),ownedEffects=new Set(this.save.ownedEffects||[]);u.cars=u.cars.filter(id=>id!=='apexLime'&&ownedCars.has(id)&&R.LIVERIES[id]);u.effects=u.effects.filter(id=>id!=='standard'&&ownedEffects.has(id)&&R.EFFECTS[id]);u.credits=Math.max(0,Math.min(Math.floor(Number(this.save.credits)||0),Math.floor(Number(u.credits)||0)));if(u.target){const owned=u.target.kind==='car'?ownedCars:ownedEffects;if(owned.has(u.target.id))u.target=null;}
    }
    upgradeLocalStakeValue(){const u=this.upgradeState;return u.cars.reduce((sum,id)=>sum+Math.max(0,Number(R.LIVERIES[id]?.price)||0),0)+u.effects.reduce((sum,id)=>sum+Math.max(0,Number(R.EFFECTS[id]?.price)||0),0)+u.credits;}
    upgradeVisual(kind,id,compact=false){
      const item=kind==='car'?R.LIVERIES[id]:R.EFFECTS[id];if(!item)return '';
      if(kind==='car'){const src=item.sprite?.thumbnail||item.sprite?.src;return src?`<span class="upgrade-mini-visual car"><img src="${assetUrl(src)}" alt=""></span>`:`<span class="upgrade-mini-visual car fallback">VA</span>`;}
      return `<span class="upgrade-mini-visual effect">${effectVisualMarkup(id,item)}</span>`;
    }
    renderUpgrade(reschedule=false){
      const u=this.upgradeState;this.cleanUpgradeSelection();const authed=!!window.VelocityAccount?.authenticated,localStake=this.upgradeLocalStakeValue(),stakeValue=u.quoted?u.stakeValue:localStake,targetItem=u.target?(u.target.kind==='car'?R.LIVERIES[u.target.id]:R.EFFECTS[u.target.id]):null,targetValue=u.quoted?u.targetValue:Math.max(0,Number(targetItem?.price)||0),chance=Math.max(0,Math.min(9000,Math.floor(Number(u.chanceBps)||0)));
      $('upgradeStakeValue').textContent=formatCredits(stakeValue)+' CR';$('upgradeTargetValue').textContent=targetValue?formatCredits(targetValue)+' CR':'—';$('upgradeBalanceLabel').textContent='БАЛАНС · '+formatCredits(this.save.credits)+' CR';$('upgradeCreditsInput').value=String(u.credits);
      const chips=[...u.cars.map(id=>({kind:'car',id,item:R.LIVERIES[id]})),...u.effects.map(id=>({kind:'effect',id,item:R.EFFECTS[id]}))];
      $('upgradeStakeItems').innerHTML=chips.length?chips.map(x=>`<button type="button" class="upgrade-stake-chip" data-upgrade-remove="${escapeHtml(x.id)}" data-kind="${x.kind}">${this.upgradeVisual(x.kind,x.id,true)}<span><strong>${escapeHtml(x.item?.name||x.id)}</strong><small>${formatCredits(x.item?.price||0)} CR</small></span><b>×</b></button>`).join(''):'<span class="upgrade-empty">Добавьте машины или эффекты</span>';
      $('upgradeStakeItems').querySelectorAll('[data-upgrade-remove]').forEach(b=>b.onclick=()=>{const key=b.dataset.kind==='effect'?'effects':'cars';u[key]=u[key].filter(id=>id!==b.dataset.upgradeRemove);u.quoted=false;this.renderUpgrade();this.scheduleUpgradeQuote();});
      $('upgradeTargetItem').innerHTML=u.target&&targetItem?`${this.upgradeVisual(u.target.kind,u.target.id)}<span><strong>${escapeHtml(targetItem.name)}</strong><small>${u.target.kind==='car'?escapeHtml(String(targetItem.category||'basic').toUpperCase()):'EFFECT'} · ${formatCredits(targetItem.price||0)} CR</small></span>`:'<span class="upgrade-empty">Выберите предмет</span>';
      const deg=(chance/10000)*360,wheel=$('upgradeWheel');wheel.style.setProperty('--upgrade-chance',deg+'deg');if(!u.busy&&!u.target){wheel.style.transition='none';wheel.style.transform='rotate(0deg)';}$('upgradeChance').textContent=(chance/100).toFixed(chance%100?2:0).replace(/\.00$/,'')+'%';$('upgradeOddsText').textContent=u.quoted&&chance?`SUCCESS ${chance/100}% · FAILED ${(10000-chance)/100}%`:u.target?'Расчёт серверного шанса…':'Выберите цель';
      const ready=authed&&!u.busy&&u.quoted&&chance>=100&&u.target&&(u.cars.length||u.effects.length||u.credits>0);$('upgradeStart').disabled=!ready;$('upgradeStart').textContent=u.busy?'ОБРАБОТКА…':'UPGRADE';
      if(!authed)$('upgradeStatus').textContent='Войдите в аккаунт — Upgrade работает только с облачным инвентарём.';else if(u.busy)$('upgradeStatus').textContent='Сервер фиксирует результат…';else if(!u.target)$('upgradeStatus').textContent='Выберите предмет, который хотите получить.';else if(!(u.cars.length||u.effects.length||u.credits))$('upgradeStatus').textContent='Добавьте предметы или CR в ставку.';else if(!u.quoted)$('upgradeStatus').textContent='Проверяем точный шанс на сервере…';else $('upgradeStatus').textContent=`Ставка ${formatCredits(stakeValue)} CR → цель ${formatCredits(targetValue)} CR`;
      if(reschedule)this.scheduleUpgradeQuote();
    }
    scheduleUpgradeQuote(){
      clearTimeout(this.upgradeQuoteTimer);const u=this.upgradeState;if(this.mode!=='garage'||this.state.garage.tab!=='upgrade'||u.busy)return;if(!window.VelocityAccount?.authenticated||!u.target||(!u.cars.length&&!u.effects.length&&!u.credits)){u.quoted=false;u.chanceBps=0;u.stakeValue=this.upgradeLocalStakeValue();u.targetValue=Math.max(0,Number((u.target?.kind==='car'?R.LIVERIES[u.target?.id]:R.EFFECTS[u.target?.id])?.price)||0);this.renderUpgrade();return;}
      const token=++this.upgradeQuoteToken;this.upgradeQuoteTimer=setTimeout(async()=>{try{const d=await this.upgradeApi('/api/upgrade/quote',{stake:{cars:u.cars,effects:u.effects,credits:u.credits},target:u.target});if(token!==this.upgradeQuoteToken)return;u.stakeValue=d.stakeValue;u.targetValue=d.targetValue;u.chanceBps=d.chanceBps;u.quoted=true;this.renderUpgrade();}catch(e){if(token!==this.upgradeQuoteToken)return;u.quoted=false;u.chanceBps=Number(e.data?.chanceBps)||0;u.stakeValue=Number(e.data?.stakeValue)||this.upgradeLocalStakeValue();u.targetValue=Number(e.data?.targetValue)||0;this.renderUpgrade();$('upgradeStatus').textContent=this.upgradeErrorText(e.code);}},140);
    }
    openUpgradePicker(mode){
      if(!window.VelocityAccount?.authenticated){window.VelocityAccount?.requestAuth?.('Чтобы использовать Upgrade, войдите в аккаунт или зарегистрируйтесь.');return;}
      const u=this.upgradeState;u.pickerMode=mode==='target'?'target':'stake';u.pickerKind='car';u.pickerCategory='all';u.pickerSort='asc';$('upgradePicker').classList.remove('hidden');$('upgradePicker').setAttribute('aria-hidden','false');$('upgradePickerTitle').textContent=u.pickerMode==='target'?'ВЫБЕРИТЕ ЦЕЛЬ':'ДОБАВЬТЕ В СТАВКУ';this.renderUpgradePicker();
    }
    closeUpgradePicker(){const m=$('upgradePicker');if(!m)return;m.classList.add('hidden');m.setAttribute('aria-hidden','true');}
    renderUpgradePicker(){
      const u=this.upgradeState,kind=u.pickerKind;document.querySelectorAll('[data-upgrade-picker-kind]').forEach(b=>b.classList.toggle('selected',b.dataset.upgradePickerKind===kind));$('upgradePickerCategories').classList.toggle('hidden',kind!=='car');$('upgradePickerCategories').querySelectorAll('[data-upgrade-category]').forEach(b=>b.classList.toggle('selected',b.dataset.upgradeCategory===u.pickerCategory));const sortBtn=$('upgradePickerSort');if(sortBtn){sortBtn.dataset.upgradeSort=u.pickerSort;sortBtn.textContent=u.pickerSort==='desc'?'ЦЕНА ↓':'ЦЕНА ↑';}
      let entries=[];if(kind==='car'){
        const ids=u.pickerMode==='stake'?(this.save.ownedLiveries||[]):(R.REAL_CAR_IDS||Object.keys(R.LIVERIES));entries=ids.filter(id=>id!=='apexLime'&&R.LIVERIES[id]&&(u.pickerMode==='stake'||(!this.save.ownedLiveries.includes(id)&&R.carAvailable(id)))).map(id=>[id,R.LIVERIES[id]]);if(u.pickerCategory!=='all')entries=entries.filter(([,item])=>categoryOf(item)===u.pickerCategory);
      }else{const ids=u.pickerMode==='stake'?(this.save.ownedEffects||[]):Object.keys(R.EFFECTS);entries=ids.filter(id=>id!=='standard'&&R.EFFECTS[id]&&(u.pickerMode==='stake'||!this.save.ownedEffects.includes(id))).map(id=>[id,R.EFFECTS[id]]);}
      const localStake=this.upgradeLocalStakeValue();if(u.pickerMode==='target'&&localStake>0)entries=entries.filter(([,item])=>Number(item.price)>localStake);entries.sort((a,b)=>(u.pickerSort==='desc'?-1:1)*((Number(a[1].price)||0)-(Number(b[1].price)||0)));
      $('upgradePickerList').innerHTML=entries.length?entries.map(([id,item])=>{const selected=u.pickerMode==='target'?u.target?.kind===kind&&u.target?.id===id:(kind==='car'?u.cars:u.effects).includes(id);return `<button type="button" class="upgrade-picker-item ${selected?'selected':''}" data-upgrade-pick="${escapeHtml(id)}" data-kind="${kind}">${this.upgradeVisual(kind,id)}<span><strong>${escapeHtml(item.name)}</strong><small>${kind==='car'?escapeHtml(String(item.category||'basic').toUpperCase())+' · ':''}${formatCredits(item.price||0)} CR</small></span><b>${selected?'✓':'+'}</b></button>`;}).join(''):'<div class="upgrade-picker-empty">Нет подходящих предметов. Измените ставку или категорию.</div>';
      const selectedCount=u.cars.length+u.effects.length;$('upgradePickerStatus').textContent=u.pickerMode==='target'?'Выберите одну цель':`В ставке: ${selectedCount} / 12`;$('upgradePickerDone').classList.toggle('hidden',u.pickerMode==='target');
    }
    toggleUpgradePickerItem(kind,id){
      const u=this.upgradeState;if(u.pickerMode==='target'){u.target={kind:kind==='effect'?'effect':'car',id};u.quoted=false;this.closeUpgradePicker();this.renderUpgrade();this.scheduleUpgradeQuote();return;}
      const key=kind==='effect'?'effects':'cars',list=u[key],exists=list.includes(id);if(!exists&&u.cars.length+u.effects.length>=12){$('upgradePickerStatus').textContent='Максимум 12 предметов.';return;}u[key]=exists?list.filter(x=>x!==id):[...list,id];u.quoted=false;this.renderUpgradePicker();this.renderUpgrade();this.scheduleUpgradeQuote();
    }
    openUpgradeConfirm(){
      const u=this.upgradeState;if(!u.quoted||u.busy||!u.target)return;const item=u.target.kind==='car'?R.LIVERIES[u.target.id]:R.EFFECTS[u.target.id],dlg=$('upgradeConfirmModal');$('upgradeConfirmSummary').innerHTML=`<div><span>СТАВКА</span><strong>${formatCredits(u.stakeValue)} CR</strong></div><div><span>ЦЕЛЬ</span><strong>${escapeHtml(item?.name||u.target.id)}</strong></div><div><span>СТОИМОСТЬ ЦЕЛИ</span><strong>${formatCredits(u.targetValue)} CR</strong></div><div><span>ШАНС</span><strong>${(u.chanceBps/100).toFixed(2).replace(/\.00$/,'')}%</strong></div>`;dlg?.showModal();
    }
    async performUpgrade(){
      const u=this.upgradeState;if(u.busy||!u.quoted||!u.target)return;$('upgradeConfirmModal')?.close();u.busy=true;this.renderUpgrade();const upgradeId=crypto.randomUUID();
      try{const d=await this.upgradeApi('/api/upgrade/attempt',{upgradeId,stake:{cars:u.cars,effects:u.effects,credits:u.credits},target:u.target});await this.animateUpgradeResult(d.attempt);}catch(e){u.busy=false;u.quoted=false;this.renderUpgrade();$('upgradeStatus').textContent=this.upgradeErrorText(e.code);this.scheduleUpgradeQuote();}
    }
    animateUpgradeResult(attempt){
      return new Promise(resolve=>{const u=this.upgradeState,wheel=$('upgradeWheel'),chance=Math.max(0,Math.min(9000,Number(attempt?.chanceBps)||0)),ticket=Math.max(0,Math.min(9999,Number(attempt?.rngValue)||0)),success=!!attempt?.success,targetName=attempt?.result?.target?.name||'предмет';u.chanceBps=chance;u.stakeValue=Number(attempt?.stakeValue)||u.stakeValue;u.targetValue=Number(attempt?.targetValue)||u.targetValue;u.quoted=true;this.renderUpgrade();wheel.classList.remove('upgrade-spinning');wheel.style.transition='none';wheel.style.transform='rotate(0deg)';void wheel.offsetWidth;wheel.classList.add('upgrade-spinning');const turns=6*360-ticket/10000*360;wheel.style.transition='transform 3.6s cubic-bezier(.08,.72,.08,1)';wheel.style.transform=`rotate(${turns}deg)`;$('upgradeStatus').textContent='Колесо вращается · результат уже зафиксирован сервером';try{navigator.vibrate?.(18);}catch{}
        let done=false;const finish=async()=>{if(done)return;done=true;wheel.classList.remove('upgrade-spinning');u.busy=false;$('upgradeStatus').textContent=success?`SUCCESS · ${targetName} добавлен в гараж`:'FAILED · ставка потеряна';$('garageMessage').textContent=success?`UPGRADE SUCCESS · ${targetName}`:'UPGRADE FAILED · попробуйте другую ставку';$('garageMessage').classList.toggle('warning',!success);try{navigator.vibrate?.(success?[35,55,70]:[80,55,80]);}catch{}await window.VelocityAccount?.refreshCloud?.();u.cars=[];u.effects=[];u.credits=0;u.target=null;u.chanceBps=0;u.stakeValue=0;u.targetValue=0;u.quoted=false;this.renderUpgrade();resolve();};wheel.addEventListener('transitionend',finish,{once:true});setTimeout(finish,3900);});
    }
    async openUpgradeHistory(){
      const dlg=$('upgradeHistoryModal'),list=$('upgradeHistoryList');if(!window.VelocityAccount?.authenticated){window.VelocityAccount?.requestAuth?.('История Upgrade доступна после входа.');return;}list.innerHTML='<div class="upgrade-history-empty">Загрузка…</div>';dlg?.showModal();try{const d=await this.upgradeApi('/api/upgrade/history');list.innerHTML=d.items?.length?d.items.map(x=>{const target=x.result?.target||x.target||{},ok=x.status==='complete'&&x.success,rejected=x.status==='rejected',label=rejected?'REJECTED':ok?'SUCCESS':'FAILED';return `<article class="upgrade-history-row ${ok?'success':'failed'}"><div><strong>${label}</strong><small>${new Date(x.createdAt).toLocaleString('ru-RU')}</small></div><span>${escapeHtml(target.name||target.id||'TARGET')}</span><b>${formatCredits(x.stakeValue)} → ${formatCredits(x.targetValue)} CR</b><em>${(x.chanceBps/100).toFixed(2).replace(/\.00$/,'')}%</em></article>`;}).join(''):'<div class="upgrade-history-empty">Upgrade ещё не запускались.</div>';}catch(e){list.innerHTML='<div class="upgrade-history-empty">Не удалось загрузить историю.</div>';}
    }
    scheduleCatalogPreload(entries,mode){
      const token=++this.catalogPreloadToken,limit=mode==='garage'?entries.length:Math.min(entries.length,14),queue=entries.slice(0,limit);
      queue.forEach(([id,item],index)=>setTimeout(()=>{if(token!==this.catalogPreloadToken)return;const src=item?.sprite?.src;if(src&&R.preloadSprite)R.preloadSprite(src);},35+index*65));
    }
    setPreviewCar(liveryId,effectId){
      const item=R.LIVERIES[liveryId],src=item?.sprite?.src,token=++this.previewLoadToken,apply=()=>{this.car.setLoadout(liveryId,effectId,'preview');this.car.setCustomization(R.getCarStyle(this.save,liveryId));};
      if(!src||!R.preloadSprite){apply();return;}
      R.preloadSprite(src).then(()=>{if(token!==this.previewLoadToken)return;const s=this.state[this.mode];if(s?.previewLivery!==liveryId||s?.previewEffect!==effectId)return;apply();});
    }
    syncPreviewChip(card,isPreview,isSelected){
      if(!card)return;card.classList.toggle('previewing',isPreview);card.dataset.previewed=isPreview?'true':'false';
      const button=card.querySelector('.item-preview');if(button)button.setAttribute('aria-pressed',String(isPreview));
      let chip=card.querySelector('.item-preview-state');
      if(isSelected){if(!chip){chip=document.createElement('span');chip.className='item-preview-state';button?.appendChild(chip);}chip.className='item-preview-state active';chip.textContent='АКТИВНО';}
      else if(isPreview){if(!chip){chip=document.createElement('span');chip.className='item-preview-state';button?.appendChild(chip);}chip.className='item-preview-state';chip.textContent='ПРОСМОТР';}
      else if(chip)chip.remove();
    }
    updatePreviewOnly(mode,id){
      const s=this.state[mode],v=this.view(mode),isCars=s.tab==='livery',previewKey=isCars?'previewLivery':'previewEffect',selected=this.save[isCars?'selectedLivery':'selectedEffect'];
      const previous=v.items.querySelector('[data-previewed="true"]'),next=v.items.querySelector(`[data-item="${CSS.escape(id)}"]`);
      if(previous&&previous!==next)this.syncPreviewChip(previous,false,previous.dataset.item===selected);
      this.syncPreviewChip(next,true,id===selected);
      if(isCars)this.setPreviewCar(id,s.previewEffect);else this.setPreviewCar(s.previewLivery,id);
      v.previewName.textContent=R.LIVERIES[s.previewLivery].name;
      v.previewEffect.textContent=R.EFFECTS[s.previewEffect].name+(mode==='garage'?' · '+(s[previewKey]===selected?'АКТИВНО':'ПРЕДПРОСМОТР'):'');
    }
    open(mode='shop'){
      this.mode=mode;const s=this.state[mode];
      s.previewLivery=this.save.selectedLivery;s.previewEffect=this.save.selectedEffect;s.tab='livery';s.category='all';if(mode==='shop')s.previewCase='all';
      this.render();const v=this.view(mode);
      v.message.textContent=mode==='shop'?'Кредиты начисляются за завершённые гонки.':'Выберите машину и эффект из своей коллекции.';
      v.message.classList.remove('warning');
    }
    syncFromSave(){
      for(const s of Object.values(this.state)){s.previewLivery=this.save.selectedLivery;s.previewEffect=this.save.selectedEffect;}
      this.render();
      if($('tuningModal')?.open){this.tuningPurchase=null;this.tuningStylePurchase=null;if(this.save.ownedLiveries.includes(this.tuningId))this.renderTuning();else $('tuningModal').close();}
      if(this.activeCaseId&&!this.caseDialog().modal.classList.contains('hidden')&&!this.caseSpinning)this.refreshCaseDialogInventory();
    }
    render(){
      const mode=this.mode,s=this.state[mode],v=this.view(mode),isCars=s.tab==='livery',isCases=mode==='shop'&&s.tab==='case',isUpgrade=mode==='garage'&&s.tab==='upgrade';
      if(!v.tabs)return;
      if(mode==='shop')v.credits.textContent=formatCredits(this.save.credits)+' CR';
      else v.credits.textContent=isUpgrade?formatCredits(this.save.credits)+' CR':`COLLECTION ${this.save.ownedLiveries.length + this.save.ownedEffects.length}`;
      v.tabs.querySelectorAll('button').forEach(b=>{const active=b.dataset.tab===s.tab;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));});
      if(isUpgrade){v.standardBody?.classList.add('hidden');v.upgradePanel?.classList.remove('hidden');$('garage')?.classList.add('upgrade-open');v.categories.classList.add('hidden');this.renderUpgrade();this.scheduleUpgradeQuote();return;}
      v.standardBody?.classList.remove('hidden');v.upgradePanel?.classList.add('hidden');$('garage')?.classList.remove('upgrade-open');
      v.categories.classList.toggle('hidden',!isCars);
      v.categories.querySelectorAll('button').forEach(b=>{const active=b.dataset.category===s.category;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));});
      if(isCases){this.renderCases(v,s);return;}
      if(v.caseHero)v.caseHero.classList.add('hidden');if(v.preview)v.preview.classList.remove('hidden');if(v.previewCopy)v.previewCopy.textContent='Предпросмотр коллекции. Покупка не меняет активный loadout.';
      this.renderCatalog(v,s,isCars,mode);
    }
    renderCatalog(v,s,isCars,mode){
      const owned=this.save[isCars?'ownedLiveries':'ownedEffects'],selected=this.save[isCars?'selectedLivery':'selectedEffect'];
      let entries=R.getCatalogEntries(this.save,mode,s.tab,s.category);
      this.categoryEmpty=isCars&&entries.length===0;
      const previewKey=isCars?'previewLivery':'previewEffect';
      if(entries.length&&!entries.some(([id])=>id===s[previewKey])){const selectedEntry=entries.find(([id])=>id===selected);s[previewKey]=(selectedEntry||entries[0])[0];}
      if(this.categoryEmpty){
        const cat=R.CAR_CATEGORIES[s.category]||R.CAR_CATEGORIES.all,title=mode==='shop'?'СКОРО':'В ГАРАЖЕ ПОКА НЕТ МАШИН ЭТОЙ КАТЕГОРИИ',copy=mode==='shop'?'Новые автомобили этой категории уже готовятся.':'Найдите и приобретите их в магазине.';
        v.items.innerHTML=`<div class="shop-empty ${cat.className}" role="status">${badgeMarkup(s.category==='all'?'basic':s.category)}<strong>${title}</strong><span>${copy}</span></div>`;
      }else{
        v.items.innerHTML=entries.map(([id,item])=>{
          const isOwned=owned.includes(id),isSelected=selected===id,isPreview=s[previewKey]===id,cat=isCars?categoryOf(item):null,status=isSelected?'ВЫБРАНО':isOwned?'КУПЛЕНО':'ЗАКРЫТО';
          const priceText=mode==='shop'?(item.price?formatCredits(item.price)+' CR':'FREE'):(isSelected?'АКТИВНО':'В КОЛЛЕКЦИИ');
          const shortfall=Math.max(0,(item.price||0)-this.save.credits),shortfallText=mode==='shop'&&!isOwned&&shortfall>0?`<div class="item-shortfall">ЕЩЁ ${formatCredits(shortfall)} CR</div>`:'';
          let button='';if(mode==='shop')button=isOwned?`<button type="button" class="purchase-btn owned" disabled>КУПЛЕНО</button>`:`<button type="button" class="purchase-btn">КУПИТЬ — ${formatCredits(item.price)} CR</button>`;else button=`<button type="button" class="select-btn ${isSelected?'equipped':''}" ${isSelected?'disabled':''}>${isSelected?'✓ АКТИВНО':'ВЫБРАТЬ'}</button>`;
          if(isCars&&!R.carAvailable(id))button='<button type="button" class="select-btn" disabled>ВРЕМЕННО НЕДОСТУПНА</button>';
          if(isCars&&mode==='garage'){
            button+=`<button type="button" class="tuning-gear" data-tune="${id}" aria-label="Настроить ${item.name}">⚙ <span>ТЮНИНГ</span></button>`;
            const quote=R.getCarInvestmentValue?.(this.save,id);
            button+=id==='apexLime'
              ?`<button type="button" class="sell-btn protected" disabled>БАЗОВАЯ · НЕ ПРОДАЁТСЯ</button>`
              :`<button type="button" class="sell-btn" data-sell="${id}">ПРОДАТЬ · ${formatCredits(quote?.payout||0)} CR</button>`;
          }
          const classes=['shop-item',isSelected?'selected equipped-card':'',isPreview?'previewing':'',isCars?'car-card '+R.CAR_CATEGORIES[cat].className:'effect-card'].filter(Boolean).join(' ');
          const effectStyle=!isCars?` style="--effect-a:${item.rainbow?'#70ff9d':(item.outer||'#61e8ff')};--effect-b:${item.rainbow?'#ff58ce':(item.inner||'#efffff')}"`:'';
          const stateChip=isSelected?'<span class="item-preview-state active">АКТИВНО</span>':isPreview?'<span class="item-preview-state">ПРОСМОТР</span>':'';
          return `<article class="${classes}" data-item="${id}" data-equipped="${isSelected?'true':'false'}" data-previewed="${isPreview?'true':'false'}"${effectStyle}>${isCars?badgeMarkup(cat):''}<button type="button" class="item-preview" aria-label="Предпросмотр ${item.name}" aria-pressed="${isPreview?'true':'false'}">${catalogVisualMarkup(id,item,isCars)}${stateChip}</button><div class="item-title">${item.name}${item.limited?' · LIMITED':''}</div><div class="item-price"><strong>${priceText}</strong><span>${status}</span></div>${isCars?`<div class="car-spec-line">${R.getCarPerformance(id,this.save).maxSpeed} км/ч <span>·</span> РАЗГОН ${R.getCarPerformance(id,this.save).accel} <span>·</span> ТОРМОЗА ${R.getCarPerformance(id,this.save).brakePower}</div>`:""}${shortfallText}${button}</article>`;
        }).join('');
      }
      v.items.querySelectorAll('.catalog-car-thumb').forEach(img=>{
        const visual=img.closest('.catalog-car-visual');
        const mark=()=>visual&&visual.classList.add('asset-error');
        if(img.complete&&!img.naturalWidth)mark();else img.addEventListener('error',mark,{once:true});
      });
      this.cards=Array.from(v.items.querySelectorAll('.shop-item[data-item] canvas.catalog-fallback-canvas')).map(canvas=>{const el=canvas.closest('.shop-item[data-item]'),car=new R.Car();car.x=140;car.y=56;car.speed=280;car.throttleVisual=1;car.setLoadout(el.dataset.item,s.previewEffect,'thumbnail');car.setCustomization(R.getCarStyle(this.save,el.dataset.item));return {car,canvas};});
      if(isCars)this.scheduleCatalogPreload(entries,mode);
      if(!this.categoryEmpty)this.setPreviewCar(s.previewLivery,s.previewEffect);
      if(this.categoryEmpty){const meta=R.CAR_CATEGORIES[s.category]||R.CAR_CATEGORIES.all;v.previewName.textContent=meta.label;v.previewEffect.textContent=mode==='shop'?'НОВЫЕ МОДЕЛИ ГОТОВЯТСЯ':'ПОПОЛНИТЕ КОЛЛЕКЦИЮ В МАГАЗИНЕ';}
      else {v.previewName.textContent=R.LIVERIES[s.previewLivery].name;v.previewEffect.textContent=R.EFFECTS[s.previewEffect].name+(mode==='garage'?' · '+(s[previewKey]===selected?'АКТИВНО':'ПРЕДПРОСМОТР'):'');}
    }
    renderCases(v,s){
      this.cards=[];this.categoryEmpty=false;v.preview.classList.add('hidden');v.caseHero.classList.remove('hidden');
      const selected=R.CASES[s.previewCase]||R.CASES.all;s.previewCase=selected.id;
      v.caseHero.style.setProperty('--case',selected.accent);v.caseHero.dataset.case=selected.id;
      v.previewName.textContent=selected.name;v.previewEffect.textContent=`${selected.label} · ${formatCredits(selected.price)} CR`;v.previewCopy.textContent=selected.description;
      v.items.innerHTML=R.CASE_ORDER.map(id=>{
        const box=R.CASES[id],count=Math.max(0,Math.floor(Number(this.save.caseInventory?.[id])||0)),shortfall=Math.max(0,box.price-this.save.credits),maxReward=Math.max(...box.rewards.map(x=>x.price));
        return `<article class="shop-item case-card ${id===s.previewCase?'selected':''}" data-case="${id}" style="--case:${box.accent}"><div class="case-card-art"><div class="case-crate"><i></i><b>VA</b><span></span></div><em>${box.label}</em>${count?`<mark>x${count}</mark>`:''}</div><div class="case-card-title"><strong>${box.name}</strong><span>${box.subtitle}</span></div><div class="case-card-stats"><span>${box.rewards.length} НАГРАД</span><span>ДО ${formatCredits(maxReward)} CR</span></div><div class="item-price case-price"><strong>${formatCredits(box.price)} CR</strong><span>${id==='all'?'УЛЬТРА-РЕДКИЙ LUX':'ШАНСЫ ПО ЦЕНЕ'}</span></div>${shortfall?`<div class="item-shortfall">ЕЩЁ ${formatCredits(shortfall)} CR</div>`:''}<button type="button" class="purchase-btn case-buy-btn">КУПИТЬ · 1–10</button>${count?`<button type="button" class="case-owned-open-btn">ОТКРЫТЬ · x${count}</button>`:''}</article>`;
      }).join('');
    }
    buyCase(id){
      this.openCaseDialog(id);
    }
    setCaseQuantity(value){
      this.caseQuantity=Math.max(1,Math.min(10,Math.floor(Number(value)||1)));this.refreshCaseDialogInventory();
    }
    buyCaseBatch(){
      const id=this.activeCaseId,box=R.CASES[id],d=this.caseDialog();if(!box||this.caseSpinning)return;
      const result=R.buyCases?R.buyCases(this.save,id,this.caseQuantity):{status:'invalid'};
      const v=this.view('shop');
      if(result.status==='purchased'){
        v.message.textContent=`${box.name} · КУПЛЕНО x${result.quantity} · ${formatCredits(result.cost)} CR`;v.message.classList.remove('warning');this.onChange();this.render();this.refreshCaseDialogInventory();d.ready.classList.remove('hidden');d.ready.textContent=`КУПЛЕНО x${result.quantity} · МОЖНО ОТКРЫТЬ ОДНИМ НАЖАТИЕМ`;
      }else{
        v.message.textContent=result.status==='insufficient'?`НЕДОСТАТОЧНО CR · НУЖНО ${formatCredits(box.price*this.caseQuantity)} CR`:result.status==='limit'?'ЛИМИТ ИНВЕНТАРЯ КЕЙСОВ':'Кейс недоступен';v.message.classList.add('warning');this.refreshCaseDialogInventory();
      }
    }
    openCaseDialog(id){
      const box=R.CASES[id],d=this.caseDialog();if(!box||!d.modal)return;
      this.activeCaseId=id;this.caseSpinning=false;this.caseSpinToken++;this.caseQuantity=1;d.modal.classList.remove('hidden');d.modal.style.setProperty('--case',box.accent);d.crate.style.setProperty('--case',box.accent);d.crate.dataset.case=id;
      d.title.textContent=box.name;d.subtitle.textContent=box.subtitle;d.price.textContent=`ЦЕНА ${formatCredits(box.price)} CR`;d.rewardCount.textContent=`${box.rewards.length} ПРЕДМЕТОВ`;
      d.rewardList.innerHTML=box.rewards.slice().sort((a,b)=>b.price-a.price).map(reward=>{const rarity=rewardRarity(reward);return `<div class="case-reward-row ${rarity.className}" style="--rarity:${rarity.color}">${rewardVisual(reward)}<div><strong>${reward.name}</strong><span>${rarity.label} · ${formatCredits(reward.price)} CR</span></div><b>${chanceText(reward.chanceBps)}</b></div>`;}).join('');
      d.strip.innerHTML='';d.result.className='case-result hidden';d.result.innerHTML='';d.ready.classList.remove('hidden');d.ready.textContent='НАЖМИТЕ «ОТКРЫТЬ», ЧТОБЫ ЗАПУСТИТЬ РУЛЕТКУ';d.close.disabled=false;this.refreshCaseDialogInventory();
    }
    refreshCaseDialogInventory(){
      if(!this.activeCaseId)return;const d=this.caseDialog(),box=R.CASES[this.activeCaseId],count=Math.max(0,Math.floor(Number(this.save.caseInventory?.[this.activeCaseId])||0)),qty=Math.max(1,Math.min(10,this.caseQuantity)),openQty=Math.min(qty,count),cost=box.price*qty;
      d.credits.textContent=formatCredits(this.save.credits)+' CR';d.owned.textContent='x'+count;d.qtyValue.textContent=String(qty);d.qtyMinus.disabled=this.caseSpinning||qty<=1;d.qtyPlus.disabled=this.caseSpinning||qty>=10;
      d.buyBatch.disabled=this.caseSpinning||this.save.credits<cost||count+qty>999;d.buyBatch.textContent=`КУПИТЬ ×${qty} · ${formatCredits(cost)} CR`;
      d.open.disabled=count<1||this.caseSpinning;d.open.textContent=count>0?(this.caseSpinning?'ОТКРЫВАЕМ…':`ОТКРЫТЬ ×${openQty}${qty>count?' · ДОСТУПНО '+count:''}`):'НЕТ КЕЙСОВ';
    }
    closeCaseDialog(){
      const d=this.caseDialog();if(!d.modal||this.caseSpinning)return;d.modal.classList.add('hidden');this.activeCaseId=null;this.caseSpinToken++;this.render();
    }
    randomReward(box){
      let ticket=Math.floor(Math.random()*10000);for(const reward of box.rewards){if(ticket<reward.chanceBps)return reward;ticket-=reward.chanceBps;}return box.rewards[box.rewards.length-1];
    }
    showcaseReward(box){
      const ranked=box.rewards.slice().sort((a,b)=>b.price-a.price),pool=ranked.slice(0,Math.max(1,Math.ceil(ranked.length*.24)));return pool[Math.floor(Math.random()*pool.length)]||ranked[0];
    }
    buildVisualSequence(box,winningReward,targetIndex,total){
      // Visual-only tension reel. The real rewards are already resolved by R.openCases()
      // before this sequence is built, so these showcase items never affect RNG or odds.
      const sequence=[],showcaseOffsets=new Set([2,5,9,14,20,27,34]);
      for(let i=0;i<total;i++){
        if(i===targetIndex){sequence.push({reward:winningReward,showcase:false});continue;}
        const distance=targetIndex-i,showcase=i<targetIndex&&(showcaseOffsets.has(distance)||(i>8&&distance>3&&Math.random()<.09));
        sequence.push({reward:showcase?this.showcaseReward(box):this.randomReward(box),showcase});
      }
      return sequence;
    }
    spinActiveCase(){
      const id=this.activeCaseId,box=R.CASES[id],d=this.caseDialog();if(!box||this.caseSpinning)return;
      const available=Math.max(0,Math.floor(Number(this.save.caseInventory?.[id])||0)),quantity=Math.min(this.caseQuantity,available,10);if(quantity<1){this.refreshCaseDialogInventory();return;}
      const batch=R.openCases?R.openCases(this.save,id,quantity):{status:'invalid',results:[]};if(batch.status!=='opened'||!batch.results.length){this.refreshCaseDialogInventory();return;}
      const results=batch.results,featured=results.reduce((best,item)=>!best||item.reward.price>best.reward.price?item:best,null);
      this.onChange();this.render();this.caseSpinning=true;this.refreshCaseDialogInventory();d.close.disabled=true;d.result.className='case-result hidden';d.result.innerHTML='';d.ready.classList.remove('hidden');d.ready.textContent=results.length>1?`СИНХРОНИЗАЦИЯ ${results.length} DROPS…`:'СИНХРОНИЗАЦИЯ DROP…';
      d.roulette.classList.add('is-spinning');d.roulette.dataset.batchCount=String(results.length);
      const targetIndex=44,total=51,sequence=this.buildVisualSequence(box,featured.reward,targetIndex,total);
      d.strip.innerHTML=sequence.map(({reward,showcase},index)=>{const rarity=rewardRarity(reward);return `<div class="case-roll-item ${rarity.className}${showcase?' showcase':''}" data-roll-index="${index}" style="--rarity:${rarity.color}">${rewardVisual(reward)}<strong>${reward.name}</strong><span>${rarity.label}</span></div>`;}).join('');
      d.strip.style.transition='none';d.strip.style.transform='translate3d(0,0,0)';void d.strip.offsetWidth;
      const token=++this.caseSpinToken,reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches,duration=reduced?420:4700;
      const finish=()=>{if(token!==this.caseSpinToken||!this.caseSpinning)return;this.caseSpinning=false;d.roulette.classList.remove('is-spinning');const target=d.strip.querySelector(`[data-roll-index="${targetIndex}"]`);if(target)target.classList.add('winner');d.close.disabled=false;this.showCaseResults(results);this.refreshCaseDialogInventory();};
      requestAnimationFrame(()=>requestAnimationFrame(()=>{
        const target=d.strip.querySelector(`[data-roll-index="${targetIndex}"]`);if(!target){finish();return;}const offset=Math.max(0,target.offsetLeft-(d.viewport.clientWidth-target.offsetWidth)/2);d.ready.textContent=results.length>1?`ОТКРЫВАЕМ ${results.length} КЕЙСОВ ОДНОВРЕМЕННО…`:'ОТКРЫВАЕМ КЕЙС…';d.strip.style.transition=`transform ${duration}ms cubic-bezier(.07,.72,.08,1)`;d.strip.style.transform=`translate3d(${-offset}px,0,0)`;d.strip.addEventListener('transitionend',finish,{once:true});setTimeout(finish,duration+180);
      }));
    }
    showCaseResult(result){
      this.showCaseResults([result]);
    }
    showCaseResults(results){
      const d=this.caseDialog();if(!Array.isArray(results)||!results.length)return;d.ready.classList.add('hidden');d.result.classList.remove('hidden');
      if(results.length===1){
        const result=results[0],reward=result.reward,rarity=rewardRarity(reward),duplicate=result.duplicate;d.result.className='case-result';d.result.style.setProperty('--rarity',rarity.color);
        d.result.innerHTML=`${rewardVisual(reward)}<div class="case-result-copy"><span class="case-result-kicker ${duplicate?'duplicate':'new'}">${duplicate?'ДУБЛИКАТ · КОМПЕНСАЦИЯ':'НОВЫЙ ПРЕДМЕТ'}</span><strong>${reward.name}</strong><small>${rarity.label} · ШАНС ${chanceText(result.chanceBps)} · ЦЕННОСТЬ ${formatCredits(reward.price)} CR</small>${duplicate?`<b>+${formatCredits(result.compensation)} CR</b>`:'<b>ДОБАВЛЕНО В ГАРАЖ</b>'}</div>`;
        this.view('shop').message.textContent=duplicate?`ДУБЛИКАТ · +${formatCredits(result.compensation)} CR`:`ПОЛУЧЕНО · ${reward.name}`;this.view('shop').message.classList.remove('warning');return;
      }
      const totalComp=results.reduce((sum,x)=>sum+(x.compensation||0),0),newCount=results.filter(x=>!x.duplicate).length;d.result.className='case-result batch';
      d.result.innerHTML=`<div class="case-batch-summary"><span>MULTI DROP</span><strong>${results.length} КЕЙСОВ ОТКРЫТО</strong><small>${newCount} НОВЫХ · ${results.length-newCount} ДУБЛИКАТОВ${totalComp?` · +${formatCredits(totalComp)} CR`:''}</small></div><div class="case-result-grid">${results.map((result,index)=>{const reward=result.reward,rarity=rewardRarity(reward);return `<article class="case-result-mini ${result.duplicate?'duplicate':''}" style="--rarity:${rarity.color};--delay:${Math.min(index,9)*55}ms"><span class="case-result-number">${String(index+1).padStart(2,'0')}</span>${rewardVisual(reward)}<div><strong>${reward.name}</strong><small>${rarity.label} · ${chanceText(result.chanceBps)}</small><b>${result.duplicate?`+${formatCredits(result.compensation)} CR`:'NEW'}</b></div></article>`;}).join('')}</div>`;
      this.view('shop').message.textContent=`MULTI DROP · ${results.length} КЕЙСОВ · ${newCount} НОВЫХ${totalComp?` · +${formatCredits(totalComp)} CR`:''}`;this.view('shop').message.classList.remove('warning');
    }
    draw(dt){
      const s=this.state[this.mode];if((this.mode==='shop'&&s.tab==='case')||(this.mode==='garage'&&s.tab==='upgrade'))return;
      const v=this.view(),canvas=v.preview;if(!canvas)return;
      const ctx=canvas.getContext('2d');ctx.clearRect(0,0,560,360);ctx.strokeStyle='rgba(141,255,73,.12)';ctx.lineWidth=1;
      for(let y=45;y<350;y+=38){ctx.beginPath();ctx.moveTo(20,y);ctx.lineTo(540,y);ctx.stroke();}
      ctx.strokeStyle='rgba(141,255,73,.3)';ctx.beginPath();ctx.ellipse(280,190,210,105,0,0,Math.PI*2);ctx.stroke();
      if(!this.categoryEmpty){this.car.effectTime+=dt;this.car.draw(ctx,3.8);}
      for(const item of this.cards){if(!item.canvas)continue;const c=item.canvas.getContext('2d');c.clearRect(0,0,280,112);item.car.effectTime+=dt;item.car.draw(c,1.6);}
    }
  }
  R.Garage=Garage;
})();
