import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const client=readFileSync(new URL('../public/js/freeroam.js',import.meta.url),'utf8');
const city=readFileSync(new URL('../public/js/free-city.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/css/style.css',import.meta.url),'utf8');
const html=readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
const server=readFileSync(new URL('../src/worker.mjs',import.meta.url),'utf8');

// V43 artwork geometry is covered by free_map_v43_test.mjs.
// Every running mini-game gets the compact score strip, not football only.
assert.ok(client.includes("compactPlaying=e.status==='running'"),'all running mini-games must activate compact HUD');
assert.ok(client.includes("roam.classList.toggle('minigame-playing',compactPlaying)"),'free-roam must expose general compact mini-game state to CSS');
for(const token of ['.free-minigame-hud.minigame-compact','.free-roam.minigame-playing .free-hud-center','@media (orientation:landscape) and (max-height:700px) and (max-width:1180px)'])assert.ok(css.includes(token),`compact mini-game CSS missing ${token}`);
assert.ok(client.includes('baseZoom*(compactView ? .82 : 1)'),'phone landscape mini-game camera must zoom out for a wider view');
assert.ok(html.includes('20260919-v43'),'V40 cache bust must force Safari/PWA to load the corrected map and HUD');
console.log('free_map_football_ui_v35_test: OK — V40 single drift megapark + compact all-mini-game HUD');
