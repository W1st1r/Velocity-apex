/* V43 — original V41 artwork, with collision traced against that exact image.
   No procedural substitute and no legacy road geometry are rendered or used. */
(function(){
 'use strict';
 const L=window.ApexMapLayout,F=window.ApexMapCollision;
 if(!L||!F)throw new Error('V43 map data missing');
 const W=L.width,H=L.height,TAU=Math.PI*2,S=L.referenceScale;
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 function clearance(x,y){
  if(!Number.isFinite(x)||!Number.isFinite(y)||x<2||y<2||x>W-4||y>H-4)return -127;
  const gx=x/F.step,gy=y/F.step,ix=Math.floor(gx),iy=Math.floor(gy),fx=gx-ix,fy=gy-iy,i=iy*F.width+ix,d=F.data;
  return (d[i]*(1-fx)+d[i+1]*fx)*(1-fy)+(d[i+F.width]*(1-fx)+d[i+F.width+1]*fx)*fy-128;
 }
 function roadAt(x,y,margin=0){return clearance(x,y)>-margin;}
 const safe=[];
 for(const r of L.roads)for(let i=1;i<r.points.length;i++){
  const a=r.points[i-1],b=r.points[i],n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/14));
  for(let k=0;k<=n;k++){const x=(a[0]+(b[0]-a[0])*k/n)*S,y=(a[1]+(b[1]-a[1])*k/n)*S;if(roadAt(x,y,-24))safe.push({x,y});}
 }
 for(const p of [L.spawn,L.drift,L.crew,L.koth,L.levels,...Object.values(L.hubs)])if(roadAt(p.x,p.y,-22))safe.push({x:p.x,y:p.y});
 function nearestRoad(x,y){
  if(roadAt(x,y,-22))return{x,y};
  let best=safe[0],dist=Infinity;for(const p of safe){const d=(p.x-x)**2+(p.y-y)**2;if(d<dist){best=p;dist=d;}}
  return {...best};
 }
 function contactPoint(x,y,margin=20){
  for(let i=0;i<18;i++){
   const d=clearance(x,y);if(d>margin+.2)return{x,y};
   const gx=clearance(x+2,y)-clearance(x-2,y),gy=clearance(x,y+2)-clearance(x,y-2),len=Math.hypot(gx,gy);
   if(len<.01)break;const push=Math.min(12,Math.max(.35,margin+.8-d));x+=gx/len*push;y+=gy/len*push;
  }
  return nearestRoad(x,y);
 }
 function resolveCarMotion(car,prevX,prevY){
  const dx=car.x-prevX,dy=car.y-prevY,steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)/4));
  let x=prevX,y=prevY,sx=dx/steps,sy=dy/steps,impact=0;
  if(!roadAt(x,y,-20)){const p=contactPoint(x,y);x=p.x;y=p.y;}
  for(let i=0;i<steps;i++){
   const tx=x+sx,ty=y+sy;if(roadAt(tx,ty,-20)){x=tx;y=ty;continue;}
   const p=contactPoint(tx,ty),nx0=p.x-tx,ny0=p.y-ty,d=Math.hypot(nx0,ny0);
   // Never jump to a different street when resolving a local contact.
   if(d>20){sx=sy=0;car.vx=car.vy=0;break;}
   x=p.x;y=p.y;if(d<1e-7)continue;
   const nx=nx0/d,ny=ny0/d,vn=car.vx*nx+car.vy*ny;
   if(vn<0){impact=Math.max(impact,-vn);const bounce=vn<-35?.10:0;car.vx-=(1+bounce)*vn*nx;car.vy-=(1+bounce)*vn*ny;}
   const inward=sx*nx+sy*ny;if(inward<0){sx-=inward*nx;sy-=inward*ny;}
  }
  car.x=x;car.y=y;car.speed=Math.hypot(car.vx,car.vy);if(impact>45)car.markImpact?.(Math.min(.45,impact/1000));return impact;
 }
 function district(x,y){x/=S;y/=S;if(y>940&&x>1150)return'АЭРОПОРТ';if(x<540&&y>735)return'ПОРТ • DRIFT';if(x<445&&y<385)return'ОЗЁРНЫЙ ПЕРЕВАЛ';if(x>1280&&y<600)return'ИНДУСТРИАЛЬНЫЙ ПАРК';if(x>1290&&y>660)return'СОЛНЕЧНЫЙ КВАРТАЛ';if(x>515&&x<690&&y>447&&y<600)return'ЦЕНТРАЛЬНЫЙ ПАРК';if(x>810&&x<1145&&y>475&&y<726)return'ЦЕНТР • CAR MEET';return'APEX BAY';}
 let image=null,ready=false,failed=false,overview=null;
 function loadImage(src,fallback){
  const img=new Image();img.decoding='async';
  img.onload=()=>{image=img;ready=true;failed=false;};
  img.onerror=()=>{if(fallback)loadImage(fallback);else failed=true;};img.src=src;
 }
 if(typeof Image!=='undefined')loadImage('assets/maps/free-roam-v41.png?v=43','assets/maps/free-roam-v41.webp?v=43');
 function plaque(c,label,x,y,w,h,color='#e6f0ea'){
  c.save();c.fillStyle='#142b30';c.beginPath();c.roundRect((x-w/2)*S,(y-h/2)*S,w*S,h*S,3*S);c.fill();
  c.fillStyle=color;c.textAlign='center';c.textBaseline='middle';c.font=`800 ${h*.56*S}px system-ui`;c.fillText(label,x*S,y*S,w*S-8*S);c.restore();
 }
 function details(c){
  // Open the painted curb exactly where the road union enters the motor club.
  // Reuse the original plaza asphalt instead of painting a foreign flat texture.
  for(const [x,y,w,h] of [[824,606,17,52],[1123,606,24,52],[965,541,51,18],[968,707,49,22]]){
   c.drawImage(image,930*S,620*S,18*S,18*S,x*S,y*S,w*S,h*S);
  }

  // Crisp vector lettering overlays only the sign faces in the retained artwork.
  plaque(c,'ОЗЁРНЫЙ ПЕРЕВАЛ',270,93,158,24);
  plaque(c,'ЦЕНТРАЛЬНЫЙ ПАРК',600,469,145,24);
  plaque(c,'ИНДУСТРИАЛЬНЫЙ',1406,306,127,23);
  plaque(c,'СОЛНЕЧНЫЙ КВАРТАЛ',1386,781,166,24);
  plaque(c,'APEX STADIUM',858,118,108,12,'#bdeeff');
  plaque(c,'CHECKPOINT RUSH',1394,345,128,12,'#b6ffc8');
  plaque(c,'HOT POTATO',361,544,95,11,'#ffc4a6');
  plaque(c,'КЛАНЫ',869,475,59,16,'#c8f5ff');
  plaque(c,'АЭРОПОРТ',1404,1106,75,23);
  // Replace indistinct runway checkers with precisely located finish/start lines.
  for(const x of [L.dragStartX,L.dragFinishX]){
   for(let y=970*S,k=0;y<1060*S;y+=7*S,k++){c.fillStyle=k%2?'#e8eeee':'#24303c';c.fillRect(x-2*S,y,4*S,7*S);}
  }
 }
 function draw(c,view){
  const v=view||{x:0,y:0,w:W,h:H};c.save();
  c.fillStyle='#102a30';c.fillRect(v.x,v.y,v.w,v.h);
  if(ready&&image){
   const x=clamp(v.x,0,W),y=clamp(v.y,0,H),w=Math.max(0,Math.min(W,v.x+v.w)-x),h=Math.max(0,Math.min(H,v.y+v.h)-y);
   c.imageSmoothingEnabled=true;c.imageSmoothingQuality='low';
   // Sample the original pixels once, avoiding the V41 intermediate tile downsample.
   if(w&&h)c.drawImage(image,x,y,w,h,x,y,w,h);details(c);
  }else{
   c.fillStyle='#e0f3ec';c.textAlign='center';c.font='700 22px system-ui';
   c.fillText(failed?'Карта не загрузилась. Проверьте подключение и перезайдите.':'Загрузка карты APEX BAY…',v.x+v.w/2,v.y+v.h/2);
  }
  c.restore();
 }
 function drawOverview(c,w,h){
  if(!ready){c.fillStyle='#102a30';c.fillRect(0,0,w,h);return;}
  if(!overview){overview=document.createElement('canvas');overview.width=2000;overview.height=1200;const g=overview.getContext('2d');g.drawImage(image,0,0,2000,1200);}
  c.drawImage(overview,0,0,w,h);
 }
 window.ApexCity={width:W,height:H,layout:L,hubs:L.hubs,roadAt,clearance,nearestRoad,resolveCarMotion,district,draw,drawOverview,get ready(){return ready;}};
})();
