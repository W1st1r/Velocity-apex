export const CARS={
  "apexLime": {
    "name": "APEX LIME",
    "price": 0,
    "category": "basic",
    "maxSpeed": 300,
    "accel": 190,
    "brakePower": 310,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "crimsonVelocity": {
    "name": "CRIMSON VELOCITY",
    "price": 3250,
    "category": "basic",
    "maxSpeed": 304,
    "accel": 194,
    "brakePower": 314,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "iceVector": {
    "name": "ICE VECTOR",
    "price": 7250,
    "category": "basic",
    "maxSpeed": 309,
    "accel": 198,
    "brakePower": 318,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "auroraPulse": {
    "name": "AURORA PULSE",
    "price": 14250,
    "category": "basic",
    "maxSpeed": 319,
    "accel": 207,
    "brakePower": 327,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "vw-golf-gti": {
    "name": "Volkswagen Golf GTI",
    "price": 6250,
    "category": "basic",
    "maxSpeed": 308,
    "accel": 197,
    "brakePower": 317,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "honda-civic-type-r": {
    "name": "Honda Civic Type R",
    "price": 11500,
    "category": "basic",
    "maxSpeed": 315,
    "accel": 203,
    "brakePower": 323,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "toyota-gt86": {
    "name": "Toyota GT86",
    "price": 9500,
    "category": "basic",
    "maxSpeed": 312,
    "accel": 201,
    "brakePower": 321,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "ford-mustang-gt": {
    "name": "Ford Mustang GT",
    "price": 26250,
    "category": "basic",
    "maxSpeed": 335,
    "accel": 220,
    "brakePower": 340,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "subaru-wrx-sti": {
    "name": "Subaru WRX STI",
    "price": 20500,
    "category": "basic",
    "maxSpeed": 327,
    "accel": 213,
    "brakePower": 333,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bmw-330i": {
    "name": "BMW 330i",
    "price": 16750,
    "category": "basic",
    "maxSpeed": 322,
    "accel": 209,
    "brakePower": 329,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bmw-m5-f90": {
    "name": "BMW M5 F90",
    "price": 72750,
    "category": "sport",
    "maxSpeed": 371,
    "accel": 251,
    "brakePower": 368,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mercedes-cls-63-amg": {
    "name": "Mercedes-Benz CLS 63 AMG",
    "price": 43000,
    "category": "sport",
    "maxSpeed": 350,
    "accel": 230,
    "brakePower": 350,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bmw-m4-competition": {
    "name": "BMW M4 Competition",
    "price": 57250,
    "category": "sport",
    "maxSpeed": 360,
    "accel": 240,
    "brakePower": 358,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mercedes-amg-c63-s": {
    "name": "Mercedes-AMG C63 S",
    "price": 63750,
    "category": "sport",
    "maxSpeed": 364,
    "accel": 244,
    "brakePower": 362,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "audi-rs5": {
    "name": "Audi RS5",
    "price": 49500,
    "category": "sport",
    "maxSpeed": 354,
    "accel": 234,
    "brakePower": 354,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "nissan-gtr-r35": {
    "name": "Nissan GT-R R35",
    "price": 93500,
    "category": "sport",
    "maxSpeed": 385,
    "accel": 265,
    "brakePower": 380,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "chevrolet-corvette-c8": {
    "name": "Chevrolet Corvette C8",
    "price": 83250,
    "category": "sport",
    "maxSpeed": 378,
    "accel": 258,
    "brakePower": 374,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "porsche-911": {
    "name": "Porsche 911 Turbo S",
    "price": 209500,
    "category": "premium",
    "maxSpeed": 430,
    "accel": 310,
    "brakePower": 420,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mercedes-amg-gt-63-s": {
    "name": "Mercedes-AMG GT 63 S",
    "price": 175500,
    "category": "premium",
    "maxSpeed": 417,
    "accel": 295,
    "brakePower": 407,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bmw-m8-competition": {
    "name": "BMW M8 Competition",
    "price": 160000,
    "category": "premium",
    "maxSpeed": 411,
    "accel": 288,
    "brakePower": 401,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bentley-continental-gt": {
    "name": "Bentley Continental GT",
    "price": 145000,
    "category": "premium",
    "maxSpeed": 405,
    "accel": 281,
    "brakePower": 395,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "aston-martin-vantage": {
    "name": "Aston Martin Vantage",
    "price": 132500,
    "category": "premium",
    "maxSpeed": 400,
    "accel": 275,
    "brakePower": 390,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "maserati-mc20": {
    "name": "Maserati MC20",
    "price": 191500,
    "category": "premium",
    "maxSpeed": 423,
    "accel": 302,
    "brakePower": 413,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "audi-r8": {
    "name": "Audi R8",
    "price": 290000,
    "category": "rare",
    "maxSpeed": 445,
    "accel": 320,
    "brakePower": 430,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "lamborghini-huracan": {
    "name": "Lamborghini Huracán",
    "price": 342500,
    "category": "rare",
    "maxSpeed": 453,
    "accel": 328,
    "brakePower": 439,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "ferrari-488-gtb": {
    "name": "Ferrari 488 GTB",
    "price": 319500,
    "category": "rare",
    "maxSpeed": 449,
    "accel": 324,
    "brakePower": 435,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mclaren-720s": {
    "name": "McLaren 720S",
    "price": 375500,
    "category": "rare",
    "maxSpeed": 458,
    "accel": 333,
    "brakePower": 445,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "porsche-918-spyder": {
    "name": "Porsche 918 Spyder",
    "price": 491500,
    "category": "rare",
    "maxSpeed": 475,
    "accel": 350,
    "brakePower": 465,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "lamborghini-aventador": {
    "name": "Lamborghini Aventador",
    "price": 416500,
    "category": "rare",
    "maxSpeed": 464,
    "accel": 339,
    "brakePower": 452,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "ford-gt": {
    "name": "Ford GT",
    "price": 449500,
    "category": "rare",
    "maxSpeed": 469,
    "accel": 344,
    "brakePower": 458,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bugatti-veyron": {
    "name": "Bugatti Veyron",
    "price": 938000,
    "category": "legendary",
    "maxSpeed": 515,
    "accel": 385,
    "brakePower": 504,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "ferrari-enzo": {
    "name": "Ferrari Enzo",
    "price": 713000,
    "category": "legendary",
    "maxSpeed": 495,
    "accel": 365,
    "brakePower": 481,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mclaren-p1": {
    "name": "McLaren P1",
    "price": 884000,
    "category": "legendary",
    "maxSpeed": 510,
    "accel": 380,
    "brakePower": 498,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "lamborghini-sian": {
    "name": "Lamborghini Sian",
    "price": 830000,
    "category": "legendary",
    "maxSpeed": 505,
    "accel": 375,
    "brakePower": 493,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "pagani-huayra": {
    "name": "Pagani Huayra",
    "price": 776000,
    "category": "legendary",
    "maxSpeed": 501,
    "accel": 371,
    "brakePower": 487,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "koenigsegg-agera-rs": {
    "name": "Koenigsegg Agera RS",
    "price": 1000000,
    "category": "legendary",
    "maxSpeed": 520,
    "accel": 390,
    "brakePower": 510,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mercedes-benz-slr-mclaren": {
    "name": "Mercedes-Benz SLR McLaren",
    "price": 654000,
    "category": "legendary",
    "maxSpeed": 490,
    "accel": 360,
    "brakePower": 475,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "ferrari-laferrari": {
    "name": "Ferrari LaFerrari",
    "price": 1349000,
    "category": "lux",
    "maxSpeed": 535,
    "accel": 400,
    "brakePower": 520,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bugatti-chiron-super-sport": {
    "name": "Bugatti Chiron Super Sport",
    "price": 1650000,
    "category": "lux",
    "maxSpeed": 552,
    "accel": 417,
    "brakePower": 545,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "bugatti-divo": {
    "name": "Bugatti Divo",
    "price": 1514000,
    "category": "lux",
    "maxSpeed": 544,
    "accel": 409,
    "brakePower": 534,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "koenigsegg-jesko": {
    "name": "Koenigsegg Jesko",
    "price": 1705000,
    "category": "lux",
    "maxSpeed": 555,
    "accel": 420,
    "brakePower": 550,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "pagani-huayra-bc": {
    "name": "Pagani Huayra BC",
    "price": 1404000,
    "category": "lux",
    "maxSpeed": 538,
    "accel": 403,
    "brakePower": 525,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "lamborghini-veneno": {
    "name": "Lamborghini Veneno",
    "price": 1569000,
    "category": "lux",
    "maxSpeed": 547,
    "accel": 412,
    "brakePower": 538,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "mercedes-amg-one": {
    "name": "Mercedes-AMG ONE",
    "price": 1459000,
    "category": "lux",
    "maxSpeed": 541,
    "accel": 406,
    "brakePower": 529,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "aston-martin-valkyrie-mary": {
    "name": "Mary",
    "price": 1540000,
    "category": "lux",
    "maxSpeed": 546,
    "accel": 411,
    "brakePower": 536,
    "turnRate": 2.4,
    "drift": 1,
    "enabled": true,
    "unavailable": false,
    "limited": false,
    "upgrades": {
      "speed": {
        "step": 0.03,
        "priceFactor": 1
      },
      "acceleration": {
        "step": 0.06,
        "priceFactor": 1.15
      },
      "brakes": {
        "step": 0.07,
        "priceFactor": 0.8
      }
    }
  },
  "apollo-evo": {
    "name": "Apollo EVO",
    "price": 1749000,
    "category": "lux",
    "maxSpeed": 558,
    "accel": 428,
    "brakePower": 560,
    "turnRate": 2.52,
    "drift": 0.94,
    "enabled": true,
    "unavailable": false,
    "limited": true,
    "upgrades": {
      "speed": {
        "step": 0.028,
        "priceFactor": 1.08
      },
      "acceleration": {
        "step": 0.064,
        "priceFactor": 1.2
      },
      "brakes": {
        "step": 0.072,
        "priceFactor": 0.9
      }
    }
  }
};
