(function(){
  'use strict';
  const R=window.Racing=window.Racing||{},clamp=R.clamp,angleWrap=R.angleWrap;
  class AIController{
    constructor(car,index){
      this.car=car;this.index=index;
      const r=Math.random;
      this.aggression=.34+r()*.60;this.precision=.74+r()*.24;this.errorChance=.025+r()*.045;
      this.cornerSkill=.74+r()*.24;this.lane=(r()-.5)*24;this.targetLane=this.lane;
      this.reaction=.76+r()*.22;this.mistake=0;this.mistakeTimer=3+r()*5;this.overtakeSide=r()<.5?-1:1;
      this.steerMemory=0;this.speedBias=.965+r()*.07;
    }

    think(dt,track,cars,difficulty=0){
      const c=this.car,n=track.samples.length;
      this.mistakeTimer-=dt;
      if(this.mistakeTimer<=0){
        this.mistakeTimer=4+Math.random()*7;
        if(Math.random()<this.errorChance)this.mistake=(Math.random()-.5)*(28-18*this.precision);
      }
      this.mistake*=Math.pow(.78,dt);

      // Read traffic ahead in track direction, then choose a lane gradually instead of darting.
      let blocked=false,nearestGap=999,closing=0;
      const trafficDistance=(c.collisionLength||71)+60;
      const closeDistance=(c.collisionLength||71)+14;
      const emergencyDistance=(c.collisionLength||71)+5;
      for(const o of cars){
        if(o===c)continue;
        let gap=o.raceMetric()-c.raceMetric();
        if(gap<0)gap+=1;
        if(gap>0&&gap<.038){
          const dx=o.x-c.x,dy=o.y-c.y,dist=Math.hypot(dx,dy);
          if(dist<trafficDistance&&dist<nearestGap){
            nearestGap=dist;blocked=true;closing=Math.max(0,c.speed-o.speed);
            const local=track.nearest(o.x,o.y,o.trackIndex);this.overtakeSide=local.signed>=0?-1:1;
          }
        }
      }
      if(blocked)this.targetLane=this.overtakeSide*(25+15*this.aggression);
      else this.targetLane=Math.sin((c.progress*6.28)+(this.index*1.73))*7*(1-this.precision)+(this.index%3-1)*6;
      const laneRate=.72+.56*this.aggression;
      this.lane+=(this.targetLane-this.lane)*Math.min(1,dt*laneRate);

      const speed=c.speed;
      const steerLook=Math.floor(13+speed*.055+this.precision*5);
      const aim=track.samples[(c.trackIndex+steerLook)%n];
      const tx=aim.x+aim.nx*(this.lane+this.mistake),ty=aim.y+aim.ny*(this.lane+this.mistake);
      const desiredAngle=Math.atan2(ty-c.y,tx-c.x),diff=angleWrap(desiredAngle-c.angle);
      const rawSteer=clamp(diff*(1.55+this.precision*.58),-1,1);
      const steerBlend=Math.min(1,dt*(4.0+this.reaction*1.8));
      this.steerMemory+=(rawSteer-this.steerMemory)*steerBlend;
      const steer=clamp(this.steerMemory,-1,1);

      // Scan well ahead so braking starts before the corner. Weight nearer curvature more heavily.
      let curveDemand=0;
      const horizon=Math.floor(42+speed*.13);
      for(let k=10;k<=horizon;k+=7){
        const curve=track.samples[(c.trackIndex+k)%n].curve;
        const proximity=1-k/(horizon+10);
        curveDemand=Math.max(curveDemand,curve*(.72+.48*proximity));
      }
      const curveSeverity=clamp((curveDemand-.075)/.44,0,1);
      const base=c.maxSpeed*(1+difficulty*.028)*this.speedBias;
      const cornerReduction=.38-.14*this.cornerSkill;
      let desired=base*(1-curveSeverity*cornerReduction);

      // More conservative when tucked up behind another car, especially with a closing speed.
      if(blocked){
        const proximity=clamp((trafficDistance-nearestGap)/(trafficDistance-closeDistance+24),0,1);
        desired=Math.min(desired,c.speed-closing*.35+22*(1-proximity));
        if(nearestGap<closeDistance)desired=Math.min(desired,Math.max(80,c.speed-48));
      }
      if(!c.onRoad)desired=Math.min(desired,128);

      const overspeed=speed-desired;
      let brake=overspeed>7?clamp((overspeed-7)/58,0,1):0;
      if(blocked&&nearestGap<emergencyDistance)brake=Math.max(brake,clamp((emergencyDistance+2-nearestGap)/28+.18,0,1));
      let throttle=brake>.08?0:clamp((desired-speed)/48+.34,0,1);

      // At the apex, avoid a sudden full-throttle step; build power as steering unwinds.
      const cornerThrottle=1-.42*Math.abs(steer)*clamp(speed/c.maxSpeed,0,1);
      throttle*=clamp(cornerThrottle,.48,1);
      return {steer,throttle,brake};
    }
  }
  R.AIController=AIController;
})();
