import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const client=readFileSync(new URL('../public/js/freeroam.js',import.meta.url),'utf8');
const city=readFileSync(new URL('../public/js/free-city.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/css/style.css',import.meta.url),'utf8');
const html=readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
const server=readFileSync(new URL('../src/worker.mjs',import.meta.url),'utf8');

// Screenshot regressions: no abrupt harbor-road dead end, no minigame/drift footprint on arterials.
assert.ok(city.includes("i===3?165"),'y=2170 road must extend into the waterfront curve instead of ending as a square block');
assert.ok(city.includes("driftHarbor:{x:510,y:2270,w:440,h:350}"),'harbor drift pad must be narrowed and shifted away from waterfront road');
assert.ok(client.includes("drift:{x:730,y:2445,r:150"),'harbor drift marker must match moved pad');
assert.ok(server.includes("harbor:{x:730,y:2445,r:150"),'server harbor drift zone must match client');
assert.ok(city.includes("driftIndustrial:{x:2490,y:1120,w:400,h:300}"),'industrial drift must have its own off-road pad');
assert.ok(client.includes("driftIndustrial:{x:2690,y:1270,r:125"),'industrial drift marker must be off the arterial');
assert.ok(server.includes("industrial:{x:2690,y:1270,r:125"),'server industrial drift zone must match client');
assert.ok(city.includes("apron:{x:600,y:1340,w:320,h:135}"),'Bomb Arena apron must end before both arterial road surfaces');
assert.ok(city.includes("building:{x:620,y:1190,w:280,h:126}"),'Bomb Arena building must remain fully off-road');
assert.ok(client.includes("hotPotatoHub:{x:820,y:1410,r:105"),'Bomb Arena client trigger must follow the moved parking area');
assert.ok(server.includes("hot_potato:{x:820,y:1410,r:118"),'Bomb Arena server trigger must follow the moved parking area');

// In-match football overlay becomes a compact score strip instead of blocking half the pitch.
assert.ok(client.includes("footballCompact=kind==='football'&&e.status==='running'"),'football running state must activate compact HUD');
assert.ok(client.includes("roam.classList.toggle('football-playing',footballCompact)"),'free-roam must expose compact football state to CSS');
for(const token of ['.free-minigame-hud.football-compact','.free-roam.football-playing .free-hud-center','.free-minigame-hud.football-compact .free-minigame-standings{display:none}'])assert.ok(css.includes(token),`compact football CSS missing ${token}`);
assert.ok(html.includes('20260919-v36'),'V35 cache bust must force Safari/PWA to load the fixed map and HUD');
console.log('free_map_football_ui_v35_test: OK — V36 access geometry + compact football HUD');
